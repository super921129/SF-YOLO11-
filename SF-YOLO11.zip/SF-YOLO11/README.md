# SF-YOLO11: Structured-Pruning Optimized YOLO for Winter Jujube Detection

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch 1.12+](https://img.shields.io/badge/PyTorch-1.12+-ee4c2c.svg)](https://pytorch.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

SF-YOLO11 is an advanced object detection model specifically designed for winter jujube detection in agricultural scenarios. Built upon the YOLO architecture, it incorporates adaptive structured pruning, small object enhancement, and multi-scale feature fusion to achieve high accuracy while maintaining computational efficiency.

## 🌟 Key Features

- **Adaptive Structured Pruning**: Intelligent model compression that maintains detection accuracy while reducing computational overhead
- **Small Object Enhancement**: Specialized modules for detecting small winter jujube fruits
- **Multi-Scale Feature Fusion**: ISSFF (Improved Spatial-Spectral Feature Fusion) for better feature representation
- **Lightweight Architecture**: Optimized for deployment on edge devices and mobile platforms
- **Real-time Performance**: Efficient inference suitable for real-time agricultural monitoring

## 🏗️ Architecture Overview

SF-YOLO11 consists of three main components:

1. **Backbone Network**: Enhanced with PrunedC3K2 modules for efficient feature extraction
2. **Neck Network**: ISSFF-based feature pyramid network for multi-scale fusion
3. **Detection Head**: Anchor-free detection head optimized for small object detection

### Key Innovations

- **PrunedC3K2**: Structured pruning-aware convolutional blocks
- **LightSPPF**: Lightweight Spatial Pyramid Pooling Fast module
- **ISSFF**: Improved Spatial-Spectral Feature Fusion for better feature integration
- **Adaptive Pruning Strategy**: Dynamic pruning based on gradient sensitivity and task relevance

## 📦 Installation

### Prerequisites

- Python 3.8 or higher
- CUDA 11.0+ (for GPU acceleration)
- PyTorch 1.12+

### Quick Installation

```bash
# Clone the repository
git clone https://github.com/your-username/SF-YOLO11.git
cd SF-YOLO11

# Install dependencies
pip install -r requirements.txt

# Optional: Install additional dependencies for specific features
pip install tensorboard wandb  # For logging and monitoring
pip install onnx onnxruntime    # For model export
```

### Development Installation

```bash
# Clone with development dependencies
git clone https://github.com/your-username/SF-YOLO11.git
cd SF-YOLO11

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in development mode
pip install -e .
pip install -r requirements.txt
```

## 🚀 Quick Start

### 1. Prepare Your Dataset

Organize your winter jujube dataset in YOLO format:

```
data/
├── winter_jujube/
│   ├── images/
│   │   ├── train/
│   │   ├── val/
│   │   └── test/
│   └── labels/
│       ├── train/
│       ├── val/
│       └── test/
└── winter_jujube.yaml
```

### 2. Training

```bash
# Basic training
python scripts/train.py --config configs/train_config.yaml --data data/winter_jujube.yaml

# Training with custom parameters
python scripts/train.py \
    --config configs/train_config.yaml \
    --data data/winter_jujube.yaml \
    --epochs 300 \
    --batch-size 16 \
    --img-size 640 \
    --device 0
```

### 3. Validation

```bash
# Validate trained model
python scripts/val.py \
    --weights weights/best.pt \
    --data data/winter_jujube.yaml \
    --img-size 640
```

### 4. Inference

```bash
# Single image inference
python scripts/test.py --weights weights/best.pt --source path/to/image.jpg

# Batch inference
python scripts/test.py --weights weights/best.pt --source path/to/images/

# Video inference
python scripts/test.py --weights weights/best.pt --source path/to/video.mp4 --save-vid

# Webcam inference
python scripts/test.py --weights weights/best.pt --source 0
```

### 5. Interactive Demo

```bash
# Launch interactive demo
python scripts/demo.py --weights weights/best.pt --source 0  # Webcam
python scripts/demo.py --weights weights/best.pt --source demo.jpg  # Image
python scripts/demo.py --weights weights/best.pt --source demo.mp4  # Video
```

## 🔧 Model Pruning

SF-YOLO11 supports adaptive structured pruning to reduce model size while maintaining accuracy:

```bash
# Prune model with default settings
python scripts/prune.py --model weights/sf_yolo11n.pt --config configs/prune_config.yaml

# Custom pruning parameters
python scripts/prune.py \
    --model weights/sf_yolo11n.pt \
    --sparsity 0.5 \
    --flops-reduction 0.3 \
    --output weights/pruned_model.pt
```

## 📤 Model Export

Export trained models to various formats for deployment:

```bash
# Export to ONNX
python scripts/export.py --weights weights/best.pt --include onnx

# Export to TensorRT
python scripts/export.py --weights weights/best.pt --include engine --device 0

# Export to CoreML (macOS)
python scripts/export.py --weights weights/best.pt --include coreml

# Export multiple formats
python scripts/export.py --weights weights/best.pt --include onnx tensorrt coreml
```

## 📊 Performance

### Model Variants

| Model | Size (MB) | mAP@0.5 | mAP@0.5:0.95 | FPS (V100) | Parameters |
|-------|-----------|---------|--------------|------------|------------|
| SF-YOLO11n | 6.2 | 89.3% | 67.8% | 142 | 2.6M |
| SF-YOLO11s | 14.7 | 91.7% | 71.2% | 98 | 9.1M |
| SF-YOLO11m | 49.7 | 93.4% | 74.6% | 64 | 20.1M |
| SF-YOLO11l | 87.7 | 94.8% | 76.9% | 43 | 46.5M |

### Pruning Results

| Model | Original Size | Pruned Size | Size Reduction | mAP Retention |
|-------|---------------|-------------|----------------|---------------|
| SF-YOLO11n | 6.2 MB | 3.8 MB | 38.7% | 97.2% |
| SF-YOLO11s | 14.7 MB | 8.9 MB | 39.5% | 96.8% |
| SF-YOLO11m | 49.7 MB | 28.4 MB | 42.9% | 96.1% |

## 📁 Project Structure

```
SF-YOLO11/
├── configs/                 # Configuration files
│   ├── sf_yolo11n.yaml     # Model architecture config
│   ├── train_config.yaml   # Training configuration
│   └── prune_config.yaml   # Pruning configuration
├── data/                   # Dataset configurations
│   └── winter_jujube.yaml  # Winter jujube dataset config
├── models/                 # Model implementations
│   ├── sf_yolo11.py       # Main model architecture
│   ├── adaptive_pruning.py # Pruning strategies
│   ├── detection_head.py   # Detection head
│   ├── issff.py           # Feature fusion module
│   ├── light_sppf.py      # Lightweight SPPF
│   └── pruned_c3k2.py     # Pruned convolution blocks
├── scripts/               # Training and inference scripts
│   ├── train.py          # Training script
│   ├── val.py            # Validation script
│   ├── test.py           # Testing script
│   ├── prune.py          # Pruning script
│   ├── export.py         # Model export script
│   └── demo.py           # Interactive demo
├── utils/                # Utility functions
│   ├── datasets.py       # Dataset loading
│   ├── loss.py           # Loss functions
│   ├── metrics.py        # Evaluation metrics
│   ├── general.py        # General utilities
│   ├── torch_utils.py    # PyTorch utilities
│   └── plots.py          # Visualization tools
├── weights/              # Pre-trained weights
├── results/              # Training results and logs
└── docs/                 # Documentation
```

## 🔬 Experiments

Run comprehensive experiments and ablation studies:

```bash
# Run all experiments
python experiments/run_experiments.py

# Ablation study
python experiments/ablation_study.py --component issff

# Benchmark comparison
python experiments/benchmark.py --models sf_yolo11n yolov8n yolov5n
```

## 📈 Monitoring and Logging

SF-YOLO11 supports multiple logging backends:

### TensorBoard

```bash
# Start TensorBoard
tensorboard --logdir runs/train

# View training progress at http://localhost:6006
```

### Weights & Biases

```bash
# Login to W&B
wandb login

# Training with W&B logging
python scripts/train.py --config configs/train_config.yaml --wandb
```

## 🛠️ Configuration

### Model Configuration

Edit `configs/sf_yolo11n.yaml` to customize model architecture:

```yaml
# Model architecture
model:
  type: SFYOLO11
  variant: nano
  nc: 1  # number of classes
  depth_multiple: 0.33
  width_multiple: 0.25

# Backbone configuration
backbone:
  type: PrunedC3K2
  layers: [3, 6, 6, 3]
  
# Neck configuration
neck:
  type: ISSFF
  channels: [256, 512, 1024]
```

### Training Configuration

Modify `configs/train_config.yaml` for training parameters:

```yaml
# Training parameters
epochs: 300
batch_size: 16
img_size: 640
lr0: 0.01
momentum: 0.937
weight_decay: 0.0005

# Data augmentation
augmentation:
  mosaic: 1.0
  mixup: 0.1
  copy_paste: 0.1
  small_object_augmentation: true
```

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details.

### Development Workflow

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Run tests (`pytest tests/`)
5. Commit your changes (`git commit -m 'Add amazing feature'`)
6. Push to the branch (`git push origin feature/amazing-feature`)
7. Open a Pull Request

### Code Style

We use Black for code formatting and flake8 for linting:

```bash
# Format code
black .

# Check linting
flake8 .

# Sort imports
isort .
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📚 Citation

If you use SF-YOLO11 in your research, please cite:

```bibtex
@article{sf_yolo11_2024,
  title={SF-YOLO11: Adaptive Structured Pruning for Efficient Winter Jujube Detection},
  author={Your Name and Co-authors},
  journal={Journal Name},
  year={2024},
  volume={XX},
  pages={XXX-XXX}
}
```

## 🙏 Acknowledgments

- [Ultralytics YOLO](https://github.com/ultralytics/ultralytics) for the base architecture
- [PyTorch](https://pytorch.org/) for the deep learning framework
- The agricultural computer vision community for inspiration and datasets

## 📞 Contact

- **Author**: Your Name
- **Email**: your.email@example.com
- **Project Link**: https://github.com/your-username/SF-YOLO11

## 🔗 Related Projects

- [YOLOv8](https://github.com/ultralytics/ultralytics)
- [YOLOv5](https://github.com/ultralytics/yolov5)
- [Agricultural Object Detection Datasets](https://github.com/AgML/AgML)

---

**Note**: This project is under active development. Please check the [Issues](https://github.com/your-username/SF-YOLO11/issues) page for known issues and upcoming features.