# SF-YOLO11 API 文档

本文档详细介绍了 SF-YOLO11 的 Python API 接口。

## 目录

- [模型 API](#模型-api)
- [数据处理 API](#数据处理-api)
- [训练 API](#训练-api)
- [推理 API](#推理-api)
- [剪枝 API](#剪枝-api)
- [导出 API](#导出-api)
- [工具函数 API](#工具函数-api)
- [配置 API](#配置-api)

## 模型 API

### SFYOLO11 类

主要的模型类，实现了 SF-YOLO11 架构。

```python
from models.sf_yolo11 import SFYOLO11

class SFYOLO11(nn.Module):
    """SF-YOLO11 模型类"""
    
    def __init__(self, nc=1, variant='nano', pruning_config=None, **kwargs):
        """
        初始化 SF-YOLO11 模型
        
        Args:
            nc (int): 类别数量，默认为 1
            variant (str): 模型变体 ('nano', 'small', 'medium', 'large', 'xlarge')
            pruning_config (dict): 剪枝配置
            **kwargs: 其他参数
        """
    
    def forward(self, x):
        """
        前向传播
        
        Args:
            x (torch.Tensor): 输入张量 [B, C, H, W]
            
        Returns:
            torch.Tensor: 输出预测结果
        """
    
    @classmethod
    def load(cls, weights_path, device='cpu', **kwargs):
        """
        加载预训练模型
        
        Args:
            weights_path (str): 权重文件路径
            device (str): 设备类型
            **kwargs: 其他参数
            
        Returns:
            SFYOLO11: 加载的模型实例
        """
    
    def save(self, save_path, include_optimizer=False):
        """
        保存模型
        
        Args:
            save_path (str): 保存路径
            include_optimizer (bool): 是否包含优化器状态
        """
```

#### 使用示例

```python
# 创建模型
model = SFYOLO11(nc=1, variant='nano')

# 加载预训练权重
model = SFYOLO11.load('weights/sf_yolo11_nano.pt')

# 推理
import torch
x = torch.randn(1, 3, 640, 640)
outputs = model(x)

# 保存模型
model.save('my_model.pt')
```

### 模型变体

```python
# 可用的模型变体
VARIANTS = {
    'nano': {
        'depth_multiple': 0.33,
        'width_multiple': 0.25,
        'max_channels': 1024
    },
    'small': {
        'depth_multiple': 0.33,
        'width_multiple': 0.50,
        'max_channels': 1024
    },
    'medium': {
        'depth_multiple': 0.67,
        'width_multiple': 0.75,
        'max_channels': 768
    },
    'large': {
        'depth_multiple': 1.0,
        'width_multiple': 1.0,
        'max_channels': 512
    },
    'xlarge': {
        'depth_multiple': 1.33,
        'width_multiple': 1.25,
        'max_channels': 512
    }
}
```

## 数据处理 API

### WinterJujubeDataset 类

专门用于冬枣检测的数据集类。

```python
from utils.datasets import WinterJujubeDataset

class WinterJujubeDataset(Dataset):
    """冬枣检测数据集类"""
    
    def __init__(self, path, img_size=640, batch_size=16, augment=False, 
                 hyp=None, rect=False, cache_images=False, single_cls=False,
                 stride=32, pad=0.0, prefix=''):
        """
        初始化数据集
        
        Args:
            path (str): 数据集路径
            img_size (int): 图像尺寸
            batch_size (int): 批次大小
            augment (bool): 是否启用数据增强
            hyp (dict): 超参数配置
            rect (bool): 是否使用矩形训练
            cache_images (bool): 是否缓存图像
            single_cls (bool): 是否单类别
            stride (int): 步长
            pad (float): 填充
            prefix (str): 日志前缀
        """
    
    def __len__(self):
        """返回数据集大小"""
    
    def __getitem__(self, index):
        """
        获取数据项
        
        Args:
            index (int): 索引
            
        Returns:
            tuple: (image, target, path, shapes)
        """
    
    @staticmethod
    def collate_fn(batch):
        """批次整理函数"""
```

#### 使用示例

```python
# 创建数据集
dataset = WinterJujubeDataset(
    path='datasets/winter_jujube/train',
    img_size=640,
    augment=True
)

# 创建数据加载器
from torch.utils.data import DataLoader
dataloader = DataLoader(
    dataset,
    batch_size=16,
    shuffle=True,
    collate_fn=dataset.collate_fn
)

# 遍历数据
for images, targets, paths, shapes in dataloader:
    # 训练代码
    pass
```

### 数据增强

```python
from utils.augmentations import Compose, RandomHSV, RandomFlip, Mosaic

# 创建增强管道
augment = Compose([
    RandomHSV(hgain=0.015, sgain=0.7, vgain=0.4),
    RandomFlip(p=0.5),
    Mosaic(p=1.0)
])

# 应用增强
augmented_image, augmented_labels = augment(image, labels)
```

## 训练 API

### Trainer 类

模型训练器类。

```python
from utils.trainer import Trainer

class Trainer:
    """SF-YOLO11 训练器"""
    
    def __init__(self, model, train_loader, val_loader, optimizer, 
                 scheduler, criterion, device, cfg):
        """
        初始化训练器
        
        Args:
            model: 模型实例
            train_loader: 训练数据加载器
            val_loader: 验证数据加载器
            optimizer: 优化器
            scheduler: 学习率调度器
            criterion: 损失函数
            device: 设备
            cfg: 配置
        """
    
    def train_epoch(self, epoch):
        """
        训练一个 epoch
        
        Args:
            epoch (int): 当前 epoch
            
        Returns:
            dict: 训练指标
        """
    
    def validate(self, epoch):
        """
        验证模型
        
        Args:
            epoch (int): 当前 epoch
            
        Returns:
            dict: 验证指标
        """
    
    def fit(self, epochs, resume_from=None):
        """
        开始训练
        
        Args:
            epochs (int): 训练轮数
            resume_from (str): 恢复训练的检查点路径
        """
```

#### 使用示例

```python
# 创建训练器
trainer = Trainer(
    model=model,
    train_loader=train_loader,
    val_loader=val_loader,
    optimizer=optimizer,
    scheduler=scheduler,
    criterion=criterion,
    device=device,
    cfg=cfg
)

# 开始训练
trainer.fit(epochs=300)

# 从检查点恢复训练
trainer.fit(epochs=300, resume_from='runs/train/exp/weights/last.pt')
```

### 损失函数

```python
from utils.loss import ComputeLoss

class ComputeLoss:
    """SF-YOLO11 损失计算类"""
    
    def __init__(self, model, autobalance=False):
        """
        初始化损失函数
        
        Args:
            model: 模型实例
            autobalance (bool): 是否自动平衡损失权重
        """
    
    def __call__(self, predictions, targets):
        """
        计算损失
        
        Args:
            predictions: 模型预测结果
            targets: 真实标签
            
        Returns:
            tuple: (总损失, 损失详情)
        """
```

## 推理 API

### Detector 类

检测器类，用于模型推理。

```python
from utils.detector import Detector

class Detector:
    """SF-YOLO11 检测器"""
    
    def __init__(self, weights_path, device='cpu', conf_thres=0.25, 
                 iou_thres=0.45, max_det=1000, classes=None, agnostic_nms=False):
        """
        初始化检测器
        
        Args:
            weights_path (str): 权重文件路径
            device (str): 设备类型
            conf_thres (float): 置信度阈值
            iou_thres (float): IoU 阈值
            max_det (int): 最大检测数量
            classes (list): 指定检测的类别
            agnostic_nms (bool): 是否使用类别无关的 NMS
        """
    
    def predict(self, source, save_dir=None, save_txt=False, save_conf=False):
        """
        执行检测
        
        Args:
            source: 输入源（图像路径、视频路径、摄像头索引等）
            save_dir (str): 结果保存目录
            save_txt (bool): 是否保存文本结果
            save_conf (bool): 是否保存置信度
            
        Returns:
            list: 检测结果列表
        """
    
    def predict_image(self, image):
        """
        对单张图像进行检测
        
        Args:
            image: 输入图像（PIL Image 或 numpy array）
            
        Returns:
            DetectionResult: 检测结果
        """
```

#### 使用示例

```python
# 创建检测器
detector = Detector(
    weights_path='weights/sf_yolo11_nano.pt',
    conf_thres=0.25,
    iou_thres=0.45
)

# 检测图像
results = detector.predict('data/images/sample.jpg')

# 检测视频
results = detector.predict('data/videos/sample.mp4', save_dir='runs/detect')

# 检测单张图像
from PIL import Image
image = Image.open('data/images/sample.jpg')
result = detector.predict_image(image)
```

### DetectionResult 类

检测结果类。

```python
class DetectionResult:
    """检测结果类"""
    
    def __init__(self, boxes, scores, classes, image_shape):
        """
        初始化检测结果
        
        Args:
            boxes (np.ndarray): 边界框 [N, 4]
            scores (np.ndarray): 置信度分数 [N]
            classes (np.ndarray): 类别 [N]
            image_shape (tuple): 图像尺寸 (H, W)
        """
        self.boxes = boxes
        self.scores = scores
        self.classes = classes
        self.image_shape = image_shape
    
    def filter_by_confidence(self, threshold):
        """根据置信度过滤结果"""
    
    def filter_by_class(self, class_ids):
        """根据类别过滤结果"""
    
    def to_dict(self):
        """转换为字典格式"""
    
    def to_json(self):
        """转换为 JSON 格式"""
    
    def draw(self, image, class_names=None):
        """在图像上绘制检测结果"""
```

## 剪枝 API

### AdaptivePruner 类

自适应剪枝器类。

```python
from utils.pruning import AdaptivePruner

class AdaptivePruner:
    """自适应剪枝器"""
    
    def __init__(self, model, config):
        """
        初始化剪枝器
        
        Args:
            model: 待剪枝的模型
            config (dict): 剪枝配置
        """
    
    def compute_importance(self, dataloader):
        """
        计算通道重要性
        
        Args:
            dataloader: 数据加载器
            
        Returns:
            dict: 重要性分数
        """
    
    def prune_model(self, sparsity_ratio):
        """
        执行模型剪枝
        
        Args:
            sparsity_ratio (float): 稀疏度比例
            
        Returns:
            nn.Module: 剪枝后的模型
        """
    
    def finetune(self, train_loader, val_loader, epochs):
        """
        微调剪枝后的模型
        
        Args:
            train_loader: 训练数据加载器
            val_loader: 验证数据加载器
            epochs (int): 微调轮数
        """
```

#### 使用示例

```python
# 创建剪枝器
pruner = AdaptivePruner(model, config)

# 计算重要性
importance = pruner.compute_importance(dataloader)

# 执行剪枝
pruned_model = pruner.prune_model(sparsity_ratio=0.5)

# 微调模型
pruner.finetune(train_loader, val_loader, epochs=50)
```

## 导出 API

### ModelExporter 类

模型导出器类。

```python
from utils.export import ModelExporter

class ModelExporter:
    """模型导出器"""
    
    def __init__(self, model, input_shape=(1, 3, 640, 640)):
        """
        初始化导出器
        
        Args:
            model: 待导出的模型
            input_shape (tuple): 输入形状
        """
    
    def export_onnx(self, save_path, opset_version=11, simplify=True):
        """
        导出为 ONNX 格式
        
        Args:
            save_path (str): 保存路径
            opset_version (int): ONNX opset 版本
            simplify (bool): 是否简化模型
        """
    
    def export_tensorrt(self, save_path, precision='fp16', workspace=4):
        """
        导出为 TensorRT 格式
        
        Args:
            save_path (str): 保存路径
            precision (str): 精度类型 ('fp32', 'fp16', 'int8')
            workspace (int): 工作空间大小 (GB)
        """
    
    def export_coreml(self, save_path):
        """导出为 CoreML 格式"""
    
    def export_tflite(self, save_path, quantize=False):
        """导出为 TensorFlow Lite 格式"""
```

#### 使用示例

```python
# 创建导出器
exporter = ModelExporter(model)

# 导出 ONNX
exporter.export_onnx('model.onnx', simplify=True)

# 导出 TensorRT
exporter.export_tensorrt('model.engine', precision='fp16')

# 导出 CoreML
exporter.export_coreml('model.mlmodel')
```

## 工具函数 API

### 通用工具

```python
from utils.general import (
    check_img_size, make_divisible, colorstr, increment_path,
    xyxy2xywh, xywh2xyxy, clip_coords, scale_coords
)

# 检查图像尺寸
img_size = check_img_size(640, stride=32)

# 坐标转换
xywh = xyxy2xywh(xyxy_coords)
xyxy = xywh2xyxy(xywh_coords)

# 坐标缩放
scaled_coords = scale_coords(img1_shape, coords, img0_shape)

# 路径增量
save_dir = increment_path('runs/train/exp')
```

### 指标计算

```python
from utils.metrics import compute_ap, compute_metrics, ConfusionMatrix

# 计算 AP
ap, ap_class = compute_ap(tp, conf, pred_cls, target_cls)

# 计算综合指标
metrics = compute_metrics(tp, conf, pred_cls, target_cls)

# 混淆矩阵
cm = ConfusionMatrix(nc=1)
cm.process_batch(detections, labels)
cm.plot(save_dir='runs/val')
```

### 可视化工具

```python
from utils.plots import plot_images, plot_results, plot_lr_scheduler

# 绘制图像和标签
plot_images(images, targets, paths, 'train_batch.jpg')

# 绘制训练结果
plot_results(csv_file='runs/train/exp/results.csv')

# 绘制学习率调度
plot_lr_scheduler(optimizer, scheduler, epochs)
```

## 配置 API

### 配置管理

```python
from utils.config import Config

# 加载配置
cfg = Config.load('configs/sf_yolo11_nano.yaml')

# 更新配置
cfg.update({'lr0': 0.01, 'epochs': 300})

# 保存配置
cfg.save('my_config.yaml')

# 合并配置
cfg.merge('configs/custom.yaml')
```

### 超参数管理

```python
from utils.hyperparams import HyperParams

# 创建超参数对象
hyp = HyperParams({
    'lr0': 0.01,
    'lrf': 0.01,
    'momentum': 0.937,
    'weight_decay': 0.0005
})

# 超参数搜索
best_hyp = hyp.search(
    model=model,
    train_loader=train_loader,
    val_loader=val_loader,
    trials=100
)
```

## 错误处理

### 自定义异常

```python
from utils.exceptions import (
    ModelLoadError, DatasetError, TrainingError, 
    ExportError, PruningError
)

try:
    model = SFYOLO11.load('invalid_path.pt')
except ModelLoadError as e:
    print(f"模型加载失败: {e}")

try:
    dataset = WinterJujubeDataset('invalid_path')
except DatasetError as e:
    print(f"数据集错误: {e}")
```

## 日志记录

### 日志配置

```python
from utils.logger import setup_logger

# 设置日志
logger = setup_logger(
    name='sf_yolo11',
    log_file='sf_yolo11.log',
    level='INFO'
)

# 使用日志
logger.info("开始训练")
logger.warning("检测到潜在问题")
logger.error("训练失败")
```

## 回调函数

### 训练回调

```python
from utils.callbacks import EarlyStopping, ModelCheckpoint, LRScheduler

# 早停回调
early_stopping = EarlyStopping(
    monitor='val_map',
    patience=10,
    mode='max'
)

# 模型检查点
checkpoint = ModelCheckpoint(
    filepath='best_model.pt',
    monitor='val_map',
    save_best_only=True
)

# 学习率调度
lr_scheduler = LRScheduler(
    scheduler=scheduler,
    monitor='val_loss'
)

# 在训练器中使用回调
trainer.add_callback(early_stopping)
trainer.add_callback(checkpoint)
trainer.add_callback(lr_scheduler)
```

## 示例代码

### 完整训练示例

```python
import torch
from models.sf_yolo11 import SFYOLO11
from utils.datasets import WinterJujubeDataset
from utils.trainer import Trainer
from utils.loss import ComputeLoss
from torch.utils.data import DataLoader

# 创建模型
model = SFYOLO11(nc=1, variant='nano')

# 创建数据集
train_dataset = WinterJujubeDataset('datasets/winter_jujube/train', augment=True)
val_dataset = WinterJujubeDataset('datasets/winter_jujube/val', augment=False)

# 创建数据加载器
train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=16, shuffle=False)

# 创建优化器和损失函数
optimizer = torch.optim.AdamW(model.parameters(), lr=0.01)
criterion = ComputeLoss(model)

# 创建训练器
trainer = Trainer(
    model=model,
    train_loader=train_loader,
    val_loader=val_loader,
    optimizer=optimizer,
    criterion=criterion,
    device='cuda'
)

# 开始训练
trainer.fit(epochs=300)
```

### 完整推理示例

```python
from utils.detector import Detector
from PIL import Image
import numpy as np

# 创建检测器
detector = Detector('weights/sf_yolo11_nano.pt')

# 加载图像
image = Image.open('data/images/sample.jpg')

# 执行检测
result = detector.predict_image(image)

# 处理结果
print(f"检测到 {len(result.boxes)} 个冬枣")
for i, (box, score, cls) in enumerate(zip(result.boxes, result.scores, result.classes)):
    print(f"冬枣 {i+1}: 置信度={score:.3f}, 位置={box}")

# 可视化结果
result_image = result.draw(image, class_names=['winter_jujube'])
result_image.save('result.jpg')
```

## 版本兼容性

- **Python**: 3.8+
- **PyTorch**: 1.12+
- **CUDA**: 11.8+ (可选)
- **ONNX**: 1.12+ (导出时需要)
- **TensorRT**: 8.4+ (导出时需要)

## 更新日志

### v1.0.0
- 初始版本发布
- 支持基础训练、推理、剪枝功能
- 提供完整的 API 接口

### v1.1.0 (计划中)
- 增加更多数据增强方法
- 优化推理速度
- 支持更多导出格式

## 技术支持

如需 API 相关帮助，请：

1. 查看 [使用指南](usage.md)
2. 查看 [FAQ 文档](faq.md)
3. 提交 [GitHub Issue](https://github.com/your-username/SF-YOLO11/issues)
4. 联系技术支持: api-support@sf-yolo11.com