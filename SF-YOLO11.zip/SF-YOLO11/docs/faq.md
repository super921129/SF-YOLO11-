# SF-YOLO11 常见问题解答 (FAQ)

本文档收集了使用 SF-YOLO11 过程中的常见问题和解决方案。

## 目录

- [安装问题](#安装问题)
- [训练问题](#训练问题)
- [推理问题](#推理问题)
- [数据问题](#数据问题)
- [性能问题](#性能问题)
- [部署问题](#部署问题)
- [错误信息](#错误信息)
- [最佳实践](#最佳实践)

## 安装问题

### Q1: 安装时出现 "No module named 'torch'" 错误

**A:** 这表示 PyTorch 未正确安装。请按以下步骤解决：

```bash
# 卸载现有的 PyTorch
pip uninstall torch torchvision torchaudio

# 重新安装 PyTorch (CPU 版本)
pip install torch torchvision torchaudio

# 或安装 GPU 版本
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

### Q2: CUDA 版本不匹配问题

**A:** 确保 CUDA 版本与 PyTorch 版本兼容：

```bash
# 检查 CUDA 版本
nvidia-smi

# 检查 PyTorch CUDA 版本
python -c "import torch; print(torch.version.cuda)"

# 如果不匹配，重新安装对应版本的 PyTorch
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

### Q3: 依赖包版本冲突

**A:** 建议使用虚拟环境隔离依赖：

```bash
# 创建新的虚拟环境
conda create -n sf-yolo11-clean python=3.9
conda activate sf-yolo11-clean

# 安装依赖
pip install -r requirements.txt
```

### Q4: Windows 上安装失败

**A:** Windows 用户常见问题：

```bash
# 确保使用正确的 Python 版本
python --version

# 更新 pip
python -m pip install --upgrade pip

# 安装 Visual Studio Build Tools (如果需要编译)
# 下载并安装 Microsoft C++ Build Tools

# 使用预编译的 wheel 包
pip install --only-binary=all -r requirements.txt
```

## 训练问题

### Q5: 训练损失不下降

**A:** 可能的原因和解决方案：

1. **学习率过高或过低**
```bash
# 使用学习率查找器
python utils/lr_finder.py --data datasets/winter_jujube/data.yaml --cfg configs/sf_yolo11_nano.yaml

# 调整学习率
python scripts/train.py --lr0 0.001  # 降低学习率
```

2. **数据标注错误**
```bash
# 检查数据标注
python utils/check_dataset.py --data datasets/winter_jujube/data.yaml
```

3. **模型配置问题**
```bash
# 使用更小的模型开始
python scripts/train.py --cfg configs/sf_yolo11_nano.yaml
```

### Q6: 显存不足 (CUDA out of memory)

**A:** 减少内存使用：

```bash
# 减少批次大小
python scripts/train.py --batch-size 8

# 使用梯度累积
python scripts/train.py --batch-size 4 --accumulate 4

# 启用混合精度训练
python scripts/train.py --amp

# 减少图像尺寸
python scripts/train.py --img-size 416

# 禁用图像缓存
python scripts/train.py --cache-images false
```

### Q7: 验证精度很低

**A:** 检查以下方面：

1. **数据集质量**
```bash
# 分析数据集
python utils/dataset_analysis.py --data datasets/winter_jujube/data.yaml
```

2. **过拟合问题**
```bash
# 增加数据增强
python scripts/train.py --hsv-h 0.015 --hsv-s 0.7 --hsv-v 0.4 --degrees 10

# 添加正则化
python scripts/train.py --weight-decay 0.0005
```

3. **类别不平衡**
```bash
# 使用类别权重
python scripts/train.py --cls-weights 1.0
```

### Q8: 训练速度很慢

**A:** 优化训练速度：

```bash
# 增加数据加载工作进程
python scripts/train.py --workers 8

# 启用数据预加载
python scripts/train.py --pin-memory

# 使用更高效的数据格式
python utils/convert_dataset.py --format coco --output datasets/winter_jujube_coco

# 启用编译优化
export PYTORCH_JIT=1
python scripts/train.py
```

## 推理问题

### Q9: 推理结果不准确

**A:** 调整推理参数：

```bash
# 降低置信度阈值
python scripts/test.py --conf-thres 0.1

# 调整 NMS 阈值
python scripts/test.py --iou-thres 0.3

# 使用更大的输入尺寸
python scripts/test.py --img-size 832

# 启用测试时增强 (TTA)
python scripts/test.py --augment
```

### Q10: 推理速度慢

**A:** 优化推理速度：

```bash
# 使用更小的模型
python scripts/test.py --weights weights/sf_yolo11_nano.pt

# 减少输入尺寸
python scripts/test.py --img-size 416

# 启用半精度推理
python scripts/test.py --half

# 批量处理
python scripts/test.py --batch-size 32
```

### Q11: 检测框抖动

**A:** 稳定检测结果：

```bash
# 提高置信度阈值
python scripts/test.py --conf-thres 0.5

# 使用更严格的 NMS
python scripts/test.py --iou-thres 0.3

# 启用跟踪算法
python scripts/test.py --track
```

## 数据问题

### Q12: 数据集格式错误

**A:** 确保数据集格式正确：

```
datasets/winter_jujube/
├── images/
│   ├── train/
│   ├── val/
│   └── test/
├── labels/
│   ├── train/
│   ├── val/
│   └── test/
└── data.yaml
```

标注格式：
```
# 每行格式: class_id center_x center_y width height (归一化坐标)
0 0.5 0.5 0.3 0.4
```

### Q13: 图像和标签不匹配

**A:** 检查文件对应关系：

```bash
# 验证数据集
python utils/check_dataset.py --data datasets/winter_jujube/data.yaml --verbose

# 修复不匹配的文件
python utils/fix_dataset.py --data datasets/winter_jujube/data.yaml
```

### Q14: 标注坐标超出范围

**A:** 修复标注坐标：

```bash
# 检查并修复标注
python utils/fix_labels.py --labels-dir datasets/winter_jujube/labels/train
```

### Q15: 数据增强效果不好

**A:** 调整数据增强参数：

```yaml
# 在配置文件中调整
hsv_h: 0.015      # 色调增强
hsv_s: 0.7        # 饱和度增强
hsv_v: 0.4        # 明度增强
degrees: 10.0     # 旋转角度
translate: 0.1    # 平移
scale: 0.5        # 缩放
fliplr: 0.5       # 左右翻转
mosaic: 1.0       # 马赛克增强
mixup: 0.1        # 混合增强
```

## 性能问题

### Q16: 模型精度不够高

**A:** 提升模型精度：

1. **使用更大的模型**
```bash
python scripts/train.py --cfg configs/sf_yolo11_large.yaml
```

2. **增加训练数据**
```bash
# 数据增强
python scripts/train.py --mosaic 1.0 --mixup 0.1

# 收集更多数据
```

3. **调整超参数**
```bash
# 超参数搜索
python utils/hyperparameter_search.py --data datasets/winter_jujube/data.yaml
```

### Q17: 小目标检测效果差

**A:** 优化小目标检测：

```bash
# 使用更大的输入尺寸
python scripts/train.py --img-size 832

# 调整锚框尺寸
python utils/autoanchor.py --data datasets/winter_jujube/data.yaml

# 启用小目标增强
python scripts/train.py --small-object-enhancement
```

### Q18: 模型过拟合

**A:** 减少过拟合：

```bash
# 增加正则化
python scripts/train.py --weight-decay 0.001

# 使用 Dropout
python scripts/train.py --dropout 0.1

# 早停
python scripts/train.py --patience 10

# 数据增强
python scripts/train.py --augment-strength 0.8
```

## 部署问题

### Q19: ONNX 导出失败

**A:** 解决导出问题：

```bash
# 检查 ONNX 版本
pip install onnx>=1.12.0

# 简化导出
python scripts/export.py --weights runs/train/exp/weights/best.pt --include onnx --simplify

# 指定 opset 版本
python scripts/export.py --weights runs/train/exp/weights/best.pt --include onnx --opset 11
```

### Q20: TensorRT 转换失败

**A:** TensorRT 转换问题：

```bash
# 检查 TensorRT 版本
python -c "import tensorrt; print(tensorrt.__version__)"

# 使用兼容的精度
python scripts/export.py --weights runs/train/exp/weights/best.pt --include engine --half

# 增加工作空间
python scripts/export.py --weights runs/train/exp/weights/best.pt --include engine --workspace 8
```

### Q21: 移动端部署问题

**A:** 移动端优化：

```bash
# CoreML 导出 (iOS)
python scripts/export.py --weights runs/train/exp/weights/best.pt --include coreml

# TensorFlow Lite 导出 (Android)
python scripts/export.py --weights runs/train/exp/weights/best.pt --include tflite --int8

# 量化优化
python scripts/export.py --weights runs/train/exp/weights/best.pt --include tflite --int8 --data datasets/winter_jujube/data.yaml
```

## 错误信息

### Q22: "RuntimeError: Expected all tensors to be on the same device"

**A:** 设备不匹配问题：

```python
# 确保模型和数据在同一设备上
model = model.to(device)
images = images.to(device)

# 或在训练脚本中指定设备
python scripts/train.py --device 0  # 使用 GPU 0
python scripts/train.py --device cpu  # 使用 CPU
```

### Q23: "FileNotFoundError: [Errno 2] No such file or directory"

**A:** 文件路径问题：

```bash
# 检查文件是否存在
ls -la weights/sf_yolo11_nano.pt

# 使用绝对路径
python scripts/test.py --weights /absolute/path/to/weights/sf_yolo11_nano.pt

# 下载预训练权重
wget https://github.com/your-username/SF-YOLO11/releases/download/v1.0/sf_yolo11_nano.pt -P weights/
```

### Q24: "ValueError: not enough values to unpack"

**A:** 数据格式问题：

```bash
# 检查数据集格式
python utils/check_dataset.py --data datasets/winter_jujube/data.yaml

# 重新生成数据集
python utils/prepare_dataset.py --source raw_data/ --output datasets/winter_jujube/
```

### Q25: "KeyError: 'model'"

**A:** 权重文件格式问题：

```python
# 检查权重文件内容
import torch
checkpoint = torch.load('weights/sf_yolo11_nano.pt', map_location='cpu')
print(checkpoint.keys())

# 如果是完整的检查点，提取模型权重
if 'model' in checkpoint:
    model_weights = checkpoint['model']
else:
    model_weights = checkpoint
torch.save(model_weights, 'weights/sf_yolo11_nano_model_only.pt')
```

## 最佳实践

### Q26: 如何获得最佳训练效果？

**A:** 训练最佳实践：

1. **数据准备**
   - 确保标注质量高
   - 数据集平衡
   - 充足的训练样本

2. **超参数设置**
   - 使用学习率查找器
   - 适当的批次大小
   - 合理的数据增强

3. **训练策略**
   - 预训练权重初始化
   - 渐进式训练
   - 早停和检查点

### Q27: 如何优化推理性能？

**A:** 推理优化建议：

1. **模型优化**
   - 选择合适的模型大小
   - 模型剪枝和量化
   - 知识蒸馏

2. **部署优化**
   - 使用 TensorRT/ONNX Runtime
   - 批量推理
   - 异步处理

3. **硬件优化**
   - GPU 加速
   - 多线程处理
   - 内存优化

### Q28: 如何处理特殊场景？

**A:** 特殊场景处理：

1. **低光照环境**
```bash
# 增强低光照数据增强
python scripts/train.py --low-light-augment
```

2. **密集目标**
```bash
# 调整 NMS 参数
python scripts/test.py --iou-thres 0.3 --max-det 1000
```

3. **多尺度目标**
```bash
# 多尺度训练
python scripts/train.py --multi-scale
```

## 获取帮助

如果以上解答没有解决您的问题，请：

1. **查看文档**
   - [安装指南](installation.md)
   - [使用指南](usage.md)
   - [API 文档](api.md)

2. **搜索已有问题**
   - [GitHub Issues](https://github.com/your-username/SF-YOLO11/issues)

3. **提交新问题**
   - 提供详细的错误信息
   - 包含复现步骤
   - 说明运行环境

4. **联系支持**
   - 邮箱: support@sf-yolo11.com
   - 论坛: https://forum.sf-yolo11.com

## 贡献

如果您发现了新的问题和解决方案，欢迎：

1. 提交 Pull Request 更新此文档
2. 在 GitHub Issues 中分享经验
3. 参与社区讨论

---

**最后更新**: 2024-01-15
**版本**: v1.0.0