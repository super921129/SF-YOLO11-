# SF-YOLO11 安装指南

本文档提供了 SF-YOLO11 冬枣检测模型的详细安装指南。

## 系统要求

### 硬件要求

**最低配置：**
- CPU: Intel i5 或 AMD Ryzen 5 以上
- 内存: 8GB RAM
- 存储: 10GB 可用空间
- GPU: 可选，但推荐用于训练

**推荐配置：**
- CPU: Intel i7/i9 或 AMD Ryzen 7/9
- 内存: 16GB+ RAM
- 存储: 50GB+ SSD 可用空间
- GPU: NVIDIA GTX 1660 或更高（6GB+ VRAM）

**训练配置：**
- CPU: 高性能多核处理器
- 内存: 32GB+ RAM
- 存储: 100GB+ NVMe SSD
- GPU: NVIDIA RTX 3080/4080 或更高（12GB+ VRAM）

### 软件要求

- **操作系统**: Windows 10/11, Ubuntu 18.04+, macOS 10.15+
- **Python**: 3.8 - 3.11
- **CUDA**: 11.8+ (如果使用 GPU)
- **cuDNN**: 8.6+ (如果使用 GPU)

## 安装方法

### 方法 1: 从源码安装（推荐）

#### 1. 克隆仓库

```bash
git clone https://github.com/your-username/SF-YOLO11.git
cd SF-YOLO11
```

#### 2. 创建虚拟环境

**使用 conda:**
```bash
conda create -n sf-yolo11 python=3.9
conda activate sf-yolo11
```

**使用 venv:**
```bash
python -m venv sf-yolo11-env
# Windows
sf-yolo11-env\Scripts\activate
# Linux/macOS
source sf-yolo11-env/bin/activate
```

#### 3. 安装依赖

**基础安装:**
```bash
pip install -r requirements.txt
```

**开发安装:**
```bash
pip install -e .
```

**完整安装（包含所有可选依赖）:**
```bash
pip install -e ".[dev,export,viz]"
```

### 方法 2: 使用 pip 安装

```bash
pip install sf-yolo11
```

### 方法 3: 使用 Docker

#### 1. 拉取 Docker 镜像

```bash
docker pull sf-yolo11:latest
```

#### 2. 运行容器

```bash
docker run -it --gpus all -v $(pwd):/workspace sf-yolo11:latest
```

## GPU 支持配置

### NVIDIA GPU (CUDA)

#### 1. 安装 CUDA Toolkit

访问 [NVIDIA CUDA 下载页面](https://developer.nvidia.com/cuda-downloads) 下载并安装 CUDA 11.8+。

#### 2. 安装 cuDNN

访问 [NVIDIA cuDNN 下载页面](https://developer.nvidia.com/cudnn) 下载并安装 cuDNN 8.6+。

#### 3. 验证 CUDA 安装

```bash
nvidia-smi
nvcc --version
```

#### 4. 安装 PyTorch GPU 版本

```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

### AMD GPU (ROCm)

#### 1. 安装 ROCm

```bash
# Ubuntu
wget -q -O - https://repo.radeon.com/rocm/rocm.gpg.key | sudo apt-key add -
echo 'deb [arch=amd64] https://repo.radeon.com/rocm/apt/debian/ ubuntu main' | sudo tee /etc/apt/sources.list.d/rocm.list
sudo apt update
sudo apt install rocm-dkms
```

#### 2. 安装 PyTorch ROCm 版本

```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/rocm5.4.2
```

## 验证安装

### 1. 基础验证

```python
import torch
import sf_yolo11

print(f"PyTorch version: {torch.__version__}")
print(f"SF-YOLO11 version: {sf_yolo11.__version__}")
print(f"CUDA available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"CUDA version: {torch.version.cuda}")
    print(f"GPU count: {torch.cuda.device_count()}")
    print(f"Current GPU: {torch.cuda.get_device_name()}")
```

### 2. 模型加载测试

```python
from models.sf_yolo11 import SFYOLO11

# 创建模型
model = SFYOLO11(nc=1, variant='nano')
print(f"Model created successfully: {model}")

# 测试推理
import torch
x = torch.randn(1, 3, 640, 640)
with torch.no_grad():
    y = model(x)
print(f"Inference test passed: {y.shape}")
```

### 3. 运行快速测试

```bash
python scripts/test.py --source data/images/sample.jpg --weights weights/sf_yolo11_nano.pt
```

## 常见问题解决

### 1. CUDA 相关问题

**问题**: `RuntimeError: CUDA out of memory`
**解决方案**:
```bash
# 减少批次大小
python scripts/train.py --batch-size 8

# 使用梯度累积
python scripts/train.py --batch-size 4 --accumulate 2
```

**问题**: `CUDA driver version is insufficient`
**解决方案**:
- 更新 NVIDIA 驱动程序
- 检查 CUDA 版本兼容性

### 2. 依赖冲突

**问题**: 包版本冲突
**解决方案**:
```bash
# 创建新的虚拟环境
conda create -n sf-yolo11-clean python=3.9
conda activate sf-yolo11-clean
pip install -r requirements.txt
```

### 3. 权限问题

**问题**: 权限被拒绝
**解决方案**:
```bash
# Linux/macOS
sudo chown -R $USER:$USER SF-YOLO11/
chmod +x scripts/*.py

# Windows (以管理员身份运行)
```

### 4. 内存不足

**问题**: 系统内存不足
**解决方案**:
```bash
# 减少工作进程数
python scripts/train.py --workers 2

# 禁用图像缓存
python scripts/train.py --cache-images false
```

### 5. 网络连接问题

**问题**: 下载依赖失败
**解决方案**:
```bash
# 使用国内镜像源
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple/

# 或使用离线安装包
pip install --find-links ./wheels -r requirements.txt
```

## 性能优化

### 1. 编译优化

```bash
# 启用 PyTorch JIT 编译
export PYTORCH_JIT=1

# 启用 CUDA 优化
export CUDA_LAUNCH_BLOCKING=0
```

### 2. 内存优化

```python
# 在训练脚本中添加
torch.backends.cudnn.benchmark = True  # 加速训练
torch.backends.cudnn.deterministic = False  # 允许非确定性算法
```

### 3. 数据加载优化

```bash
# 增加数据加载工作进程
python scripts/train.py --workers 8

# 启用内存固定
python scripts/train.py --pin-memory
```

## 卸载

### 1. 卸载 Python 包

```bash
pip uninstall sf-yolo11
```

### 2. 删除虚拟环境

```bash
# conda
conda env remove -n sf-yolo11

# venv
rm -rf sf-yolo11-env/
```

### 3. 清理缓存

```bash
# 清理 pip 缓存
pip cache purge

# 清理 conda 缓存
conda clean --all

# 清理 PyTorch 缓存
python -c "import torch; torch.cuda.empty_cache()"
```

## 更新

### 1. 更新到最新版本

```bash
# 从源码更新
git pull origin main
pip install -e .

# 从 PyPI 更新
pip install --upgrade sf-yolo11
```

### 2. 检查更新

```bash
pip list --outdated | grep sf-yolo11
```

## 技术支持

如果在安装过程中遇到问题，请：

1. 查看 [FAQ 文档](faq.md)
2. 搜索 [GitHub Issues](https://github.com/your-username/SF-YOLO11/issues)
3. 提交新的 Issue 并提供详细的错误信息
4. 联系技术支持: support@sf-yolo11.com

## 许可证

本软件遵循 MIT 许可证。详情请参阅 [LICENSE](../LICENSE) 文件。