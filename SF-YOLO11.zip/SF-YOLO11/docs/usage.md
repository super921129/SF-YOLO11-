# SF-YOLO11 使用指南

本文档详细介绍了如何使用 SF-YOLO11 进行冬枣检测的各种任务。

## 目录

- [快速开始](#快速开始)
- [数据准备](#数据准备)
- [模型训练](#模型训练)
- [模型验证](#模型验证)
- [模型推理](#模型推理)
- [模型剪枝](#模型剪枝)
- [模型导出](#模型导出)
- [实验分析](#实验分析)
- [配置说明](#配置说明)
- [最佳实践](#最佳实践)

## 快速开始

### 1. 基础推理

```bash
# 对单张图片进行检测
python scripts/test.py --source data/images/sample.jpg --weights weights/sf_yolo11_nano.pt

# 对视频进行检测
python scripts/test.py --source data/videos/sample.mp4 --weights weights/sf_yolo11_nano.pt

# 对摄像头进行实时检测
python scripts/test.py --source 0 --weights weights/sf_yolo11_nano.pt
```

### 2. 交互式演示

```bash
# 启动演示界面
python scripts/demo.py --weights weights/sf_yolo11_nano.pt
```

### 3. 批量处理

```bash
# 处理整个文件夹
python scripts/test.py --source data/images/ --weights weights/sf_yolo11_nano.pt --save-txt --save-conf
```

## 数据准备

### 1. 数据集格式

SF-YOLO11 支持 YOLO 格式的数据集：

```
datasets/
├── winter_jujube/
│   ├── images/
│   │   ├── train/
│   │   │   ├── img1.jpg
│   │   │   └── img2.jpg
│   │   ├── val/
│   │   │   ├── img3.jpg
│   │   │   └── img4.jpg
│   │   └── test/
│   │       ├── img5.jpg
│   │       └── img6.jpg
│   ├── labels/
│   │   ├── train/
│   │   │   ├── img1.txt
│   │   │   └── img2.txt
│   │   ├── val/
│   │   │   ├── img3.txt
│   │   │   └── img4.txt
│   │   └── test/
│   │       ├── img5.txt
│   │       └── img6.txt
│   └── data.yaml
```

### 2. 标注格式

每个标注文件包含目标的类别和边界框信息：

```
# 格式: class_id center_x center_y width height (归一化坐标)
0 0.5 0.5 0.3 0.4
0 0.2 0.3 0.1 0.2
```

### 3. 数据配置文件

创建 `data.yaml` 文件：

```yaml
# 数据集配置
path: datasets/winter_jujube  # 数据集根目录
train: images/train  # 训练集路径
val: images/val      # 验证集路径
test: images/test    # 测试集路径

# 类别信息
nc: 1  # 类别数量
names: ['winter_jujube']  # 类别名称

# 数据集信息
description: "Winter Jujube Detection Dataset"
version: "1.0"
license: "MIT"
```

### 4. 数据预处理

```bash
# 数据集统计分析
python utils/dataset_analysis.py --data datasets/winter_jujube/data.yaml

# 数据增强预览
python utils/augmentation_preview.py --data datasets/winter_jujube/data.yaml --samples 10
```

## 模型训练

### 1. 基础训练

```bash
# 使用默认配置训练
python scripts/train.py --data datasets/winter_jujube/data.yaml --cfg configs/sf_yolo11_nano.yaml --weights '' --epochs 300

# 使用预训练权重
python scripts/train.py --data datasets/winter_jujube/data.yaml --cfg configs/sf_yolo11_nano.yaml --weights weights/yolo11n.pt --epochs 300
```

### 2. 高级训练选项

```bash
# 多GPU训练
python -m torch.distributed.run --nproc_per_node 2 scripts/train.py --data datasets/winter_jujube/data.yaml --cfg configs/sf_yolo11_nano.yaml --epochs 300 --device 0,1

# 混合精度训练
python scripts/train.py --data datasets/winter_jujube/data.yaml --cfg configs/sf_yolo11_nano.yaml --epochs 300 --amp

# 自定义超参数
python scripts/train.py --data datasets/winter_jujube/data.yaml --cfg configs/sf_yolo11_nano.yaml --epochs 300 --lr0 0.01 --lrf 0.01 --momentum 0.937 --weight-decay 0.0005
```

### 3. 训练监控

```bash
# 启用 TensorBoard
python scripts/train.py --data datasets/winter_jujube/data.yaml --cfg configs/sf_yolo11_nano.yaml --epochs 300 --tensorboard

# 启用 Weights & Biases
python scripts/train.py --data datasets/winter_jujube/data.yaml --cfg configs/sf_yolo11_nano.yaml --epochs 300 --wandb
```

### 4. 断点续训

```bash
# 从检查点继续训练
python scripts/train.py --resume runs/train/exp/weights/last.pt
```

## 模型验证

### 1. 基础验证

```bash
# 验证训练好的模型
python scripts/val.py --data datasets/winter_jujube/data.yaml --weights runs/train/exp/weights/best.pt

# 指定验证参数
python scripts/val.py --data datasets/winter_jujube/data.yaml --weights runs/train/exp/weights/best.pt --img-size 640 --batch-size 32 --conf-thres 0.25 --iou-thres 0.45
```

### 2. 详细评估

```bash
# 保存验证结果
python scripts/val.py --data datasets/winter_jujube/data.yaml --weights runs/train/exp/weights/best.pt --save-txt --save-json --save-hybrid

# 生成混淆矩阵
python scripts/val.py --data datasets/winter_jujube/data.yaml --weights runs/train/exp/weights/best.pt --plots
```

### 3. 小目标评估

```bash
# 专门评估小目标检测性能
python scripts/val.py --data datasets/winter_jujube/data.yaml --weights runs/train/exp/weights/best.pt --small-object-eval --area-range 0 32 96
```

## 模型推理

### 1. 图像推理

```bash
# 单张图像
python scripts/test.py --source data/images/sample.jpg --weights runs/train/exp/weights/best.pt --conf-thres 0.25

# 多张图像
python scripts/test.py --source data/images/ --weights runs/train/exp/weights/best.pt --save-txt --save-conf
```

### 2. 视频推理

```bash
# 视频文件
python scripts/test.py --source data/videos/sample.mp4 --weights runs/train/exp/weights/best.pt --save-vid

# 实时摄像头
python scripts/test.py --source 0 --weights runs/train/exp/weights/best.pt --view-img
```

### 3. 批量推理

```bash
# 批量处理并保存结果
python scripts/test.py --source data/test_images/ --weights runs/train/exp/weights/best.pt --save-txt --save-conf --save-crop
```

### 4. API 推理

```python
from models.sf_yolo11 import SFYOLO11
import torch
from PIL import Image
import numpy as np

# 加载模型
model = SFYOLO11.load('runs/train/exp/weights/best.pt')
model.eval()

# 加载图像
image = Image.open('data/images/sample.jpg')
image_array = np.array(image)

# 推理
results = model(image_array)

# 处理结果
for result in results:
    boxes = result.boxes.xyxy.cpu().numpy()  # 边界框
    scores = result.boxes.conf.cpu().numpy()  # 置信度
    classes = result.boxes.cls.cpu().numpy()  # 类别
    
    print(f"检测到 {len(boxes)} 个冬枣")
    for i, (box, score, cls) in enumerate(zip(boxes, scores, classes)):
        print(f"冬枣 {i+1}: 置信度={score:.3f}, 位置={box}")
```

## 模型剪枝

### 1. 自适应剪枝

```bash
# 使用默认剪枝配置
python scripts/prune.py --model runs/train/exp/weights/best.pt --data datasets/winter_jujube/data.yaml --config configs/prune_config.yaml

# 自定义剪枝参数
python scripts/prune.py --model runs/train/exp/weights/best.pt --data datasets/winter_jujube/data.yaml --sparsity 0.5 --finetune-epochs 50
```

### 2. 结构化剪枝

```bash
# 通道剪枝
python scripts/prune.py --model runs/train/exp/weights/best.pt --data datasets/winter_jujube/data.yaml --prune-type structured --prune-ratio 0.3

# 层级剪枝
python scripts/prune.py --model runs/train/exp/weights/best.pt --data datasets/winter_jujube/data.yaml --prune-type layerwise --layer-ratios 0.2,0.3,0.4
```

### 3. 剪枝效果分析

```bash
# 比较剪枝前后性能
python scripts/prune.py --model runs/train/exp/weights/best.pt --data datasets/winter_jujube/data.yaml --analyze --benchmark
```

## 模型导出

### 1. ONNX 导出

```bash
# 基础 ONNX 导出
python scripts/export.py --weights runs/train/exp/weights/best.pt --include onnx

# 优化的 ONNX 导出
python scripts/export.py --weights runs/train/exp/weights/best.pt --include onnx --optimize --simplify
```

### 2. TensorRT 导出

```bash
# TensorRT 导出
python scripts/export.py --weights runs/train/exp/weights/best.pt --include engine --device 0

# 指定精度
python scripts/export.py --weights runs/train/exp/weights/best.pt --include engine --half --workspace 4
```

### 3. 移动端导出

```bash
# CoreML (iOS)
python scripts/export.py --weights runs/train/exp/weights/best.pt --include coreml

# TensorFlow Lite (Android)
python scripts/export.py --weights runs/train/exp/weights/best.pt --include tflite --int8
```

### 4. 导出验证

```bash
# 验证导出的模型
python scripts/export.py --weights runs/train/exp/weights/best.pt --include onnx --verify
```

## 实验分析

### 1. 运行实验

```bash
# 运行完整实验套件
python experiments/run_experiments.py --config experiments/experiment_config.yaml

# 运行特定实验
python experiments/run_experiments.py --config experiments/experiment_config.yaml --experiment model_variants
```

### 2. 消融研究

```bash
# 组件消融研究
python experiments/ablation_study.py --config experiments/ablation_config.yaml --component components

# 超参数消融研究
python experiments/ablation_study.py --config experiments/ablation_config.yaml --component hyperparameters
```

### 3. 基准测试

```bash
# 性能基准测试
python experiments/run_experiments.py --config experiments/experiment_config.yaml --experiment benchmark --benchmark-only
```

## 配置说明

### 1. 模型配置

```yaml
# configs/sf_yolo11_nano.yaml
model:
  nc: 1  # 类别数
  depth_multiple: 0.33  # 深度倍数
  width_multiple: 0.25  # 宽度倍数
  
backbone:
  # 骨干网络配置
  
neck:
  # 颈部网络配置
  
head:
  # 检测头配置
```

### 2. 训练配置

```yaml
# 超参数配置
lr0: 0.01          # 初始学习率
lrf: 0.01          # 最终学习率
momentum: 0.937    # 动量
weight_decay: 0.0005  # 权重衰减
warmup_epochs: 3   # 预热轮数
warmup_momentum: 0.8  # 预热动量
warmup_bias_lr: 0.1   # 预热偏置学习率
```

### 3. 数据增强配置

```yaml
# 数据增强参数
hsv_h: 0.015      # 色调增强
hsv_s: 0.7        # 饱和度增强
hsv_v: 0.4        # 明度增强
degrees: 0.0      # 旋转角度
translate: 0.1    # 平移
scale: 0.5        # 缩放
shear: 0.0        # 剪切
perspective: 0.0  # 透视变换
flipud: 0.0       # 上下翻转
fliplr: 0.5       # 左右翻转
mosaic: 1.0       # 马赛克增强
mixup: 0.0        # 混合增强
copy_paste: 0.0   # 复制粘贴增强
```

## 最佳实践

### 1. 训练建议

- **数据质量**: 确保标注准确，图像质量良好
- **数据平衡**: 保持训练集和验证集的类别平衡
- **批次大小**: 根据 GPU 内存调整，通常 16-32 为佳
- **学习率**: 使用学习率查找器确定最优学习率
- **早停**: 设置早停机制避免过拟合

### 2. 推理优化

- **模型选择**: 根据精度和速度需求选择合适的模型变体
- **输入尺寸**: 较大输入尺寸提高精度但降低速度
- **置信度阈值**: 根据应用场景调整置信度阈值
- **NMS 阈值**: 调整 NMS 阈值平衡检测数量和质量

### 3. 部署建议

- **模型导出**: 选择适合目标平台的导出格式
- **量化**: 使用 INT8 量化减少模型大小
- **批处理**: 批量处理提高吞吐量
- **缓存**: 合理使用缓存机制提高效率

### 4. 调试技巧

- **可视化**: 使用可视化工具检查数据和结果
- **日志记录**: 详细记录训练过程和参数
- **版本控制**: 使用版本控制管理实验
- **复现性**: 设置随机种子确保结果可复现

## 常见问题

### 1. 训练问题

**Q: 训练损失不下降**
A: 检查学习率、数据标注、模型配置

**Q: 验证精度低**
A: 增加训练数据、调整数据增强、检查过拟合

**Q: 内存不足**
A: 减少批次大小、使用梯度累积、启用混合精度

### 2. 推理问题

**Q: 检测效果差**
A: 调整置信度阈值、检查输入预处理、使用合适的模型

**Q: 推理速度慢**
A: 使用较小模型、优化输入尺寸、启用 GPU 加速

**Q: 误检较多**
A: 提高置信度阈值、增加负样本训练、调整 NMS 参数

## 技术支持

如需更多帮助，请参考：

- [API 文档](api.md)
- [FAQ 文档](faq.md)
- [GitHub Issues](https://github.com/your-username/SF-YOLO11/issues)
- 技术支持邮箱: support@sf-yolo11.com