#!/usr/bin/env python3
"""
SF-YOLO11 Ablation Study
Detailed ablation study for SF-YOLO11 components
"""

import os
import sys
import argparse
import yaml
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent))

import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from models.sf_yolo11 import SFYOLO11
from utils.datasets import WinterJujubeDataset
from utils.metrics import compute_ap, compute_metrics
from utils.general import increment_path, colorstr
from utils.torch_utils import select_device, time_sync, model_info

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class AblationStudy:
    """Comprehensive ablation study for SF-YOLO11"""
    
    def __init__(self, config_path: str, output_dir: str = "experiments/ablation_results"):
        """
        Initialize ablation study
        
        Args:
            config_path: Path to ablation configuration file
            output_dir: Directory to save results
        """
        self.config_path = config_path
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Load configuration
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)
        
        # Setup device
        self.device = select_device(self.config.get('device', ''))
        
        # Create experiment directory
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.exp_dir = self.output_dir / f"ablation_{self.timestamp}"
        self.exp_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize results storage
        self.results = {
            'component_analysis': [],
            'layer_analysis': [],
            'hyperparameter_analysis': [],
            'architecture_analysis': []
        }
        
        logger.info(f"Ablation study initialized. Results will be saved to: {self.exp_dir}")
    
    def create_model_variant(self, variant_config: Dict[str, Any]) -> nn.Module:
        """Create model variant based on configuration"""
        model_config = variant_config['model']
        
        # Create base model
        model = SFYOLO11(
            nc=model_config.get('nc', 1),
            variant=model_config.get('variant', 'nano'),
            pruning_config=model_config.get('pruning_config')
        )
        
        # Apply component modifications
        components = model_config.get('components', {})
        
        # Disable/modify specific components
        if not components.get('issff', True):
            self.disable_issff(model)
        
        if not components.get('light_sppf', True):
            self.disable_light_sppf(model)
        
        if not components.get('pruned_c3k2', True):
            self.replace_pruned_c3k2(model)
        
        if not components.get('small_object_enhancement', True):
            self.disable_small_object_enhancement(model)
        
        if not components.get('adaptive_pruning', True):
            self.disable_adaptive_pruning(model)
        
        # Load weights if specified
        weights_path = variant_config.get('weights')
        if weights_path and Path(weights_path).exists():
            checkpoint = torch.load(weights_path, map_location=self.device)
            model.load_state_dict(checkpoint.get('model', checkpoint), strict=False)
            logger.info(f"Loaded weights from {weights_path}")
        
        model.to(self.device)
        return model
    
    def disable_issff(self, model: nn.Module):
        """Disable ISSFF feature fusion"""
        # Replace ISSFF with standard feature pyramid
        logger.info("Disabling ISSFF feature fusion")
        # Implementation would replace ISSFF modules with standard FPN
        pass
    
    def disable_light_sppf(self, model: nn.Module):
        """Disable LightSPPF module"""
        # Replace LightSPPF with standard SPPF
        logger.info("Disabling LightSPPF module")
        # Implementation would replace LightSPPF with standard SPPF
        pass
    
    def replace_pruned_c3k2(self, model: nn.Module):
        """Replace PrunedC3K2 with standard C3"""
        logger.info("Replacing PrunedC3K2 with standard C3")
        # Implementation would replace PrunedC3K2 modules with standard C3
        pass
    
    def disable_small_object_enhancement(self, model: nn.Module):
        """Disable small object enhancement features"""
        logger.info("Disabling small object enhancement")
        # Implementation would disable small object specific features
        pass
    
    def disable_adaptive_pruning(self, model: nn.Module):
        """Disable adaptive pruning strategy"""
        logger.info("Disabling adaptive pruning strategy")
        # Implementation would disable pruning-aware training
        pass
    
    def evaluate_model(self, model: nn.Module, dataloader, 
                      conf_thres: float = 0.001, iou_thres: float = 0.6) -> Dict[str, float]:
        """Evaluate model performance"""
        model.eval()
        stats = []
        inference_times = []
        
        with torch.no_grad():
            for batch_i, (imgs, targets, paths, shapes) in enumerate(dataloader):
                imgs = imgs.to(self.device, non_blocking=True)
                imgs = imgs.float() / 255.0
                
                # Inference timing
                torch.cuda.synchronize() if self.device.type == 'cuda' else None
                t1 = time_sync()
                outputs = model(imgs)
                torch.cuda.synchronize() if self.device.type == 'cuda' else None
                t2 = time_sync()
                
                inference_times.append(t2 - t1)
                
                # Apply NMS (simplified)
                outputs = self.apply_nms(outputs, conf_thres, iou_thres)
                
                # Compute statistics
                for si, pred in enumerate(outputs):
                    labels = targets[targets[:, 0] == si, 1:]
                    nl = len(labels)
                    tcls = labels[:, 0].tolist() if nl else []
                    
                    if len(pred) == 0:
                        if nl:
                            stats.append((torch.zeros(0, 4, dtype=torch.bool), 
                                        torch.Tensor(), torch.Tensor(), tcls))
                        continue
                    
                    # Evaluate predictions
                    if nl:
                        tbox = labels[:, 1:5]
                        labelsn = torch.cat((labels[:, 0:1], tbox), 1)
                        correct = self.process_batch(pred, labelsn, iou_thres)
                    else:
                        correct = torch.zeros(pred.shape[0], 10, dtype=torch.bool)
                    
                    stats.append((correct.cpu(), pred[:, 4].cpu(), pred[:, 5].cpu(), tcls))
        
        # Compute metrics
        stats = [np.concatenate(x, 0) for x in zip(*stats)]
        if len(stats) and stats[0].any():
            tp, fp, p, r, f1, ap, ap_class = compute_ap(*stats, plot=False)
            ap50, ap = ap[:, 0], ap.mean(1)
            mp, mr, map50, map = p.mean(), r.mean(), ap50.mean(), ap.mean()
        else:
            mp = mr = map50 = map = 0.0
        
        # Model statistics
        model_stats = self.get_model_stats(model)
        
        return {
            'precision': mp,
            'recall': mr,
            'mAP@0.5': map50,
            'mAP@0.5:0.95': map,
            'f1': 2 * mp * mr / (mp + mr) if (mp + mr) > 0 else 0.0,
            'inference_time': np.mean(inference_times) * 1000,  # ms
            'fps': len(dataloader.dataset) / sum(inference_times),
            **model_stats
        }
    
    def apply_nms(self, outputs, conf_thres: float, iou_thres: float):
        """Apply Non-Maximum Suppression (simplified)"""
        # Placeholder implementation
        return outputs
    
    def process_batch(self, detections, labels, iou_threshold):
        """Process batch for evaluation (simplified)"""
        # Placeholder implementation
        return torch.zeros(detections.shape[0], 10, dtype=torch.bool)
    
    def get_model_stats(self, model: nn.Module) -> Dict[str, float]:
        """Get model statistics"""
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        
        # Model size estimation
        param_size = sum(p.numel() * p.element_size() for p in model.parameters())
        buffer_size = sum(b.numel() * b.element_size() for b in model.buffers())
        size_mb = (param_size + buffer_size) / (1024 ** 2)
        
        return {
            'total_params': total_params,
            'trainable_params': trainable_params,
            'size_mb': size_mb,
            'param_ratio': trainable_params / total_params if total_params > 0 else 0
        }
    
    def run_component_ablation(self):
        """Run component-wise ablation study"""
        logger.info("Running component ablation study...")
        
        config = self.config['ablation']['components']
        results = []
        
        # Baseline model
        baseline_config = self.config['ablation']['baseline']
        baseline_model = self.create_model_variant(baseline_config)
        baseline_dataloader = self.create_dataloader(baseline_config['data'])
        baseline_metrics = self.evaluate_model(baseline_model, baseline_dataloader)
        
        baseline_result = {
            'component': 'baseline',
            'description': 'Full SF-YOLO11 model with all components',
            **baseline_metrics
        }
        results.append(baseline_result)
        logger.info(f"Baseline: mAP@0.5={baseline_metrics['mAP@0.5']:.3f}")
        
        # Test each component removal
        for component_config in config:
            component_name = component_config['name']
            logger.info(f"Testing: {component_name}")
            
            # Create model variant
            model = self.create_model_variant(component_config)
            dataloader = self.create_dataloader(component_config['data'])
            
            # Evaluate
            metrics = self.evaluate_model(model, dataloader)
            
            # Calculate performance impact
            performance_drop = baseline_metrics['mAP@0.5'] - metrics['mAP@0.5']
            relative_drop = (performance_drop / baseline_metrics['mAP@0.5']) * 100
            
            result = {
                'component': component_name,
                'description': component_config['description'],
                **metrics,
                'performance_drop': performance_drop,
                'relative_drop_percent': relative_drop,
                'efficiency_gain': baseline_metrics['size_mb'] - metrics['size_mb'],
                'speed_gain': metrics['fps'] - baseline_metrics['fps']
            }
            
            results.append(result)
            logger.info(f"{component_name}: mAP@0.5={metrics['mAP@0.5']:.3f} "
                       f"(drop: {performance_drop:.3f}, {relative_drop:.1f}%)")
        
        self.results['component_analysis'] = results
        self.save_results(results, 'component_ablation_results.json')
        self.plot_component_ablation(results)
        
        return results
    
    def run_layer_ablation(self):
        """Run layer-wise ablation study"""
        logger.info("Running layer ablation study...")
        
        if 'layers' not in self.config['ablation']:
            logger.warning("Layer ablation configuration not found, skipping...")
            return []
        
        config = self.config['ablation']['layers']
        results = []
        
        for layer_config in config:
            layer_name = layer_config['name']
            logger.info(f"Testing layer configuration: {layer_name}")
            
            # Create model with modified layers
            model = self.create_model_variant(layer_config)
            dataloader = self.create_dataloader(layer_config['data'])
            
            # Evaluate
            metrics = self.evaluate_model(model, dataloader)
            
            result = {
                'layer_config': layer_name,
                'description': layer_config['description'],
                'modification': layer_config.get('modification', 'unknown'),
                **metrics
            }
            
            results.append(result)
            logger.info(f"{layer_name}: mAP@0.5={metrics['mAP@0.5']:.3f}")
        
        self.results['layer_analysis'] = results
        self.save_results(results, 'layer_ablation_results.json')
        self.plot_layer_ablation(results)
        
        return results
    
    def run_hyperparameter_ablation(self):
        """Run hyperparameter ablation study"""
        logger.info("Running hyperparameter ablation study...")
        
        if 'hyperparameters' not in self.config['ablation']:
            logger.warning("Hyperparameter ablation configuration not found, skipping...")
            return []
        
        config = self.config['ablation']['hyperparameters']
        results = []
        
        for hp_config in config:
            hp_name = hp_config['name']
            logger.info(f"Testing hyperparameter: {hp_name}")
            
            # Create model with modified hyperparameters
            model = self.create_model_variant(hp_config)
            dataloader = self.create_dataloader(hp_config['data'])
            
            # Evaluate
            metrics = self.evaluate_model(model, dataloader)
            
            result = {
                'hyperparameter': hp_name,
                'description': hp_config['description'],
                'value': hp_config.get('value', 'unknown'),
                **metrics
            }
            
            results.append(result)
            logger.info(f"{hp_name}: mAP@0.5={metrics['mAP@0.5']:.3f}")
        
        self.results['hyperparameter_analysis'] = results
        self.save_results(results, 'hyperparameter_ablation_results.json')
        self.plot_hyperparameter_ablation(results)
        
        return results
    
    def create_dataloader(self, data_config: Dict[str, Any]):
        """Create dataloader from configuration"""
        dataset = WinterJujubeDataset(
            data_config['path'],
            img_size=data_config.get('img_size', 640),
            batch_size=data_config.get('batch_size', 16),
            augment=False,
            hyp=data_config.get('hyp', {}),
            rect=True,
            cache_images=data_config.get('cache', False),
            single_cls=data_config.get('single_cls', False),
            stride=32,
            pad=0.0,
            prefix=colorstr('val: ')
        )
        
        from torch.utils.data import DataLoader
        dataloader = DataLoader(
            dataset,
            batch_size=data_config.get('batch_size', 16),
            shuffle=False,
            num_workers=data_config.get('workers', 8),
            pin_memory=True,
            collate_fn=dataset.collate_fn
        )
        
        return dataloader
    
    def save_results(self, results: List[Dict], filename: str):
        """Save results to JSON file"""
        output_path = self.exp_dir / filename
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        logger.info(f"Results saved to {output_path}")
    
    def plot_component_ablation(self, results: List[Dict]):
        """Plot component ablation results"""
        df = pd.DataFrame(results)
        
        # Set up the plotting style
        plt.style.use('seaborn-v0_8')
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.suptitle('SF-YOLO11 Component Ablation Study', fontsize=16, fontweight='bold')
        
        # mAP@0.5 comparison
        colors = ['green' if comp == 'baseline' else 'red' for comp in df['component']]
        bars1 = axes[0, 0].bar(df['component'], df['mAP@0.5'], color=colors, alpha=0.7)
        axes[0, 0].set_title('mAP@0.5 by Component')
        axes[0, 0].set_ylabel('mAP@0.5')
        axes[0, 0].tick_params(axis='x', rotation=45)
        
        # Add value labels
        for bar, value in zip(bars1, df['mAP@0.5']):
            axes[0, 0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                           f'{value:.3f}', ha='center', va='bottom', fontweight='bold')
        
        # Performance drop
        df_drop = df[df['component'] != 'baseline'].copy()
        if not df_drop.empty:
            bars2 = axes[0, 1].bar(df_drop['component'], df_drop['performance_drop'], 
                                  color='red', alpha=0.7)
            axes[0, 1].set_title('Performance Drop without Component')
            axes[0, 1].set_ylabel('mAP@0.5 Drop')
            axes[0, 1].tick_params(axis='x', rotation=45)
            
            # Add value labels
            for bar, value in zip(bars2, df_drop['performance_drop']):
                axes[0, 1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.001,
                               f'{value:.3f}', ha='center', va='bottom', fontweight='bold')
        
        # Model size comparison
        bars3 = axes[1, 0].bar(df['component'], df['size_mb'], color=colors, alpha=0.7)
        axes[1, 0].set_title('Model Size by Component')
        axes[1, 0].set_ylabel('Size (MB)')
        axes[1, 0].tick_params(axis='x', rotation=45)
        
        # Speed comparison
        bars4 = axes[1, 1].bar(df['component'], df['fps'], color=colors, alpha=0.7)
        axes[1, 1].set_title('Inference Speed by Component')
        axes[1, 1].set_ylabel('FPS')
        axes[1, 1].tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.savefig(self.exp_dir / 'component_ablation.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # Create detailed comparison table plot
        self.plot_detailed_comparison_table(df)
    
    def plot_detailed_comparison_table(self, df: pd.DataFrame):
        """Create detailed comparison table visualization"""
        fig, ax = plt.subplots(figsize=(14, 8))
        ax.axis('tight')
        ax.axis('off')
        
        # Select key metrics for table
        table_data = df[['component', 'mAP@0.5', 'precision', 'recall', 'f1', 
                        'size_mb', 'fps', 'performance_drop']].copy()
        
        # Round numerical values
        for col in ['mAP@0.5', 'precision', 'recall', 'f1', 'size_mb', 'fps', 'performance_drop']:
            if col in table_data.columns:
                table_data[col] = table_data[col].round(3)
        
        # Create table
        table = ax.table(cellText=table_data.values,
                        colLabels=table_data.columns,
                        cellLoc='center',
                        loc='center',
                        bbox=[0, 0, 1, 1])
        
        # Style the table
        table.auto_set_font_size(False)
        table.set_fontsize(10)
        table.scale(1.2, 2)
        
        # Color baseline row
        for i in range(len(table_data.columns)):
            if table_data.iloc[0]['component'] == 'baseline':
                table[(1, i)].set_facecolor('#90EE90')  # Light green
        
        plt.title('SF-YOLO11 Component Ablation - Detailed Results', 
                 fontsize=14, fontweight='bold', pad=20)
        plt.savefig(self.exp_dir / 'component_ablation_table.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_layer_ablation(self, results: List[Dict]):
        """Plot layer ablation results"""
        if not results:
            return
        
        df = pd.DataFrame(results)
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle('SF-YOLO11 Layer Ablation Study', fontsize=16)
        
        # mAP comparison
        axes[0, 0].bar(df['layer_config'], df['mAP@0.5'])
        axes[0, 0].set_title('mAP@0.5 by Layer Configuration')
        axes[0, 0].set_ylabel('mAP@0.5')
        axes[0, 0].tick_params(axis='x', rotation=45)
        
        # Model size
        axes[0, 1].bar(df['layer_config'], df['size_mb'], color='orange')
        axes[0, 1].set_title('Model Size by Layer Configuration')
        axes[0, 1].set_ylabel('Size (MB)')
        axes[0, 1].tick_params(axis='x', rotation=45)
        
        # Speed
        axes[1, 0].bar(df['layer_config'], df['fps'], color='green')
        axes[1, 0].set_title('Speed by Layer Configuration')
        axes[1, 0].set_ylabel('FPS')
        axes[1, 0].tick_params(axis='x', rotation=45)
        
        # Accuracy vs Speed
        axes[1, 1].scatter(df['fps'], df['mAP@0.5'])
        for i, config in enumerate(df['layer_config']):
            axes[1, 1].annotate(config, (df['fps'].iloc[i], df['mAP@0.5'].iloc[i]))
        axes[1, 1].set_xlabel('FPS')
        axes[1, 1].set_ylabel('mAP@0.5')
        axes[1, 1].set_title('Accuracy vs Speed Trade-off')
        
        plt.tight_layout()
        plt.savefig(self.exp_dir / 'layer_ablation.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_hyperparameter_ablation(self, results: List[Dict]):
        """Plot hyperparameter ablation results"""
        if not results:
            return
        
        df = pd.DataFrame(results)
        
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        fig.suptitle('SF-YOLO11 Hyperparameter Ablation Study', fontsize=16)
        
        # mAP comparison
        axes[0].bar(df['hyperparameter'], df['mAP@0.5'])
        axes[0].set_title('mAP@0.5 by Hyperparameter')
        axes[0].set_ylabel('mAP@0.5')
        axes[0].tick_params(axis='x', rotation=45)
        
        # Speed comparison
        axes[1].bar(df['hyperparameter'], df['fps'], color='green')
        axes[1].set_title('Speed by Hyperparameter')
        axes[1].set_ylabel('FPS')
        axes[1].tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.savefig(self.exp_dir / 'hyperparameter_ablation.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def generate_report(self):
        """Generate comprehensive ablation study report"""
        report_path = self.exp_dir / 'ablation_study_report.md'
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# SF-YOLO11 Ablation Study Report\n\n")
            f.write(f"**Generated on:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write(f"**Study ID:** {self.timestamp}\n\n")
            
            # Component ablation results
            if self.results['component_analysis']:
                f.write("## Component Ablation Study\n\n")
                f.write("This section analyzes the contribution of each major component in SF-YOLO11.\n\n")
                
                df = pd.DataFrame(self.results['component_analysis'])
                f.write("### Results Summary\n\n")
                f.write(df.to_markdown(index=False))
                f.write("\n\n")
                
                # Find most important component
                df_drop = df[df['component'] != 'baseline']
                if not df_drop.empty:
                    most_important = df_drop.loc[df_drop['performance_drop'].idxmax()]
                    f.write(f"**Most Critical Component:** {most_important['component']} ")
                    f.write(f"(Performance drop: {most_important['performance_drop']:.3f})\n\n")
            
            # Layer ablation results
            if self.results['layer_analysis']:
                f.write("## Layer Ablation Study\n\n")
                df = pd.DataFrame(self.results['layer_analysis'])
                f.write(df.to_markdown(index=False))
                f.write("\n\n")
            
            # Hyperparameter ablation results
            if self.results['hyperparameter_analysis']:
                f.write("## Hyperparameter Ablation Study\n\n")
                df = pd.DataFrame(self.results['hyperparameter_analysis'])
                f.write(df.to_markdown(index=False))
                f.write("\n\n")
            
            f.write("## Conclusions\n\n")
            f.write("This ablation study provides insights into the contribution of each component ")
            f.write("in SF-YOLO11 for winter jujube detection. The results help understand the ")
            f.write("trade-offs between accuracy, speed, and model size.\n\n")
            
            f.write("## Files Generated\n\n")
            f.write("- `component_ablation.png`: Component ablation visualization\n")
            f.write("- `component_ablation_table.png`: Detailed results table\n")
            f.write("- `layer_ablation.png`: Layer ablation visualization\n")
            f.write("- `hyperparameter_ablation.png`: Hyperparameter ablation visualization\n")
            f.write("- `*.json`: Raw results data\n")
        
        logger.info(f"Ablation study report generated: {report_path}")
    
    def run_full_ablation_study(self):
        """Run complete ablation study"""
        logger.info("Starting comprehensive ablation study...")
        
        # Run component ablation
        self.run_component_ablation()
        
        # Run layer ablation if configured
        self.run_layer_ablation()
        
        # Run hyperparameter ablation if configured
        self.run_hyperparameter_ablation()
        
        # Generate report
        self.generate_report()
        
        logger.info(f"Ablation study completed. Results saved to: {self.exp_dir}")

def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='SF-YOLO11 Ablation Study')
    parser.add_argument('--config', type=str, default='experiments/ablation_config.yaml',
                       help='Path to ablation configuration file')
    parser.add_argument('--output', type=str, default='experiments/ablation_results',
                       help='Output directory for results')
    parser.add_argument('--component', type=str, 
                       choices=['all', 'components', 'layers', 'hyperparameters'],
                       default='all', help='Specific ablation study to run')
    parser.add_argument('--device', type=str, default='', help='Device to use')
    
    return parser.parse_args()

def main():
    """Main function"""
    args = parse_args()
    
    # Initialize ablation study
    study = AblationStudy(args.config, args.output)
    
    # Override device if specified
    if args.device:
        study.device = select_device(args.device)
    
    # Run specified ablation study
    if args.component == 'all':
        study.run_full_ablation_study()
    elif args.component == 'components':
        study.run_component_ablation()
        study.generate_report()
    elif args.component == 'layers':
        study.run_layer_ablation()
        study.generate_report()
    elif args.component == 'hyperparameters':
        study.run_hyperparameter_ablation()
        study.generate_report()
    
    print(f"\n{colorstr('Ablation study completed!')} Results saved to: {study.exp_dir}")

if __name__ == '__main__':
    main()