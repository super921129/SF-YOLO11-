#!/usr/bin/env python3
"""
SF-YOLO11 Comprehensive Experiments Runner
Run various experiments to evaluate model performance and conduct ablation studies
"""

import os
import sys
import argparse
import yaml
import json
import time
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent))

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from models.sf_yolo11 import SFYOLO11
from utils.datasets import WinterJujubeDataset
from utils.metrics import compute_ap, compute_metrics
from utils.general import increment_path, colorstr
from utils.torch_utils import select_device, time_sync

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ExperimentRunner:
    """Comprehensive experiment runner for SF-YOLO11"""
    
    def __init__(self, config_path: str, output_dir: str = "experiments/results"):
        """
        Initialize experiment runner
        
        Args:
            config_path: Path to experiment configuration file
            output_dir: Directory to save experiment results
        """
        self.config_path = config_path
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Load experiment configuration
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)
        
        # Setup device
        self.device = select_device(self.config.get('device', ''))
        
        # Initialize results storage
        self.results = {
            'experiments': [],
            'ablation_studies': [],
            'benchmark_comparisons': [],
            'pruning_analysis': [],
            'runtime_analysis': []
        }
        
        # Create experiment timestamp
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.exp_dir = self.output_dir / f"exp_{self.timestamp}"
        self.exp_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Experiment runner initialized. Results will be saved to: {self.exp_dir}")
    
    def load_model(self, model_config: Dict[str, Any], weights_path: Optional[str] = None) -> nn.Module:
        """Load SF-YOLO11 model with specified configuration"""
        model = SFYOLO11(
            nc=model_config.get('nc', 1),
            variant=model_config.get('variant', 'nano'),
            pruning_config=model_config.get('pruning_config')
        )
        
        if weights_path and Path(weights_path).exists():
            checkpoint = torch.load(weights_path, map_location=self.device)
            model.load_state_dict(checkpoint.get('model', checkpoint))
            logger.info(f"Loaded weights from {weights_path}")
        
        model.to(self.device)
        model.eval()
        return model
    
    def load_dataset(self, data_config: Dict[str, Any], split: str = 'val') -> DataLoader:
        """Load dataset for evaluation"""
        dataset = WinterJujubeDataset(
            data_config['path'],
            img_size=data_config.get('img_size', 640),
            batch_size=data_config.get('batch_size', 16),
            augment=False,  # No augmentation for evaluation
            hyp=data_config.get('hyp', {}),
            rect=True,  # Rectangular inference
            cache_images=data_config.get('cache', False),
            single_cls=data_config.get('single_cls', False),
            stride=32,
            pad=0.0,
            prefix=colorstr(f'{split}: ')
        )
        
        dataloader = DataLoader(
            dataset,
            batch_size=data_config.get('batch_size', 16),
            shuffle=False,
            num_workers=data_config.get('workers', 8),
            pin_memory=True,
            collate_fn=dataset.collate_fn
        )
        
        return dataloader
    
    def evaluate_model(self, model: nn.Module, dataloader: DataLoader, 
                      conf_thres: float = 0.001, iou_thres: float = 0.6) -> Dict[str, float]:
        """Evaluate model performance"""
        model.eval()
        stats = []
        
        with torch.no_grad():
            for batch_i, (imgs, targets, paths, shapes) in enumerate(dataloader):
                imgs = imgs.to(self.device, non_blocking=True)
                imgs = imgs.float() / 255.0
                
                # Inference
                t1 = time_sync()
                outputs = model(imgs)
                t2 = time_sync()
                
                # Apply NMS
                outputs = self.apply_nms(outputs, conf_thres, iou_thres)
                
                # Statistics per image
                for si, pred in enumerate(outputs):
                    labels = targets[targets[:, 0] == si, 1:]
                    nl = len(labels)
                    tcls = labels[:, 0].tolist() if nl else []
                    
                    if len(pred) == 0:
                        if nl:
                            stats.append((torch.zeros(0, 4, dtype=torch.bool), 
                                        torch.Tensor(), torch.Tensor(), tcls))
                        continue
                    
                    # Predictions
                    predn = pred.clone()
                    
                    # Evaluate
                    if nl:
                        tbox = labels[:, 1:5]  # target boxes
                        labelsn = torch.cat((labels[:, 0:1], tbox), 1)  # native-space labels
                        correct = self.process_batch(predn, labelsn, iou_thres)
                    else:
                        correct = torch.zeros(pred.shape[0], 10, dtype=torch.bool)
                    
                    stats.append((correct.cpu(), pred[:, 4].cpu(), pred[:, 5].cpu(), tcls))
        
        # Compute metrics
        stats = [np.concatenate(x, 0) for x in zip(*stats)]
        if len(stats) and stats[0].any():
            tp, fp, p, r, f1, ap, ap_class = compute_ap(*stats, plot=False)
            ap50, ap = ap[:, 0], ap.mean(1)  # AP@0.5, AP@0.5:0.95
            mp, mr, map50, map = p.mean(), r.mean(), ap50.mean(), ap.mean()
        else:
            mp = mr = map50 = map = 0.0
        
        return {
            'precision': mp,
            'recall': mr,
            'mAP@0.5': map50,
            'mAP@0.5:0.95': map,
            'inference_time': (t2 - t1) * 1000  # ms
        }
    
    def apply_nms(self, outputs, conf_thres: float, iou_thres: float):
        """Apply Non-Maximum Suppression"""
        # Simplified NMS implementation
        # In practice, you would use torchvision.ops.nms or similar
        return outputs  # Placeholder
    
    def process_batch(self, detections, labels, iou_threshold):
        """Process batch for evaluation metrics"""
        # Simplified batch processing
        # In practice, you would implement proper IoU calculation and matching
        return torch.zeros(detections.shape[0], 10, dtype=torch.bool)
    
    def run_model_variants_experiment(self):
        """Run experiments on different model variants"""
        logger.info("Running model variants experiment...")
        
        variants = self.config['experiments']['model_variants']
        results = []
        
        for variant_config in variants:
            logger.info(f"Testing variant: {variant_config['name']}")
            
            # Load model
            model = self.load_model(variant_config['model'], variant_config.get('weights'))
            
            # Load dataset
            dataloader = self.load_dataset(variant_config['data'])
            
            # Evaluate
            metrics = self.evaluate_model(model, dataloader)
            
            # Model statistics
            model_stats = self.get_model_stats(model)
            
            result = {
                'variant': variant_config['name'],
                'model_config': variant_config['model'],
                **metrics,
                **model_stats
            }
            
            results.append(result)
            logger.info(f"Variant {variant_config['name']} results: mAP@0.5={metrics['mAP@0.5']:.3f}")
        
        self.results['experiments'] = results
        self.save_results(results, 'model_variants_results.json')
        self.plot_model_variants_comparison(results)
    
    def run_ablation_study(self):
        """Run ablation study on key components"""
        logger.info("Running ablation study...")
        
        ablation_config = self.config['experiments']['ablation_study']
        results = []
        
        # Baseline model
        baseline_model = self.load_model(ablation_config['baseline']['model'], 
                                       ablation_config['baseline'].get('weights'))
        baseline_dataloader = self.load_dataset(ablation_config['baseline']['data'])
        baseline_metrics = self.evaluate_model(baseline_model, baseline_dataloader)
        
        baseline_result = {
            'component': 'baseline',
            'description': 'Full SF-YOLO11 model',
            **baseline_metrics
        }
        results.append(baseline_result)
        
        # Test each component removal
        for component in ablation_config['components']:
            logger.info(f"Testing without component: {component['name']}")
            
            # Load modified model (without specific component)
            model = self.load_model(component['model'], component.get('weights'))
            dataloader = self.load_dataset(component['data'])
            
            metrics = self.evaluate_model(model, dataloader)
            
            result = {
                'component': component['name'],
                'description': component['description'],
                **metrics,
                'performance_drop': baseline_metrics['mAP@0.5'] - metrics['mAP@0.5']
            }
            
            results.append(result)
            logger.info(f"Without {component['name']}: mAP@0.5={metrics['mAP@0.5']:.3f} "
                       f"(drop: {result['performance_drop']:.3f})")
        
        self.results['ablation_studies'] = results
        self.save_results(results, 'ablation_study_results.json')
        self.plot_ablation_study(results)
    
    def run_pruning_analysis(self):
        """Run pruning analysis experiment"""
        logger.info("Running pruning analysis...")
        
        pruning_config = self.config['experiments']['pruning_analysis']
        results = []
        
        for pruning_setting in pruning_config['settings']:
            logger.info(f"Testing pruning: {pruning_setting['name']}")
            
            # Load pruned model
            model = self.load_model(pruning_setting['model'], pruning_setting.get('weights'))
            dataloader = self.load_dataset(pruning_setting['data'])
            
            # Evaluate
            metrics = self.evaluate_model(model, dataloader)
            model_stats = self.get_model_stats(model)
            
            result = {
                'pruning_method': pruning_setting['name'],
                'sparsity': pruning_setting.get('sparsity', 0.0),
                'pruning_config': pruning_setting.get('pruning_config', {}),
                **metrics,
                **model_stats
            }
            
            results.append(result)
            logger.info(f"Pruning {pruning_setting['name']}: "
                       f"mAP@0.5={metrics['mAP@0.5']:.3f}, "
                       f"Size={model_stats['size_mb']:.1f}MB")
        
        self.results['pruning_analysis'] = results
        self.save_results(results, 'pruning_analysis_results.json')
        self.plot_pruning_analysis(results)
    
    def run_benchmark_comparison(self):
        """Run benchmark comparison with other models"""
        logger.info("Running benchmark comparison...")
        
        benchmark_config = self.config['experiments']['benchmark_comparison']
        results = []
        
        for model_config in benchmark_config['models']:
            logger.info(f"Benchmarking: {model_config['name']}")
            
            # Load model (could be SF-YOLO11 or other YOLO variants)
            if model_config['type'] == 'sf_yolo11':
                model = self.load_model(model_config['model'], model_config.get('weights'))
            else:
                # Load other model types (YOLOv8, YOLOv5, etc.)
                model = self.load_external_model(model_config)
            
            dataloader = self.load_dataset(model_config['data'])
            
            # Evaluate
            metrics = self.evaluate_model(model, dataloader)
            model_stats = self.get_model_stats(model)
            
            # Runtime benchmark
            runtime_stats = self.benchmark_runtime(model, dataloader)
            
            result = {
                'model_name': model_config['name'],
                'model_type': model_config['type'],
                **metrics,
                **model_stats,
                **runtime_stats
            }
            
            results.append(result)
            logger.info(f"Model {model_config['name']}: "
                       f"mAP@0.5={metrics['mAP@0.5']:.3f}, "
                       f"FPS={runtime_stats['fps']:.1f}")
        
        self.results['benchmark_comparisons'] = results
        self.save_results(results, 'benchmark_comparison_results.json')
        self.plot_benchmark_comparison(results)
    
    def load_external_model(self, model_config: Dict[str, Any]) -> nn.Module:
        """Load external model (YOLOv8, YOLOv5, etc.)"""
        # Placeholder for loading external models
        # In practice, you would implement specific loaders for each model type
        logger.warning(f"External model loading not implemented for {model_config['type']}")
        return self.load_model(model_config['model'], model_config.get('weights'))
    
    def get_model_stats(self, model: nn.Module) -> Dict[str, float]:
        """Get model statistics (parameters, FLOPs, size)"""
        # Count parameters
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        
        # Estimate model size (MB)
        param_size = sum(p.numel() * p.element_size() for p in model.parameters())
        buffer_size = sum(b.numel() * b.element_size() for b in model.buffers())
        size_mb = (param_size + buffer_size) / (1024 ** 2)
        
        return {
            'total_params': total_params,
            'trainable_params': trainable_params,
            'size_mb': size_mb
        }
    
    def benchmark_runtime(self, model: nn.Module, dataloader: DataLoader, 
                         num_batches: int = 100) -> Dict[str, float]:
        """Benchmark model runtime performance"""
        model.eval()
        times = []
        
        with torch.no_grad():
            for i, (imgs, _, _, _) in enumerate(dataloader):
                if i >= num_batches:
                    break
                
                imgs = imgs.to(self.device, non_blocking=True)
                imgs = imgs.float() / 255.0
                
                # Warmup
                if i < 10:
                    _ = model(imgs)
                    continue
                
                # Benchmark
                torch.cuda.synchronize() if self.device.type == 'cuda' else None
                t1 = time.time()
                _ = model(imgs)
                torch.cuda.synchronize() if self.device.type == 'cuda' else None
                t2 = time.time()
                
                times.append(t2 - t1)
        
        if times:
            avg_time = np.mean(times)
            fps = dataloader.batch_size / avg_time
            return {
                'avg_inference_time': avg_time * 1000,  # ms
                'fps': fps,
                'throughput': fps * dataloader.batch_size  # images/sec
            }
        else:
            return {'avg_inference_time': 0, 'fps': 0, 'throughput': 0}
    
    def save_results(self, results: List[Dict], filename: str):
        """Save experiment results to JSON file"""
        output_path = self.exp_dir / filename
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        logger.info(f"Results saved to {output_path}")
    
    def plot_model_variants_comparison(self, results: List[Dict]):
        """Plot model variants comparison"""
        df = pd.DataFrame(results)
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('SF-YOLO11 Model Variants Comparison', fontsize=16)
        
        # mAP comparison
        axes[0, 0].bar(df['variant'], df['mAP@0.5'])
        axes[0, 0].set_title('mAP@0.5 Comparison')
        axes[0, 0].set_ylabel('mAP@0.5')
        axes[0, 0].tick_params(axis='x', rotation=45)
        
        # Model size comparison
        axes[0, 1].bar(df['variant'], df['size_mb'])
        axes[0, 1].set_title('Model Size Comparison')
        axes[0, 1].set_ylabel('Size (MB)')
        axes[0, 1].tick_params(axis='x', rotation=45)
        
        # Parameters comparison
        axes[1, 0].bar(df['variant'], df['total_params'] / 1e6)
        axes[1, 0].set_title('Parameters Comparison')
        axes[1, 0].set_ylabel('Parameters (M)')
        axes[1, 0].tick_params(axis='x', rotation=45)
        
        # Accuracy vs Size scatter
        axes[1, 1].scatter(df['size_mb'], df['mAP@0.5'])
        for i, variant in enumerate(df['variant']):
            axes[1, 1].annotate(variant, (df['size_mb'].iloc[i], df['mAP@0.5'].iloc[i]))
        axes[1, 1].set_xlabel('Model Size (MB)')
        axes[1, 1].set_ylabel('mAP@0.5')
        axes[1, 1].set_title('Accuracy vs Model Size')
        
        plt.tight_layout()
        plt.savefig(self.exp_dir / 'model_variants_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_ablation_study(self, results: List[Dict]):
        """Plot ablation study results"""
        df = pd.DataFrame(results)
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        fig.suptitle('SF-YOLO11 Ablation Study', fontsize=16)
        
        # mAP comparison
        colors = ['green' if comp == 'baseline' else 'red' for comp in df['component']]
        bars = ax1.bar(df['component'], df['mAP@0.5'], color=colors, alpha=0.7)
        ax1.set_title('mAP@0.5 by Component')
        ax1.set_ylabel('mAP@0.5')
        ax1.tick_params(axis='x', rotation=45)
        
        # Add value labels on bars
        for bar, value in zip(bars, df['mAP@0.5']):
            ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                    f'{value:.3f}', ha='center', va='bottom')
        
        # Performance drop
        df_drop = df[df['component'] != 'baseline']
        if not df_drop.empty:
            ax2.bar(df_drop['component'], df_drop['performance_drop'], color='red', alpha=0.7)
            ax2.set_title('Performance Drop without Component')
            ax2.set_ylabel('mAP@0.5 Drop')
            ax2.tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.savefig(self.exp_dir / 'ablation_study.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_pruning_analysis(self, results: List[Dict]):
        """Plot pruning analysis results"""
        df = pd.DataFrame(results)
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('SF-YOLO11 Pruning Analysis', fontsize=16)
        
        # Accuracy vs Sparsity
        axes[0, 0].plot(df['sparsity'], df['mAP@0.5'], 'o-')
        axes[0, 0].set_xlabel('Sparsity')
        axes[0, 0].set_ylabel('mAP@0.5')
        axes[0, 0].set_title('Accuracy vs Sparsity')
        axes[0, 0].grid(True)
        
        # Model Size vs Sparsity
        axes[0, 1].plot(df['sparsity'], df['size_mb'], 'o-', color='orange')
        axes[0, 1].set_xlabel('Sparsity')
        axes[0, 1].set_ylabel('Model Size (MB)')
        axes[0, 1].set_title('Model Size vs Sparsity')
        axes[0, 1].grid(True)
        
        # Accuracy vs Model Size
        axes[1, 0].scatter(df['size_mb'], df['mAP@0.5'])
        for i, method in enumerate(df['pruning_method']):
            axes[1, 0].annotate(method, (df['size_mb'].iloc[i], df['mAP@0.5'].iloc[i]))
        axes[1, 0].set_xlabel('Model Size (MB)')
        axes[1, 0].set_ylabel('mAP@0.5')
        axes[1, 0].set_title('Accuracy vs Model Size')
        axes[1, 0].grid(True)
        
        # Pruning methods comparison
        axes[1, 1].bar(df['pruning_method'], df['mAP@0.5'])
        axes[1, 1].set_title('Pruning Methods Comparison')
        axes[1, 1].set_ylabel('mAP@0.5')
        axes[1, 1].tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.savefig(self.exp_dir / 'pruning_analysis.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_benchmark_comparison(self, results: List[Dict]):
        """Plot benchmark comparison results"""
        df = pd.DataFrame(results)
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('Model Benchmark Comparison', fontsize=16)
        
        # Accuracy comparison
        colors = ['red' if 'sf_yolo11' in name.lower() else 'blue' for name in df['model_name']]
        axes[0, 0].bar(df['model_name'], df['mAP@0.5'], color=colors, alpha=0.7)
        axes[0, 0].set_title('mAP@0.5 Comparison')
        axes[0, 0].set_ylabel('mAP@0.5')
        axes[0, 0].tick_params(axis='x', rotation=45)
        
        # Speed comparison
        axes[0, 1].bar(df['model_name'], df['fps'], color=colors, alpha=0.7)
        axes[0, 1].set_title('Speed Comparison (FPS)')
        axes[0, 1].set_ylabel('FPS')
        axes[0, 1].tick_params(axis='x', rotation=45)
        
        # Model size comparison
        axes[1, 0].bar(df['model_name'], df['size_mb'], color=colors, alpha=0.7)
        axes[1, 0].set_title('Model Size Comparison')
        axes[1, 0].set_ylabel('Size (MB)')
        axes[1, 0].tick_params(axis='x', rotation=45)
        
        # Accuracy vs Speed scatter
        axes[1, 1].scatter(df['fps'], df['mAP@0.5'], c=colors, alpha=0.7, s=100)
        for i, name in enumerate(df['model_name']):
            axes[1, 1].annotate(name, (df['fps'].iloc[i], df['mAP@0.5'].iloc[i]))
        axes[1, 1].set_xlabel('FPS')
        axes[1, 1].set_ylabel('mAP@0.5')
        axes[1, 1].set_title('Accuracy vs Speed')
        axes[1, 1].grid(True)
        
        plt.tight_layout()
        plt.savefig(self.exp_dir / 'benchmark_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
    
    def generate_report(self):
        """Generate comprehensive experiment report"""
        report_path = self.exp_dir / 'experiment_report.md'
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(f"# SF-YOLO11 Experiment Report\n\n")
            f.write(f"**Generated on:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write(f"**Experiment ID:** {self.timestamp}\n\n")
            
            # Model variants results
            if self.results['experiments']:
                f.write("## Model Variants Experiment\n\n")
                df = pd.DataFrame(self.results['experiments'])
                f.write(df.to_markdown(index=False))
                f.write("\n\n")
            
            # Ablation study results
            if self.results['ablation_studies']:
                f.write("## Ablation Study\n\n")
                df = pd.DataFrame(self.results['ablation_studies'])
                f.write(df.to_markdown(index=False))
                f.write("\n\n")
            
            # Pruning analysis results
            if self.results['pruning_analysis']:
                f.write("## Pruning Analysis\n\n")
                df = pd.DataFrame(self.results['pruning_analysis'])
                f.write(df.to_markdown(index=False))
                f.write("\n\n")
            
            # Benchmark comparison results
            if self.results['benchmark_comparisons']:
                f.write("## Benchmark Comparison\n\n")
                df = pd.DataFrame(self.results['benchmark_comparisons'])
                f.write(df.to_markdown(index=False))
                f.write("\n\n")
            
            f.write("## Summary\n\n")
            f.write("This report contains comprehensive experimental results for SF-YOLO11 model evaluation.\n")
            f.write("All plots and detailed results are available in the experiment directory.\n")
        
        logger.info(f"Experiment report generated: {report_path}")
    
    def run_all_experiments(self):
        """Run all configured experiments"""
        logger.info("Starting comprehensive experiments...")
        
        experiments = self.config['experiments']
        
        if 'model_variants' in experiments:
            self.run_model_variants_experiment()
        
        if 'ablation_study' in experiments:
            self.run_ablation_study()
        
        if 'pruning_analysis' in experiments:
            self.run_pruning_analysis()
        
        if 'benchmark_comparison' in experiments:
            self.run_benchmark_comparison()
        
        # Generate final report
        self.generate_report()
        
        logger.info(f"All experiments completed. Results saved to: {self.exp_dir}")

def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='SF-YOLO11 Experiments Runner')
    parser.add_argument('--config', type=str, default='experiments/experiment_config.yaml',
                       help='Path to experiment configuration file')
    parser.add_argument('--output', type=str, default='experiments/results',
                       help='Output directory for results')
    parser.add_argument('--experiment', type=str, choices=['all', 'variants', 'ablation', 'pruning', 'benchmark'],
                       default='all', help='Specific experiment to run')
    parser.add_argument('--device', type=str, default='', help='Device to use (cuda:0, cpu, etc.)')
    
    return parser.parse_args()

def main():
    """Main function"""
    args = parse_args()
    
    # Initialize experiment runner
    runner = ExperimentRunner(args.config, args.output)
    
    # Override device if specified
    if args.device:
        runner.device = select_device(args.device)
    
    # Run specified experiments
    if args.experiment == 'all':
        runner.run_all_experiments()
    elif args.experiment == 'variants':
        runner.run_model_variants_experiment()
    elif args.experiment == 'ablation':
        runner.run_ablation_study()
    elif args.experiment == 'pruning':
        runner.run_pruning_analysis()
    elif args.experiment == 'benchmark':
        runner.run_benchmark_comparison()
    
    print(f"\n{colorstr('Experiments completed!')} Results saved to: {runner.exp_dir}")

if __name__ == '__main__':
    main()