"""
Detection Head for SF-YOLO11
===========================

This module implements the detection head for SF-YOLO11 with optimizations
for winter jujube detection, including anchor-free detection, multi-scale
feature processing, and small object enhancement.

Key Features:
1. Anchor-free detection with improved localization
2. Multi-scale feature integration
3. Small object enhancement mechanisms
4. Efficient classification and regression heads
5. Task-specific optimizations for winter jujube detection
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple, Dict, Optional
import math


class Conv(nn.Module):
    """Standard convolution with BatchNorm and activation"""
    
    def __init__(self, c1: int, c2: int, k: int = 1, s: int = 1, p: Optional[int] = None, 
                 g: int = 1, d: int = 1, act: bool = True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class DWConv(Conv):
    """Depthwise convolution"""
    def __init__(self, c1: int, c2: int, k: int = 1, s: int = 1, d: int = 1, act: bool = True):
        super().__init__(c1, c2, k, s, d=d, g=math.gcd(c1, c2), act=act)


class SmallObjectEnhancer(nn.Module):
    """Small object enhancement module for winter jujube detection"""
    
    def __init__(self, channels: int, enhancement_factor: float = 2.0):
        super().__init__()
        self.enhancement_factor = enhancement_factor
        
        # Multi-scale feature extraction for small objects
        self.small_scale_conv = Conv(channels, channels // 2, 3, 1, 1)
        self.micro_scale_conv = Conv(channels, channels // 4, 1, 1)
        
        # Attention mechanism for small object focus
        self.spatial_attention = nn.Sequential(
            nn.Conv2d(2, 1, 7, padding=3, bias=False),
            nn.Sigmoid()
        )
        
        # Feature fusion
        self.fusion_conv = Conv(channels + channels // 2 + channels // 4, channels, 1, 1)
        
    def forward(self, x):
        # Original features
        original = x
        
        # Multi-scale feature extraction
        small_scale = self.small_scale_conv(x)
        micro_scale = self.micro_scale_conv(x)
        
        # Spatial attention for small objects
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        attention_input = torch.cat([avg_out, max_out], dim=1)
        spatial_att = self.spatial_attention(attention_input)
        
        # Apply attention to enhance small object features
        enhanced_original = original * spatial_att * self.enhancement_factor
        
        # Concatenate and fuse features
        fused_features = torch.cat([enhanced_original, small_scale, micro_scale], dim=1)
        output = self.fusion_conv(fused_features)
        
        return output


class ClassificationHead(nn.Module):
    """Classification head with small object optimization"""
    
    def __init__(self, in_channels: int, num_classes: int, num_anchors: int = 1):
        super().__init__()
        self.num_classes = num_classes
        self.num_anchors = num_anchors
        
        # Small object enhancer
        self.enhancer = SmallObjectEnhancer(in_channels)
        
        # Classification layers
        self.cls_convs = nn.ModuleList([
            Conv(in_channels, in_channels, 3, 1, 1),
            Conv(in_channels, in_channels, 3, 1, 1),
        ])
        
        # Final classification layer
        self.cls_pred = nn.Conv2d(in_channels, num_anchors * num_classes, 1)
        
        # Initialize weights
        self._initialize_weights()
    
    def _initialize_weights(self):
        """Initialize classification head weights"""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight, std=0.01)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
        
        # Initialize classification bias for better convergence
        prior_prob = 0.01
        bias_value = -math.log((1 - prior_prob) / prior_prob)
        nn.init.constant_(self.cls_pred.bias, bias_value)
    
    def forward(self, x):
        # Enhance features for small objects
        x = self.enhancer(x)
        
        # Apply classification convolutions
        for cls_conv in self.cls_convs:
            x = cls_conv(x)
        
        # Final classification prediction
        cls_pred = self.cls_pred(x)
        
        return cls_pred


class RegressionHead(nn.Module):
    """Regression head for bounding box prediction"""
    
    def __init__(self, in_channels: int, num_anchors: int = 1):
        super().__init__()
        self.num_anchors = num_anchors
        
        # Small object enhancer
        self.enhancer = SmallObjectEnhancer(in_channels)
        
        # Regression layers
        self.reg_convs = nn.ModuleList([
            Conv(in_channels, in_channels, 3, 1, 1),
            Conv(in_channels, in_channels, 3, 1, 1),
        ])
        
        # Final regression layer (4 coordinates per anchor)
        self.reg_pred = nn.Conv2d(in_channels, num_anchors * 4, 1)
        
        # Initialize weights
        self._initialize_weights()
    
    def _initialize_weights(self):
        """Initialize regression head weights"""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight, std=0.01)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
    
    def forward(self, x):
        # Enhance features for small objects
        x = self.enhancer(x)
        
        # Apply regression convolutions
        for reg_conv in self.reg_convs:
            x = reg_conv(x)
        
        # Final regression prediction
        reg_pred = self.reg_pred(x)
        
        return reg_pred


class ObjectnessHead(nn.Module):
    """Objectness head for anchor-free detection"""
    
    def __init__(self, in_channels: int, num_anchors: int = 1):
        super().__init__()
        self.num_anchors = num_anchors
        
        # Objectness layers
        self.obj_convs = nn.ModuleList([
            Conv(in_channels, in_channels, 3, 1, 1),
            Conv(in_channels, in_channels, 3, 1, 1),
        ])
        
        # Final objectness layer
        self.obj_pred = nn.Conv2d(in_channels, num_anchors, 1)
        
        # Initialize weights
        self._initialize_weights()
    
    def _initialize_weights(self):
        """Initialize objectness head weights"""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight, std=0.01)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
    
    def forward(self, x):
        # Apply objectness convolutions
        for obj_conv in self.obj_convs:
            x = obj_conv(x)
        
        # Final objectness prediction
        obj_pred = self.obj_pred(x)
        
        return obj_pred


class DetectionHead(nn.Module):
    """
    Detection Head for SF-YOLO11
    
    Features:
    1. Anchor-free detection
    2. Multi-scale feature processing
    3. Small object enhancement
    4. Separate classification and regression heads
    5. Optimized for winter jujube detection
    """
    
    def __init__(self, in_channels: List[int], num_classes: int = 1, 
                 num_anchors: int = 1, use_objectness: bool = True):
        super().__init__()
        
        self.num_classes = num_classes
        self.num_anchors = num_anchors
        self.use_objectness = use_objectness
        self.num_levels = len(in_channels)
        
        # Ensure all feature levels have the same channel dimension
        self.lateral_convs = nn.ModuleList([
            Conv(in_ch, in_channels[0], 1, 1) if in_ch != in_channels[0] else nn.Identity()
            for in_ch in in_channels
        ])
        
        # Classification heads for each level
        self.cls_heads = nn.ModuleList([
            ClassificationHead(in_channels[0], num_classes, num_anchors)
            for _ in range(self.num_levels)
        ])
        
        # Regression heads for each level
        self.reg_heads = nn.ModuleList([
            RegressionHead(in_channels[0], num_anchors)
            for _ in range(self.num_levels)
        ])
        
        # Objectness heads (optional)
        if use_objectness:
            self.obj_heads = nn.ModuleList([
                ObjectnessHead(in_channels[0], num_anchors)
                for _ in range(self.num_levels)
            ])
        
        # Strides for each feature level
        self.strides = [8, 16, 32]  # P3, P4, P5
        
        # Prior generator for anchor-free detection
        self.prior_generator = self._create_prior_generator()
    
    def _create_prior_generator(self):
        """Create prior generator for anchor-free detection"""
        # This is a simplified version - in practice, you might use
        # more sophisticated prior generation
        return None
    
    def forward(self, features: List[torch.Tensor]) -> Tuple[List[torch.Tensor], List[torch.Tensor], Optional[List[torch.Tensor]]]:
        """
        Forward pass of detection head
        
        Args:
            features: List of feature maps from neck [P3, P4, P5]
            
        Returns:
            Tuple of (classifications, regressions, objectness)
        """
        assert len(features) == self.num_levels, f"Expected {self.num_levels} features, got {len(features)}"
        
        classifications = []
        regressions = []
        objectness = [] if self.use_objectness else None
        
        for i, feature in enumerate(features):
            # Apply lateral convolution if needed
            if not isinstance(self.lateral_convs[i], nn.Identity):
                feature = self.lateral_convs[i](feature)
            
            # Classification prediction
            cls_pred = self.cls_heads[i](feature)
            classifications.append(cls_pred)
            
            # Regression prediction
            reg_pred = self.reg_heads[i](feature)
            regressions.append(reg_pred)
            
            # Objectness prediction (if enabled)
            if self.use_objectness:
                obj_pred = self.obj_heads[i](feature)
                objectness.append(obj_pred)
        
        return classifications, regressions, objectness
    
    def decode_predictions(self, classifications: List[torch.Tensor], 
                          regressions: List[torch.Tensor],
                          objectness: Optional[List[torch.Tensor]] = None,
                          img_metas: Optional[List[Dict]] = None) -> List[Dict]:
        """
        Decode predictions to bounding boxes
        
        Args:
            classifications: Classification predictions
            regressions: Regression predictions  
            objectness: Objectness predictions (optional)
            img_metas: Image metadata
            
        Returns:
            List of detection results
        """
        # This is a placeholder for the decoding logic
        # In practice, you would implement proper decoding based on your
        # anchor-free detection strategy (e.g., FCOS, CenterNet style)
        
        results = []
        batch_size = classifications[0].shape[0]
        
        for batch_idx in range(batch_size):
            # Collect predictions from all levels
            batch_cls = [cls[batch_idx] for cls in classifications]
            batch_reg = [reg[batch_idx] for reg in regressions]
            batch_obj = [obj[batch_idx] for obj in objectness] if objectness else None
            
            # Decode predictions (simplified)
            detections = self._decode_single_image(batch_cls, batch_reg, batch_obj)
            results.append(detections)
        
        return results
    
    def _decode_single_image(self, classifications: List[torch.Tensor],
                           regressions: List[torch.Tensor],
                           objectness: Optional[List[torch.Tensor]] = None) -> Dict:
        """Decode predictions for a single image"""
        # Placeholder implementation
        # In practice, you would implement proper NMS and coordinate decoding
        
        all_boxes = []
        all_scores = []
        all_labels = []
        
        for level_idx, (cls_pred, reg_pred) in enumerate(zip(classifications, regressions)):
            # Get feature map dimensions
            h, w = cls_pred.shape[1:]
            
            # Generate grid points
            stride = self.strides[level_idx]
            grid_y, grid_x = torch.meshgrid(
                torch.arange(h, device=cls_pred.device) * stride,
                torch.arange(w, device=cls_pred.device) * stride,
                indexing='ij'
            )
            
            # Flatten predictions
            cls_pred = cls_pred.permute(1, 2, 0).reshape(-1, self.num_classes)
            reg_pred = reg_pred.permute(1, 2, 0).reshape(-1, 4)
            
            # Apply sigmoid to classification scores
            scores = torch.sigmoid(cls_pred)
            
            # Decode bounding boxes (simplified)
            grid_points = torch.stack([grid_x.flatten(), grid_y.flatten()], dim=1)
            boxes = self._decode_boxes(reg_pred, grid_points, stride)
            
            # Get best class scores and labels
            max_scores, labels = torch.max(scores, dim=1)
            
            # Filter by confidence threshold
            conf_threshold = 0.1
            valid_mask = max_scores > conf_threshold
            
            if valid_mask.sum() > 0:
                all_boxes.append(boxes[valid_mask])
                all_scores.append(max_scores[valid_mask])
                all_labels.append(labels[valid_mask])
        
        # Concatenate all levels
        if all_boxes:
            boxes = torch.cat(all_boxes, dim=0)
            scores = torch.cat(all_scores, dim=0)
            labels = torch.cat(all_labels, dim=0)
        else:
            boxes = torch.empty((0, 4), device=classifications[0].device)
            scores = torch.empty((0,), device=classifications[0].device)
            labels = torch.empty((0,), device=classifications[0].device, dtype=torch.long)
        
        return {
            'boxes': boxes,
            'scores': scores,
            'labels': labels
        }
    
    def _decode_boxes(self, reg_pred: torch.Tensor, grid_points: torch.Tensor, stride: int) -> torch.Tensor:
        """Decode regression predictions to bounding boxes"""
        # Simple decoding - in practice, you might use more sophisticated methods
        # reg_pred: [N, 4] (dx, dy, dw, dh)
        # grid_points: [N, 2] (x, y)
        
        dx, dy, dw, dh = reg_pred.unbind(dim=1)
        
        # Convert to absolute coordinates
        x_center = grid_points[:, 0] + dx * stride
        y_center = grid_points[:, 1] + dy * stride
        width = torch.exp(dw) * stride
        height = torch.exp(dh) * stride
        
        # Convert to x1, y1, x2, y2 format
        x1 = x_center - width / 2
        y1 = y_center - height / 2
        x2 = x_center + width / 2
        y2 = y_center + height / 2
        
        boxes = torch.stack([x1, y1, x2, y2], dim=1)
        return boxes
    
    def get_targets(self, gt_bboxes: List[torch.Tensor], gt_labels: List[torch.Tensor],
                   featmap_sizes: List[Tuple[int, int]]) -> Tuple[List[torch.Tensor], List[torch.Tensor]]:
        """Generate targets for training"""
        # This is a placeholder for target generation
        # In practice, you would implement proper target assignment
        # based on your anchor-free detection strategy
        
        cls_targets = []
        reg_targets = []
        
        for featmap_size in featmap_sizes:
            h, w = featmap_size
            # Create dummy targets
            cls_target = torch.zeros((len(gt_bboxes), self.num_classes, h, w))
            reg_target = torch.zeros((len(gt_bboxes), 4, h, w))
            
            cls_targets.append(cls_target)
            reg_targets.append(reg_target)
        
        return cls_targets, reg_targets


def autopad(k, p=None, d=1):
    """Auto-padding calculation"""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


if __name__ == "__main__":
    # Test detection head
    in_channels = [256, 512, 1024]  # P3, P4, P5
    num_classes = 1  # Winter jujube
    
    # Create detection head
    detection_head = DetectionHead(in_channels, num_classes, use_objectness=True)
    
    # Create dummy features
    features = [
        torch.randn(2, 256, 80, 80),   # P3
        torch.randn(2, 512, 40, 40),   # P4  
        torch.randn(2, 1024, 20, 20),  # P5
    ]
    
    # Forward pass
    classifications, regressions, objectness = detection_head(features)
    
    print("Detection Head Results:")
    for i, (cls, reg, obj) in enumerate(zip(classifications, regressions, objectness)):
        print(f"Level P{i+3}:")
        print(f"  Classification shape: {cls.shape}")
        print(f"  Regression shape: {reg.shape}")
        print(f"  Objectness shape: {obj.shape}")
    
    # Test decoding
    results = detection_head.decode_predictions(classifications, regressions, objectness)
    print(f"\nDecoded results for {len(results)} images:")
    for i, result in enumerate(results):
        print(f"Image {i}: {result['boxes'].shape[0]} detections")