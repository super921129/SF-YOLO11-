"""
ISSFF: Improved Sequential Scale Feature Fusion
==============================================

This module implements the ISSFF (Improved Sequential Scale Feature Fusion) mechanism
for enhanced multi-scale feature integration in winter jujube detection.

Key Features:
1. Sequential scale-aware feature fusion
2. Adaptive channel attention
3. Spatial attention for small object enhancement
4. Efficient feature pyramid construction
5. Cross-scale information flow optimization
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Dict, Optional, Tuple
import math


class Conv(nn.Module):
    """Standard convolution with BatchNorm and activation"""
    
    def __init__(self, c1: int, c2: int, k: int = 1, s: int = 1, p: Optional[int] = None, 
                 g: int = 1, d: int = 1, act: bool = True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class ChannelAttention(nn.Module):
    """Channel attention mechanism for feature recalibration"""
    
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        
        self.fc = nn.Sequential(
            nn.Conv2d(channels, channels // reduction, 1, bias=False),
            nn.SiLU(),
            nn.Conv2d(channels // reduction, channels, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return x * self.sigmoid(out)


class SpatialAttention(nn.Module):
    """Spatial attention mechanism for small object enhancement"""
    
    def __init__(self, kernel_size: int = 7):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=kernel_size//2, bias=False)
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        out = torch.cat([avg_out, max_out], dim=1)
        out = self.conv(out)
        return x * self.sigmoid(out)


class ScaleAwareAttention(nn.Module):
    """Scale-aware attention for multi-scale feature fusion"""
    
    def __init__(self, channels: int, num_scales: int = 3):
        super().__init__()
        self.num_scales = num_scales
        self.channels = channels
        
        # Scale-specific channel attention
        self.scale_attentions = nn.ModuleList([
            ChannelAttention(channels) for _ in range(num_scales)
        ])
        
        # Cross-scale attention
        self.cross_scale_conv = Conv(channels * num_scales, channels, 1)
        self.scale_weights = nn.Parameter(torch.ones(num_scales))
        self.softmax = nn.Softmax(dim=0)
    
    def forward(self, features: List[torch.Tensor]) -> torch.Tensor:
        """
        Args:
            features: List of feature maps from different scales
        Returns:
            Fused feature map
        """
        assert len(features) == self.num_scales, f"Expected {self.num_scales} features, got {len(features)}"
        
        # Apply scale-specific attention
        attended_features = []
        for i, (feat, attention) in enumerate(zip(features, self.scale_attentions)):
            attended_feat = attention(feat)
            attended_features.append(attended_feat)
        
        # Concatenate and fuse
        concat_features = torch.cat(attended_features, dim=1)
        fused_features = self.cross_scale_conv(concat_features)
        
        # Apply learnable scale weights
        weights = self.softmax(self.scale_weights)
        weighted_features = sum(w * feat for w, feat in zip(weights, attended_features))
        
        # Combine fused and weighted features
        output = fused_features + weighted_features
        
        return output


class FeaturePyramidBlock(nn.Module):
    """Feature pyramid block for multi-scale feature extraction"""
    
    def __init__(self, in_channels: int, out_channels: int, scales: List[int] = [1, 2, 4]):
        super().__init__()
        self.scales = scales
        
        # Multi-scale convolutions
        self.scale_convs = nn.ModuleList([
            Conv(in_channels, out_channels // len(scales), 3, 1, 
                 d=scale, p=scale) for scale in scales
        ])
        
        # Feature fusion
        self.fusion_conv = Conv(out_channels, out_channels, 1)
        
        # Spatial attention for small objects
        self.spatial_attention = SpatialAttention()
    
    def forward(self, x):
        # Multi-scale feature extraction
        scale_features = []
        for conv in self.scale_convs:
            scale_feat = conv(x)
            scale_features.append(scale_feat)
        
        # Concatenate multi-scale features
        concat_features = torch.cat(scale_features, dim=1)
        
        # Feature fusion
        fused_features = self.fusion_conv(concat_features)
        
        # Apply spatial attention
        output = self.spatial_attention(fused_features)
        
        return output


class CrossScaleConnection(nn.Module):
    """Cross-scale connection for information flow optimization"""
    
    def __init__(self, channels: int):
        super().__init__()
        self.top_down_conv = Conv(channels, channels, 1)
        self.bottom_up_conv = Conv(channels, channels, 1)
        self.lateral_conv = Conv(channels, channels, 1)
        
        # Adaptive fusion weights
        self.fusion_weights = nn.Parameter(torch.ones(3))  # top-down, bottom-up, lateral
        self.softmax = nn.Softmax(dim=0)
    
    def forward(self, top_feat: torch.Tensor, bottom_feat: torch.Tensor, 
                lateral_feat: torch.Tensor) -> torch.Tensor:
        """
        Args:
            top_feat: Feature from higher resolution level
            bottom_feat: Feature from lower resolution level  
            lateral_feat: Feature from current level
        Returns:
            Fused feature
        """
        # Resize features to match lateral feature size
        h, w = lateral_feat.shape[2:]
        
        if top_feat is not None:
            top_feat = F.interpolate(top_feat, size=(h, w), mode='bilinear', align_corners=False)
            top_feat = self.top_down_conv(top_feat)
        else:
            top_feat = torch.zeros_like(lateral_feat)
        
        if bottom_feat is not None:
            bottom_feat = F.interpolate(bottom_feat, size=(h, w), mode='bilinear', align_corners=False)
            bottom_feat = self.bottom_up_conv(bottom_feat)
        else:
            bottom_feat = torch.zeros_like(lateral_feat)
        
        lateral_feat = self.lateral_conv(lateral_feat)
        
        # Adaptive fusion
        weights = self.softmax(self.fusion_weights)
        fused_feat = (weights[0] * top_feat + 
                     weights[1] * bottom_feat + 
                     weights[2] * lateral_feat)
        
        return fused_feat


class ISSFF(nn.Module):
    """
    Improved Sequential Scale Feature Fusion
    
    Features:
    1. Sequential multi-scale feature fusion
    2. Scale-aware attention mechanism
    3. Cross-scale information flow
    4. Small object enhancement
    5. Efficient feature pyramid construction
    """
    
    def __init__(self, in_channels: List[int], out_channels: int = 256, 
                 num_levels: int = 3, use_attention: bool = True):
        super().__init__()
        
        self.num_levels = num_levels
        self.use_attention = use_attention
        
        # Input projection layers
        self.input_convs = nn.ModuleList([
            Conv(in_ch, out_channels, 1) for in_ch in in_channels
        ])
        
        # Feature pyramid blocks
        self.fpn_blocks = nn.ModuleList([
            FeaturePyramidBlock(out_channels, out_channels)
            for _ in range(num_levels)
        ])
        
        # Cross-scale connections
        self.cross_scale_connections = nn.ModuleList([
            CrossScaleConnection(out_channels)
            for _ in range(num_levels)
        ])
        
        # Scale-aware attention
        if use_attention:
            self.scale_attention = ScaleAwareAttention(out_channels, num_levels)
        
        # Output projection
        self.output_convs = nn.ModuleList([
            Conv(out_channels, out_channels, 3, 1, 1)
            for _ in range(num_levels)
        ])
        
        # Sequential fusion weights
        self.sequential_weights = nn.Parameter(torch.ones(num_levels))
        self.softmax = nn.Softmax(dim=0)
    
    def forward(self, features: List[torch.Tensor]) -> List[torch.Tensor]:
        """
        Args:
            features: List of input features from backbone [P3, P4, P5]
        Returns:
            List of enhanced multi-scale features
        """
        assert len(features) == self.num_levels, f"Expected {self.num_levels} features, got {len(features)}"
        
        # Input projection
        projected_features = []
        for feat, conv in zip(features, self.input_convs):
            projected_features.append(conv(feat))
        
        # Feature pyramid processing
        fpn_features = []
        for feat, fpn_block in zip(projected_features, self.fpn_blocks):
            fpn_feat = fpn_block(feat)
            fpn_features.append(fpn_feat)
        
        # Cross-scale connections
        enhanced_features = []
        for i, (feat, cross_conn) in enumerate(zip(fpn_features, self.cross_scale_connections)):
            # Get neighboring features
            top_feat = fpn_features[i-1] if i > 0 else None
            bottom_feat = fpn_features[i+1] if i < len(fpn_features)-1 else None
            
            # Apply cross-scale connection
            enhanced_feat = cross_conn(top_feat, bottom_feat, feat)
            enhanced_features.append(enhanced_feat)
        
        # Scale-aware attention fusion
        if self.use_attention:
            # Resize all features to the same size for attention
            target_size = enhanced_features[0].shape[2:]
            resized_features = []
            for feat in enhanced_features:
                if feat.shape[2:] != target_size:
                    feat = F.interpolate(feat, size=target_size, mode='bilinear', align_corners=False)
                resized_features.append(feat)
            
            # Apply scale-aware attention
            attention_output = self.scale_attention(resized_features)
            
            # Distribute attention output back to original scales
            for i in range(len(enhanced_features)):
                if enhanced_features[i].shape[2:] != target_size:
                    attention_feat = F.interpolate(attention_output, 
                                                 size=enhanced_features[i].shape[2:], 
                                                 mode='bilinear', align_corners=False)
                else:
                    attention_feat = attention_output
                
                # Sequential fusion with learnable weights
                weights = self.softmax(self.sequential_weights)
                enhanced_features[i] = enhanced_features[i] + weights[i] * attention_feat
        
        # Output projection
        output_features = []
        for feat, conv in zip(enhanced_features, self.output_convs):
            output_feat = conv(feat)
            output_features.append(output_feat)
        
        return output_features
    
    def get_fusion_weights(self) -> Dict[str, torch.Tensor]:
        """Get current fusion weights for analysis"""
        weights = {}
        
        # Sequential fusion weights
        weights['sequential'] = self.softmax(self.sequential_weights)
        
        # Scale attention weights
        if hasattr(self, 'scale_attention'):
            weights['scale_attention'] = self.softmax(self.scale_attention.scale_weights)
        
        # Cross-scale connection weights
        for i, conn in enumerate(self.cross_scale_connections):
            weights[f'cross_scale_{i}'] = self.softmax(conn.fusion_weights)
        
        return weights


class SimplifiedISSFF(nn.Module):
    """Simplified version of ISSFF for faster inference"""
    
    def __init__(self, in_channels: List[int], out_channels: int = 256):
        super().__init__()
        
        # Input projection
        self.input_convs = nn.ModuleList([
            Conv(in_ch, out_channels, 1) for in_ch in in_channels
        ])
        
        # Simple feature fusion
        self.fusion_conv = Conv(out_channels * len(in_channels), out_channels, 1)
        
        # Output convolutions
        self.output_convs = nn.ModuleList([
            Conv(out_channels, out_channels, 3, 1, 1)
            for _ in range(len(in_channels))
        ])
    
    def forward(self, features: List[torch.Tensor]) -> List[torch.Tensor]:
        # Project inputs
        projected = [conv(feat) for feat, conv in zip(features, self.input_convs)]
        
        # Resize to common size
        target_size = projected[0].shape[2:]
        resized = []
        for feat in projected:
            if feat.shape[2:] != target_size:
                feat = F.interpolate(feat, size=target_size, mode='bilinear', align_corners=False)
            resized.append(feat)
        
        # Fuse features
        fused = self.fusion_conv(torch.cat(resized, dim=1))
        
        # Generate outputs at different scales
        outputs = []
        for i, conv in enumerate(self.output_convs):
            if projected[i].shape[2:] != target_size:
                output = F.interpolate(fused, size=projected[i].shape[2:], 
                                     mode='bilinear', align_corners=False)
            else:
                output = fused
            outputs.append(conv(output))
        
        return outputs


def autopad(k, p=None, d=1):
    """Auto-padding calculation"""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


if __name__ == "__main__":
    # Test ISSFF module
    in_channels = [256, 512, 1024]  # P3, P4, P5
    features = [
        torch.randn(1, 256, 80, 80),   # P3
        torch.randn(1, 512, 40, 40),   # P4
        torch.randn(1, 1024, 20, 20),  # P5
    ]
    
    # Test full ISSFF
    issff = ISSFF(in_channels, out_channels=256, num_levels=3, use_attention=True)
    outputs = issff(features)
    
    print("ISSFF Results:")
    for i, out in enumerate(outputs):
        print(f"P{i+3} output shape: {out.shape}")
    
    # Test simplified version
    simple_issff = SimplifiedISSFF(in_channels, out_channels=256)
    simple_outputs = simple_issff(features)
    
    print("\nSimplified ISSFF Results:")
    for i, out in enumerate(simple_outputs):
        print(f"P{i+3} output shape: {out.shape}")
    
    # Get fusion weights
    weights = issff.get_fusion_weights()
    print(f"\nFusion weights: {weights}")