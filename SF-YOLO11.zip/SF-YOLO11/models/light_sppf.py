"""
LightSPPF: Lightweight Spatial Pyramid Pooling - Fast
=====================================================

This module implements the LightSPPF module optimized for winter jujube detection.
It uses adaptive pooling kernel combinations based on target scale distribution analysis.

Key Features:
1. Adaptive pooling kernel selection (3×3, 5×5, 7×7)
2. Optimized for small object detection (winter jujube)
3. Reduced computational overhead
4. Multi-scale feature fusion with attention mechanism
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple, Optional
import math


class Conv(nn.Module):
    """Standard convolution with BatchNorm and activation"""
    
    def __init__(self, c1: int, c2: int, k: int = 1, s: int = 1, p: Optional[int] = None, 
                 g: int = 1, d: int = 1, act: bool = True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        return self.act(self.conv(x))


class ChannelAttention(nn.Module):
    """Lightweight channel attention mechanism"""
    
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        
        self.fc = nn.Sequential(
            nn.Conv2d(channels, channels // reduction, 1, bias=False),
            nn.SiLU(),
            nn.Conv2d(channels // reduction, channels, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return x * self.sigmoid(out)


class AdaptivePooling(nn.Module):
    """Adaptive pooling with dynamic kernel selection"""
    
    def __init__(self, kernel_sizes: List[int] = [3, 5, 7], adaptive: bool = True):
        super().__init__()
        self.kernel_sizes = kernel_sizes
        self.adaptive = adaptive
        
        # Create pooling layers
        self.pools = nn.ModuleList([
            nn.MaxPool2d(kernel_size=k, stride=1, padding=k//2)
            for k in kernel_sizes
        ])
        
        # Learnable weights for kernel combination
        if adaptive:
            self.kernel_weights = nn.Parameter(torch.ones(len(kernel_sizes)))
            self.softmax = nn.Softmax(dim=0)
    
    def forward(self, x):
        if not self.adaptive:
            # Standard multi-scale pooling
            return [pool(x) for pool in self.pools]
        
        # Adaptive weighted pooling
        pooled_features = []
        weights = self.softmax(self.kernel_weights)
        
        for i, pool in enumerate(self.pools):
            pooled = pool(x)
            weighted_pooled = pooled * weights[i]
            pooled_features.append(weighted_pooled)
        
        return pooled_features


class LightSPPF(nn.Module):
    """
    Lightweight Spatial Pyramid Pooling - Fast
    
    Optimized for winter jujube detection with:
    - Adaptive pooling kernel selection
    - Reduced computational overhead
    - Multi-scale feature fusion
    - Channel attention mechanism
    """
    
    def __init__(self, c1: int, c2: int, k: int = 5, adaptive: bool = True, 
                 use_attention: bool = True, reduction_ratio: float = 0.5):
        super().__init__()
        
        c_ = int(c1 * reduction_ratio)  # hidden channels
        
        # Input projection
        self.cv1 = Conv(c1, c_, 1, 1)
        
        # Adaptive pooling with optimized kernel sizes for winter jujube
        # Based on target scale distribution: small (16-32), medium (32-64), large (64-128)
        self.kernel_sizes = [3, 5, 7] if k == 5 else [k, k+2, k+4]
        self.adaptive_pool = AdaptivePooling(self.kernel_sizes, adaptive=adaptive)
        
        # Channel attention
        self.use_attention = use_attention
        if use_attention:
            self.attention = ChannelAttention(c_, reduction=16)
        
        # Output projection
        # Input: original + 3 pooled features = 4 * c_
        self.cv2 = Conv(4 * c_, c2, 1, 1)
        
        # Lightweight residual connection
        self.shortcut = c1 == c2
        if not self.shortcut:
            self.residual_conv = Conv(c1, c2, 1, 1)
    
    def forward(self, x):
        # Store input for residual connection
        residual = x
        
        # Input projection
        x = self.cv1(x)
        
        # Multi-scale pooling
        pooled_features = self.adaptive_pool(x)
        
        # Concatenate original and pooled features
        features = [x] + pooled_features
        x = torch.cat(features, dim=1)
        
        # Apply channel attention
        if self.use_attention:
            x = self.attention(x)
        
        # Output projection
        x = self.cv2(x)
        
        # Add residual connection
        if self.shortcut:
            x = x + residual
        elif hasattr(self, 'residual_conv'):
            x = x + self.residual_conv(residual)
        
        return x
    
    def get_kernel_weights(self):
        """Get current adaptive kernel weights"""
        if hasattr(self.adaptive_pool, 'kernel_weights'):
            weights = self.adaptive_pool.softmax(self.adaptive_pool.kernel_weights)
            return {f'kernel_{k}': w.item() for k, w in zip(self.kernel_sizes, weights)}
        return None
    
    def set_kernel_weights(self, weights: List[float]):
        """Set adaptive kernel weights manually"""
        if hasattr(self.adaptive_pool, 'kernel_weights') and len(weights) == len(self.kernel_sizes):
            with torch.no_grad():
                self.adaptive_pool.kernel_weights.copy_(torch.tensor(weights))


class SPPF(nn.Module):
    """Original SPPF for comparison"""
    
    def __init__(self, c1: int, c2: int, k: int = 5):
        super().__init__()
        c_ = c1 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)

    def forward(self, x):
        x = self.cv1(x)
        y1 = self.m(x)
        y2 = self.m(y1)
        return self.cv2(torch.cat((x, y1, y2, self.m(y2)), 1))


class MultiScaleSPPF(nn.Module):
    """Multi-scale SPPF with different kernel sizes"""
    
    def __init__(self, c1: int, c2: int, kernels: List[int] = [3, 5, 7]):
        super().__init__()
        c_ = c1 // 2
        self.cv1 = Conv(c1, c_, 1, 1)
        
        # Multiple pooling branches
        self.pools = nn.ModuleList([
            nn.MaxPool2d(kernel_size=k, stride=1, padding=k//2)
            for k in kernels
        ])
        
        # Output projection
        self.cv2 = Conv(c_ * (len(kernels) + 1), c2, 1, 1)
    
    def forward(self, x):
        x = self.cv1(x)
        features = [x]
        
        for pool in self.pools:
            features.append(pool(x))
        
        return self.cv2(torch.cat(features, 1))


class OptimizedLightSPPF(LightSPPF):
    """
    Optimized version of LightSPPF with additional features:
    - Dynamic kernel selection based on input resolution
    - Efficient feature fusion
    - Memory-optimized implementation
    """
    
    def __init__(self, c1: int, c2: int, k: int = 5, min_resolution: int = 32):
        super().__init__(c1, c2, k, adaptive=True, use_attention=True)
        self.min_resolution = min_resolution
        
        # Dynamic kernel selection based on input size
        self.dynamic_kernels = True
        
    def forward(self, x):
        # Dynamic kernel selection based on input resolution
        if self.dynamic_kernels and self.training:
            h, w = x.shape[2:]
            if min(h, w) < self.min_resolution:
                # Use smaller kernels for low resolution
                self.adaptive_pool.kernel_sizes = [3, 5]
            elif min(h, w) > 2 * self.min_resolution:
                # Use larger kernels for high resolution
                self.adaptive_pool.kernel_sizes = [5, 7, 9]
            else:
                # Standard kernels
                self.adaptive_pool.kernel_sizes = [3, 5, 7]
        
        return super().forward(x)


def autopad(k, p=None, d=1):
    """Auto-padding calculation"""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


def compare_sppf_variants():
    """Compare different SPPF variants"""
    c1, c2 = 512, 512
    x = torch.randn(1, c1, 32, 32)
    
    models = {
        'Original SPPF': SPPF(c1, c2),
        'LightSPPF': LightSPPF(c1, c2),
        'MultiScale SPPF': MultiScaleSPPF(c1, c2),
        'Optimized LightSPPF': OptimizedLightSPPF(c1, c2)
    }
    
    results = {}
    for name, model in models.items():
        model.eval()
        with torch.no_grad():
            # Measure inference time
            import time
            start = time.time()
            for _ in range(100):
                out = model(x)
            end = time.time()
            
            # Calculate parameters and FLOPs
            params = sum(p.numel() for p in model.parameters())
            
            results[name] = {
                'output_shape': out.shape,
                'parameters': params,
                'inference_time': (end - start) / 100 * 1000,  # ms
            }
    
    return results


if __name__ == "__main__":
    # Test LightSPPF module
    model = LightSPPF(512, 512, k=5, adaptive=True, use_attention=True)
    x = torch.randn(1, 512, 32, 32)
    
    # Forward pass
    model.train()
    out = model(x)
    print(f"Input shape: {x.shape}")
    print(f"Output shape: {out.shape}")
    
    # Check adaptive kernel weights
    weights = model.get_kernel_weights()
    if weights:
        print(f"Adaptive kernel weights: {weights}")
    
    # Compare variants
    print("\nComparing SPPF variants:")
    comparison = compare_sppf_variants()
    for name, stats in comparison.items():
        print(f"{name}:")
        print(f"  Parameters: {stats['parameters']:,}")
        print(f"  Inference time: {stats['inference_time']:.2f} ms")
        print(f"  Output shape: {stats['output_shape']}")
        print()