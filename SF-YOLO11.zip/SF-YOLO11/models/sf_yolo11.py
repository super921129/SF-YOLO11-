"""
SF-YOLO11: Lightweight Multi-Scale Fusion Model for Real-time Winter Jujube Detection
=====================================================================================

This module implements the main SF-YOLO11 architecture with:
1. Adaptive structured pruning strategy
2. Lightweight LightSPPF module  
3. Improved Sequential Scale Feature Fusion (ISSFF)

Based on YOLO11n with optimizations for edge deployment and small object detection.
"""

import torch
import torch.nn as nn
from typing import List, Dict, Optional, Tuple
import yaml

from .pruned_c3k2 import PrunedC3K2
from .light_sppf import LightSPPF
from .issff import ISSFF
from .detection_head import DetectionHead


class SFYOLO11(nn.Module):
    """
    SF-YOLO11 Main Architecture
    
    Args:
        cfg (dict): Model configuration
        ch (int): Input channels, default 3
        nc (int): Number of classes
        anchors (Optional): Anchor boxes (not used in anchor-free version)
    """
    
    def __init__(self, cfg: Dict, ch: int = 3, nc: int = 1, anchors: Optional = None):
        super(SFYOLO11, self).__init__()
        
        self.cfg = cfg
        self.nc = nc  # number of classes
        self.ch = ch  # input channels
        
        # Build backbone
        self.backbone = self._build_backbone()
        
        # Build neck with ISSFF
        self.neck = self._build_neck()
        
        # Build detection head
        self.head = DetectionHead(nc=nc, anchors=anchors)
        
        # Initialize weights
        self._initialize_weights()
    
    def _build_backbone(self) -> nn.ModuleList:
        """Build backbone network with PrunedC3K2 and LightSPPF"""
        layers = nn.ModuleList()
        
        # Stem layer
        layers.append(nn.Conv2d(self.ch, 64, 6, 2, 2))  # P1/2
        layers.append(nn.BatchNorm2d(64))
        layers.append(nn.SiLU(inplace=True))
        
        # Stage 1
        layers.append(nn.Conv2d(64, 128, 3, 2, 1))  # P2/4
        layers.append(nn.BatchNorm2d(128))
        layers.append(nn.SiLU(inplace=True))
        layers.append(PrunedC3K2(128, 128, n=2, shortcut=True, prune_ratio=0.5))
        
        # Stage 2  
        layers.append(nn.Conv2d(128, 256, 3, 2, 1))  # P3/8
        layers.append(nn.BatchNorm2d(256))
        layers.append(nn.SiLU(inplace=True))
        layers.append(PrunedC3K2(256, 256, n=2, shortcut=True, prune_ratio=0.5))
        
        # Stage 3
        layers.append(nn.Conv2d(256, 512, 3, 2, 1))  # P4/16
        layers.append(nn.BatchNorm2d(512))
        layers.append(nn.SiLU(inplace=True))
        layers.append(PrunedC3K2(512, 512, n=2, shortcut=True, prune_ratio=0.5))
        
        # Stage 4
        layers.append(nn.Conv2d(512, 1024, 3, 2, 1))  # P5/32
        layers.append(nn.BatchNorm2d(1024))
        layers.append(nn.SiLU(inplace=True))
        layers.append(PrunedC3K2(1024, 1024, n=2, shortcut=True, prune_ratio=0.5))
        
        # LightSPPF
        layers.append(LightSPPF(1024, 1024, k=5))
        
        return layers
    
    def _build_neck(self) -> ISSFF:
        """Build neck with Improved Sequential Scale Feature Fusion"""
        return ISSFF(
            in_channels=[256, 512, 1024],  # P3, P4, P5
            out_channels=[256, 512, 1024],
            num_scales=3
        )
    
    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        """
        Forward pass
        
        Args:
            x (torch.Tensor): Input tensor [B, C, H, W]
            
        Returns:
            List[torch.Tensor]: Multi-scale feature maps for detection
        """
        # Backbone forward
        features = []
        for i, layer in enumerate(self.backbone):
            x = layer(x)
            # Collect P3, P4, P5 features
            if i in [9, 13, 17]:  # After each PrunedC3K2 stage
                features.append(x)
        
        # Neck forward with ISSFF
        neck_features = self.neck(features)
        
        # Detection head forward
        outputs = self.head(neck_features)
        
        return outputs
    
    def _initialize_weights(self):
        """Initialize model weights"""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
    
    def fuse(self):
        """Fuse Conv2d + BatchNorm2d layers for inference optimization"""
        print('Fusing layers... ')
        for m in self.modules():
            if isinstance(m, (nn.Conv2d, nn.BatchNorm2d)) and hasattr(m, 'bn'):
                m.conv = fuse_conv_and_bn(m.conv, m.bn)
                delattr(m, 'bn')
                m.forward = m.forward_fuse
        return self
    
    @staticmethod
    def load_config(config_path: str) -> Dict:
        """Load model configuration from YAML file"""
        with open(config_path, 'r', encoding='utf-8') as f:
            cfg = yaml.safe_load(f)
        return cfg
    
    def get_model_info(self) -> Dict:
        """Get model information including parameters and FLOPs"""
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        
        return {
            'total_params': total_params,
            'trainable_params': trainable_params,
            'model_size_mb': total_params * 4 / 1024 / 1024,  # Assuming float32
            'num_classes': self.nc
        }


def fuse_conv_and_bn(conv: nn.Conv2d, bn: nn.BatchNorm2d) -> nn.Conv2d:
    """Fuse convolution and batch normalization layers"""
    fusedconv = nn.Conv2d(
        conv.in_channels,
        conv.out_channels,
        kernel_size=conv.kernel_size,
        stride=conv.stride,
        padding=conv.padding,
        groups=conv.groups,
        bias=True
    ).requires_grad_(False).to(conv.weight.device)

    # Prepare filters
    w_conv = conv.weight.clone().view(conv.out_channels, -1)
    w_bn = torch.diag(bn.weight.div(torch.sqrt(bn.eps + bn.running_var)))
    fusedconv.weight.copy_(torch.mm(w_bn, w_conv).view(fusedconv.weight.shape))

    # Prepare spatial bias
    b_conv = torch.zeros(conv.weight.size(0), device=conv.weight.device) if conv.bias is None else conv.bias
    b_bn = bn.bias - bn.weight.mul(bn.running_mean).div(torch.sqrt(bn.running_var + bn.eps))
    fusedconv.bias.copy_(torch.mm(w_bn, b_conv.reshape(-1, 1)).reshape(-1) + b_bn)

    return fusedconv


def create_sf_yolo11(config_path: str, num_classes: int = 1, pretrained: bool = False) -> SFYOLO11:
    """
    Create SF-YOLO11 model
    
    Args:
        config_path (str): Path to model configuration file
        num_classes (int): Number of classes
        pretrained (bool): Whether to load pretrained weights
        
    Returns:
        SFYOLO11: Model instance
    """
    cfg = SFYOLO11.load_config(config_path)
    model = SFYOLO11(cfg, nc=num_classes)
    
    if pretrained:
        # Load pretrained weights if available
        try:
            checkpoint = torch.load('weights/sf_yolo11n.pt', map_location='cpu')
            model.load_state_dict(checkpoint['model'], strict=False)
            print("Loaded pretrained weights successfully")
        except FileNotFoundError:
            print("Pretrained weights not found, using random initialization")
    
    return model


if __name__ == "__main__":
    # Test model creation
    model = create_sf_yolo11("../configs/sf_yolo11n.yaml", num_classes=1)
    
    # Test forward pass
    x = torch.randn(1, 3, 640, 640)
    outputs = model(x)
    
    print(f"Model info: {model.get_model_info()}")
    print(f"Output shapes: {[out.shape for out in outputs]}")