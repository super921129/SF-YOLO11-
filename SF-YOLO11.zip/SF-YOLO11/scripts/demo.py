#!/usr/bin/env python3
"""
SF-YOLO11 Inference Demo Script
==============================

This script provides an interactive demo for SF-YOLO11 winter jujube detection,
supporting various input sources including images, videos, webcam, and real-time streams.

Usage:
    python scripts/demo.py --weights weights/best.pt --source demo.jpg
    python scripts/demo.py --weights weights/sf_yolo11n.pt --source 0  # webcam
    python scripts/demo.py --weights weights/pruned_model.pt --source video.mp4 --save-vid

Author: SF-YOLO11 Research Team
"""

import argparse
import cv2
import os
import sys
import time
from pathlib import Path
import threading
import queue

import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
import yaml

# Add project root to path
FILE = Path(__file__).resolve()
ROOT = FILE.parents[1]  # SF-YOLO11 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

# Import SF-YOLO11 modules
from models.sf_yolo11 import SFYOLO11
from utils.general import (
    set_logging, check_requirements, colorstr, increment_path,
    non_max_suppression, scale_coords, xyxy2xywh, clip_coords,
    yaml_load, make_dirs, check_img_size, letterbox
)
from utils.torch_utils import select_device, time_sync
from utils.plots import Annotator, colors


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='SF-YOLO11 Inference Demo')
    
    # Model and source
    parser.add_argument('--weights', type=str, required=True,
                       help='Model weights path')
    parser.add_argument('--source', type=str, default='0',
                       help='Source: file/dir/URL/glob, 0 for webcam')
    parser.add_argument('--model-config', type=str, default='configs/sf_yolo11n.yaml',
                       help='Model configuration file')
    
    # Inference parameters
    parser.add_argument('--img-size', type=int, default=640,
                       help='Input image size')
    parser.add_argument('--conf-thres', type=float, default=0.25,
                       help='Confidence threshold')
    parser.add_argument('--iou-thres', type=float, default=0.45,
                       help='NMS IoU threshold')
    parser.add_argument('--max-det', type=int, default=1000,
                       help='Maximum detections per image')
    
    # Hardware configuration
    parser.add_argument('--device', default='',
                       help='CUDA device, i.e. 0 or 0,1,2,3 or cpu')
    
    # Display options
    parser.add_argument('--view-img', action='store_true', default=True,
                       help='Show results')
    parser.add_argument('--save-img', action='store_true',
                       help='Save results')
    parser.add_argument('--save-vid', action='store_true',
                       help='Save video results')
    parser.add_argument('--hide-labels', action='store_true',
                       help='Hide labels')
    parser.add_argument('--hide-conf', action='store_true',
                       help='Hide confidences')
    parser.add_argument('--line-thickness', type=int, default=3,
                       help='Bounding box thickness (pixels)')
    
    # Save options
    parser.add_argument('--project', type=str, default='runs/demo',
                       help='Save results to project/name')
    parser.add_argument('--name', type=str, default='exp',
                       help='Save results to project/name')
    parser.add_argument('--exist-ok', action='store_true',
                       help='Existing project/name ok, do not increment')
    
    # Advanced options
    parser.add_argument('--half', action='store_true',
                       help='Use FP16 half-precision inference')
    parser.add_argument('--augment', action='store_true',
                       help='Augmented inference')
    parser.add_argument('--agnostic-nms', action='store_true',
                       help='Class-agnostic NMS')
    
    # Demo specific options
    parser.add_argument('--fps-limit', type=int, default=30,
                       help='FPS limit for video processing')
    parser.add_argument('--show-fps', action='store_true', default=True,
                       help='Show FPS counter')
    parser.add_argument('--show-count', action='store_true', default=True,
                       help='Show detection count')
    
    return parser.parse_args()


class SFYOLO11Demo:
    """SF-YOLO11 Demo class for real-time inference."""
    
    def __init__(self, args):
        """Initialize demo."""
        self.args = args
        self.device = select_device(args.device)
        self.half = args.half and self.device.type != 'cpu'
        
        # Load model
        self.model = self.load_model()
        
        # Class names
        self.names = {0: 'winter_jujube'}
        self.colors = colors(len(self.names), True)
        
        # Statistics
        self.fps_counter = 0
        self.fps_start_time = time.time()
        self.current_fps = 0.0
        
        # Create save directory if needed
        if args.save_img or args.save_vid:
            self.save_dir = increment_path(Path(args.project) / args.name, exist_ok=args.exist_ok)
            make_dirs(self.save_dir)
        else:
            self.save_dir = None
    
    def load_model(self):
        """Load SF-YOLO11 model."""
        print(f"{colorstr('Model:')} Loading model from {self.args.weights}")
        
        # Load checkpoint
        ckpt = torch.load(self.args.weights, map_location=self.device)
        
        # Load model configuration
        if self.args.model_config and os.path.exists(self.args.model_config):
            with open(self.args.model_config, 'r') as f:
                model_config = yaml.safe_load(f)
        else:
            # Try to get config from checkpoint
            model_config = ckpt.get('config', {'nc': 1})
        
        # Create model
        model = SFYOLO11(config=model_config)
        
        # Load state dict
        if 'model' in ckpt:
            state_dict = ckpt['model']
        elif 'state_dict' in ckpt:
            state_dict = ckpt['state_dict']
        else:
            state_dict = ckpt
        
        # Load weights
        model.load_state_dict(state_dict, strict=False)
        model = model.to(self.device)
        
        # Set to evaluation mode
        model.eval()
        
        # Convert to half precision if requested
        if self.half:
            model.half()
        
        # Print model info
        n_params = sum(p.numel() for p in model.parameters())
        print(f"{colorstr('Model:')} {n_params:,} parameters loaded")
        
        return model
    
    def preprocess_image(self, img0):
        """Preprocess image for inference."""
        # Letterbox
        img = letterbox(img0, self.args.img_size, stride=32, auto=True)[0]
        
        # Convert
        img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
        img = np.ascontiguousarray(img)
        
        # To tensor
        img = torch.from_numpy(img).to(self.device)
        img = img.half() if self.half else img.float()  # uint8 to fp16/32
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        
        if img.ndimension() == 3:
            img = img.unsqueeze(0)
        
        return img
    
    def run_inference(self, img):
        """Run model inference."""
        with torch.no_grad():
            pred = self.model(img, augment=self.args.augment)[0]
        return pred
    
    def postprocess_detections(self, pred, img, img0):
        """Post-process model predictions."""
        # NMS
        pred = non_max_suppression(
            pred, self.args.conf_thres, self.args.iou_thres, 
            None, self.args.agnostic_nms, max_det=self.args.max_det
        )
        
        # Process detections
        detections = []
        for i, det in enumerate(pred):  # per image
            if len(det):
                # Rescale boxes from img_size to img0 size
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], img0.shape).round()
                
                # Convert to list format
                for *xyxy, conf, cls in reversed(det):
                    detections.append({
                        'bbox': [int(x) for x in xyxy],
                        'confidence': float(conf),
                        'class': int(cls),
                        'class_name': self.names[int(cls)]
                    })
        
        return detections
    
    def draw_detections(self, img0, detections):
        """Draw detections on image."""
        annotator = Annotator(img0, line_width=self.args.line_thickness, example=str(self.names))
        
        for det in detections:
            xyxy = det['bbox']
            conf = det['confidence']
            cls = det['class']
            
            # Label
            if self.args.hide_labels:
                label = None
            elif self.args.hide_conf:
                label = self.names[cls]
            else:
                label = f'{self.names[cls]} {conf:.2f}'
            
            # Draw box
            annotator.box_label(xyxy, label, color=self.colors[cls])
        
        return annotator.result()
    
    def add_info_overlay(self, img, detections, fps=None):
        """Add information overlay to image."""
        h, w = img.shape[:2]
        
        # Create overlay
        overlay = img.copy()
        
        # Add FPS counter
        if fps is not None and self.args.show_fps:
            fps_text = f'FPS: {fps:.1f}'
            cv2.putText(overlay, fps_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                       1, (0, 255, 0), 2, cv2.LINE_AA)
        
        # Add detection count
        if self.args.show_count:
            count_text = f'Detections: {len(detections)}'
            cv2.putText(overlay, count_text, (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 
                       1, (0, 255, 0), 2, cv2.LINE_AA)
        
        # Add model info
        model_text = f'SF-YOLO11 - Winter Jujube Detection'
        cv2.putText(overlay, model_text, (10, h - 20), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (255, 255, 255), 2, cv2.LINE_AA)
        
        return overlay
    
    def update_fps(self):
        """Update FPS counter."""
        self.fps_counter += 1
        current_time = time.time()
        
        if current_time - self.fps_start_time >= 1.0:
            self.current_fps = self.fps_counter / (current_time - self.fps_start_time)
            self.fps_counter = 0
            self.fps_start_time = current_time
    
    def process_image(self, img0):
        """Process single image."""
        # Preprocess
        img = self.preprocess_image(img0)
        
        # Inference
        t1 = time_sync()
        pred = self.run_inference(img)
        t2 = time_sync()
        
        # Post-process
        detections = self.postprocess_detections(pred, img, img0)
        
        # Draw results
        img_result = self.draw_detections(img0.copy(), detections)
        
        # Add info overlay
        img_result = self.add_info_overlay(img_result, detections, self.current_fps)
        
        # Update FPS
        self.update_fps()
        
        inference_time = (t2 - t1) * 1000  # ms
        
        return img_result, detections, inference_time
    
    def run_image_demo(self):
        """Run demo on single image."""
        print(f"{colorstr('Demo:')} Processing image {self.args.source}")
        
        # Load image
        img0 = cv2.imread(self.args.source)
        if img0 is None:
            print(f"Error: Could not load image {self.args.source}")
            return
        
        # Process image
        img_result, detections, inference_time = self.process_image(img0)
        
        # Print results
        print(f"Inference time: {inference_time:.1f}ms")
        print(f"Detections: {len(detections)} winter jujube(s)")
        
        # Save result
        if self.save_dir:
            save_path = self.save_dir / f'result_{Path(self.args.source).name}'
            cv2.imwrite(str(save_path), img_result)
            print(f"Result saved to {save_path}")
        
        # Display result
        if self.args.view_img:
            cv2.imshow('SF-YOLO11 Demo', img_result)
            cv2.waitKey(0)
            cv2.destroyAllWindows()
    
    def run_video_demo(self):
        """Run demo on video file or webcam."""
        # Open video source
        if self.args.source.isdigit():
            cap = cv2.VideoCapture(int(self.args.source))
            source_type = 'webcam'
        else:
            cap = cv2.VideoCapture(self.args.source)
            source_type = 'video'
        
        if not cap.isOpened():
            print(f"Error: Could not open {source_type} {self.args.source}")
            return
        
        # Get video properties
        fps = cap.get(cv2.CAP_PROP_FPS)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        print(f"{colorstr('Demo:')} Processing {source_type} {self.args.source}")
        print(f"Resolution: {w}x{h}, FPS: {fps}")
        
        # Set up video writer
        vid_writer = None
        if self.args.save_vid and self.save_dir:
            save_path = self.save_dir / f'result_{Path(self.args.source).stem}.mp4'
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            vid_writer = cv2.VideoWriter(str(save_path), fourcc, fps, (w, h))
        
        # FPS limiting
        frame_time = 1.0 / self.args.fps_limit if self.args.fps_limit > 0 else 0
        
        frame_count = 0
        total_detections = 0
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                start_time = time.time()
                
                # Process frame
                img_result, detections, inference_time = self.process_frame(frame)
                
                frame_count += 1
                total_detections += len(detections)
                
                # Save frame
                if vid_writer is not None:
                    vid_writer.write(img_result)
                
                # Display frame
                if self.args.view_img:
                    cv2.imshow('SF-YOLO11 Demo', img_result)
                    
                    # Handle key presses
                    key = cv2.waitKey(1) & 0xFF
                    if key == ord('q'):
                        break
                    elif key == ord('s') and self.save_dir:
                        # Save current frame
                        save_path = self.save_dir / f'frame_{frame_count:06d}.jpg'
                        cv2.imwrite(str(save_path), img_result)
                        print(f"Frame saved to {save_path}")
                
                # FPS limiting
                if frame_time > 0:
                    elapsed = time.time() - start_time
                    if elapsed < frame_time:
                        time.sleep(frame_time - elapsed)
        
        except KeyboardInterrupt:
            print(f"\n{colorstr('Demo:')} Interrupted by user")
        
        finally:
            # Cleanup
            cap.release()
            if vid_writer is not None:
                vid_writer.release()
            cv2.destroyAllWindows()
            
            # Print statistics
            print(f"\n{colorstr('Statistics:')}")
            print(f"Frames processed: {frame_count}")
            print(f"Total detections: {total_detections}")
            print(f"Average detections per frame: {total_detections/frame_count:.1f}")
    
    def process_frame(self, frame):
        """Process single video frame."""
        return self.process_image(frame)
    
    def run(self):
        """Run demo based on source type."""
        # Check if source is image or video
        if os.path.isfile(self.args.source):
            # Check file extension
            ext = Path(self.args.source).suffix.lower()
            if ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif']:
                self.run_image_demo()
            else:
                self.run_video_demo()
        else:
            # Webcam or video stream
            self.run_video_demo()


def main():
    """Main demo function."""
    # Parse arguments
    args = parse_args()
    
    # Set up logging
    set_logging()
    
    # Check requirements
    check_requirements(['opencv-python', 'pillow'])
    
    # Create and run demo
    demo = SFYOLO11Demo(args)
    
    print(f"\n{colorstr('SF-YOLO11 Demo:')} Starting inference demo...")
    print(f"{colorstr('Model:')} {args.weights}")
    print(f"{colorstr('Source:')} {args.source}")
    print(f"{colorstr('Device:')} {demo.device}")
    
    # Add instructions
    if args.view_img:
        print(f"\n{colorstr('Instructions:')}")
        print("  - Press 'q' to quit")
        print("  - Press 's' to save current frame (video mode)")
    
    try:
        demo.run()
    except Exception as e:
        print(f"{colorstr('Error:')} {e}")
    
    print(f"\n{colorstr('Demo:')} Completed successfully!")


if __name__ == '__main__':
    main()