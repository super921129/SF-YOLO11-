#!/usr/bin/env python3
"""
SF-YOLO11 Model Export Script
============================

This script exports SF-YOLO11 models to various formats including ONNX, TensorRT, 
CoreML, and TensorFlow for deployment on different platforms.

Usage:
    python scripts/export.py --weights weights/best.pt --include onnx
    python scripts/export.py --weights weights/sf_yolo11n.pt --include onnx tensorrt --device 0
    python scripts/export.py --weights weights/pruned_model.pt --include coreml --img-size 640

Author: SF-YOLO11 Research Team
"""

import argparse
import json
import os
import platform
import subprocess
import sys
import time
import warnings
from pathlib import Path

import pandas as pd
import torch
import torch.nn as nn
from torch.utils.mobile_optimizer import optimize_for_mobile

# Add project root to path
FILE = Path(__file__).resolve()
ROOT = FILE.parents[1]  # SF-YOLO11 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

# Import SF-YOLO11 modules
from models.sf_yolo11 import SFYOLO11
from utils.general import (
    set_logging, check_requirements, colorstr, file_size,
    yaml_load, make_dirs, check_version
)
from utils.torch_utils import select_device


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='SF-YOLO11 Model Export')
    
    # Model configuration
    parser.add_argument('--weights', type=str, required=True,
                       help='Model weights path')
    parser.add_argument('--img-size', nargs='+', type=int, default=[640, 640],
                       help='Image size (height, width)')
    parser.add_argument('--batch-size', type=int, default=1,
                       help='Batch size')
    
    # Export formats
    parser.add_argument('--include', nargs='+',
                       default=['torchscript'],
                       help='Available formats: torchscript, onnx, openvino, engine, coreml, saved_model, pb, tflite, edgetpu, tfjs, paddle')
    
    # Hardware configuration
    parser.add_argument('--device', default='cpu',
                       help='CUDA device, i.e. 0 or 0,1,2,3 or cpu')
    
    # Export options
    parser.add_argument('--half', action='store_true',
                       help='FP16 half-precision export')
    parser.add_argument('--inplace', action='store_true',
                       help='Set YOLO Detect() inplace=True')
    parser.add_argument('--keras', action='store_true',
                       help='TF: use Keras')
    parser.add_argument('--optimize', action='store_true',
                       help='TorchScript: optimize for mobile')
    parser.add_argument('--int8', action='store_true',
                       help='CoreML/TF INT8 quantization')
    parser.add_argument('--dynamic', action='store_true',
                       help='ONNX/TF/TensorRT: dynamic axes')
    parser.add_argument('--simplify', action='store_true',
                       help='ONNX: simplify model')
    parser.add_argument('--opset', type=int, default=12,
                       help='ONNX: opset version')
    parser.add_argument('--verbose', action='store_true',
                       help='TensorRT: verbose log')
    parser.add_argument('--workspace', type=int, default=4,
                       help='TensorRT: workspace size (GB)')
    parser.add_argument('--nms', action='store_true',
                       help='TF: add NMS to model')
    parser.add_argument('--agnostic-nms', action='store_true',
                       help='TF: add agnostic NMS to model')
    parser.add_argument('--topk-per-class', type=int, default=100,
                       help='TF.js NMS: topk per class to keep')
    parser.add_argument('--topk-all', type=int, default=100,
                       help='TF.js NMS: topk for all classes to keep')
    parser.add_argument('--iou-thres', type=float, default=0.45,
                       help='TF.js NMS: IoU threshold')
    parser.add_argument('--conf-thres', type=float, default=0.25,
                       help='TF.js NMS: confidence threshold')
    
    return parser.parse_args()


def export_torchscript(model, im, file, optimize):
    """Export model to TorchScript format."""
    print(f'\n{colorstr("TorchScript:")} starting export with torch {torch.__version__}...')
    f = file.with_suffix('.torchscript')
    
    ts = torch.jit.trace(model, im, strict=False)
    d = {"shape": im.shape, "stride": int(max(model.stride)), "names": model.names}
    extra_files = {'config.txt': json.dumps(d)}  # torch._C.ExtraFilesMap()
    
    if optimize:  # https://pytorch.org/tutorials/recipes/mobile_interpreter.html
        optimize_for_mobile(ts)._save_for_lite_interpreter(str(f), _extra_files=extra_files)
    else:
        ts.save(str(f), _extra_files=extra_files)
    
    print(f'{colorstr("TorchScript:")} export success, saved as {f} ({file_size(f):.1f} MB)')
    return f


def export_onnx(model, im, file, opset, dynamic, simplify, prefix=colorstr('ONNX:')):
    """Export model to ONNX format."""
    check_requirements('onnx')
    import onnx
    
    print(f'\n{prefix} starting export with onnx {onnx.__version__}...')
    f = file.with_suffix('.onnx')
    
    torch.onnx.export(
        model.cpu() if dynamic else model,  # --dynamic only compatible with cpu
        im.cpu() if dynamic else im,
        f,
        verbose=False,
        opset_version=opset,
        do_constant_folding=True,
        input_names=['images'],
        output_names=['output'],
        dynamic_axes={
            'images': {0: 'batch', 2: 'height', 3: 'width'},  # shape(1,3,640,640)
            'output': {0: 'batch', 1: 'anchors'}  # shape(1,25200,85)
        } if dynamic else None)
    
    # Checks
    model_onnx = onnx.load(f)  # load onnx model
    onnx.checker.check_model(model_onnx)  # check onnx model
    
    # Simplify
    if simplify:
        try:
            check_requirements('onnxsim')
            import onnxsim
            
            print(f'{prefix} simplifying with onnx-simplifier {onnxsim.__version__}...')
            model_onnx, check = onnxsim.simplify(model_onnx)
            assert check, 'assert check failed'
            onnx.save(model_onnx, f)
        except Exception as e:
            print(f'{prefix} simplifier failure: {e}')
    
    print(f'{prefix} export success, saved as {f} ({file_size(f):.1f} MB)')
    return f


def export_openvino(file, metadata, half):
    """Export model to OpenVINO format."""
    check_requirements('openvino-dev')  # requires openvino-dev: https://pypi.org/project/openvino-dev/
    import openvino.inference_engine as ie
    
    print(f'\n{colorstr("OpenVINO:")} starting export with openvino {ie.__version__}...')
    f = str(file).replace('.onnx', f'_openvino_model{os.sep}')
    
    cmd = f"mo --input_model {file} --output_dir {f} --data_type {'FP16' if half else 'FP32'}"
    subprocess.run(cmd.split(), check=True, env=os.environ)  # export
    yaml_save(Path(f) / 'metadata.yaml', metadata)  # add metadata.yaml
    
    print(f'{colorstr("OpenVINO:")} export success, saved as {f} ({file_size(f):.1f} MB)')
    return f


def export_coreml(model, im, file, int8, half, prefix=colorstr('CoreML:')):
    """Export model to CoreML format."""
    check_requirements('coremltools')
    import coremltools as ct
    
    print(f'\n{prefix} starting export with coremltools {ct.__version__}...')
    f = file.with_suffix('.mlmodel')
    
    ts = torch.jit.trace(model, im, strict=False)  # TorchScript model
    ct_model = ct.convert(ts, inputs=[ct.ImageType('image', shape=im.shape, scale=1 / 255, bias=[0, 0, 0])])
    bits, mode = (8, 'kmeans_lut') if int8 else (16, 'linear') if half else (32, None)
    if bits < 32:
        if platform.system() == 'Darwin':  # quantization only supported on macOS
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=DeprecationWarning)  # suppress numpy warnings
                ct_model = ct.models.neural_network.quantization_utils.quantize_weights(ct_model, bits, mode)
        else:
            print(f'{prefix} quantization only supported on macOS, skipping...')
    ct_model.save(f)
    
    print(f'{prefix} export success, saved as {f} ({file_size(f):.1f} MB)')
    return ct_model, f


def export_engine(model, im, file, half, dynamic, simplify, workspace=4, verbose=False):
    """Export model to TensorRT format."""
    assert im.device.type != 'cpu', 'export running on CPU but must be on GPU, i.e. `python export.py --device 0`'
    try:
        import tensorrt as trt
    except Exception:
        if platform.system() == 'Linux':
            check_requirements('nvidia-tensorrt', cmds='-U --index-url https://pypi.ngc.nvidia.com')
        import tensorrt as trt
    
    if trt.__version__[0] == '7':  # TensorRT 7 handling https://github.com/ultralytics/yolov5/issues/6012
        grid = model.model[-1].anchor_grid
        model.model[-1].anchor_grid = [a[..., :1, :1, :] for a in grid]
        export_onnx(model, im, file, 12, dynamic, simplify)  # opset 12
        model.model[-1].anchor_grid = grid
    else:  # TensorRT >= 8
        check_requirements('onnx>=1.12.0')
        export_onnx(model, im, file, 12, dynamic, simplify)  # opset 12
    onnx = file.with_suffix('.onnx')
    
    print(f'\n{colorstr("TensorRT:")} starting export with TensorRT {trt.__version__}...')
    assert onnx.exists(), f'failed to export ONNX file: {onnx}'
    f = file.with_suffix('.engine')  # TensorRT engine file
    logger = trt.Logger(trt.Logger.INFO)
    if verbose:
        logger.min_severity = trt.Logger.Severity.VERBOSE
    
    builder = trt.Builder(logger)
    config = builder.create_builder_config()
    config.max_workspace_size = workspace * 1 << 30  # fix TRT 6.x exception
    
    flag = (1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
    network = builder.create_network(flag)
    parser = trt.OnnxParser(network, logger)
    if not parser.parse_from_file(str(onnx)):
        raise RuntimeError(f'failed to load ONNX file: {onnx}')
    
    inputs = [network.get_input(i) for i in range(network.num_inputs)]
    outputs = [network.get_output(i) for i in range(network.num_outputs)]
    print(f'{colorstr("TensorRT:")} Network Description:')
    for inp in inputs:
        print(f'{colorstr("TensorRT:")} input "{inp.name}" with shape {inp.shape} and dtype {inp.dtype}')
    for out in outputs:
        print(f'{colorstr("TensorRT:")} output "{out.name}" with shape {out.shape} and dtype {out.dtype}')
    
    if dynamic:
        if im.shape[0] <= 1:
            print(f"{colorstr('TensorRT:')} WARNING: --dynamic model requires maximum --batch-size argument")
        profile = builder.create_optimization_profile()
        for inp in inputs:
            profile.set_shape(inp.name, (1, *im.shape[1:]), (max(1, im.shape[0] // 2), *im.shape[1:]), im.shape)
        config.add_optimization_profile(profile)
    
    print(f'{colorstr("TensorRT:")} building FP{16 if builder.platform_has_fast_fp16 and half else 32} engine in {f}')
    if builder.platform_has_fast_fp16 and half:
        config.set_flag(trt.BuilderFlag.FP16)
    with builder.build_engine(network, config) as engine, open(f, 'wb') as t:
        t.write(engine.serialize())
    
    print(f'{colorstr("TensorRT:")} export success, saved as {f} ({file_size(f):.1f} MB)')
    return f


def export_saved_model(model, im, file, dynamic, tf_nms=False, agnostic_nms=False, topk_per_class=100,
                      topk_all=100, iou_thres=0.45, conf_thres=0.25, keras=False, prefix=colorstr('TensorFlow SavedModel:')):
    """Export model to TensorFlow SavedModel format."""
    # YOLOv5 TensorFlow export
    try:
        import tensorflow as tf
    except Exception:
        check_requirements(f"tensorflow{'' if torch.cuda.is_available() else '-cpu'}")
        import tensorflow as tf
    from tensorflow.python.framework.convert_to_constants import convert_variables_to_constants_v2
    
    print(f'\n{prefix} starting export with tensorflow {tf.__version__}...')
    f = str(file).replace('.pt', '_saved_model')
    batch_size, ch, *imgsz = im.shape  # BCHW
    
    tf_model = TFModel(cfg=model.yaml, model=model, nc=model.nc, imgsz=imgsz)
    im = tf.zeros((batch_size, *imgsz, ch))  # BHWC order for TensorFlow
    _ = tf_model.predict(im, tf_nms, agnostic_nms, topk_per_class, topk_all, iou_thres, conf_thres)
    inputs = tf.keras.Input(shape=(*imgsz, ch), batch_size=None if dynamic else batch_size)
    outputs = tf_model.predict(inputs, tf_nms, agnostic_nms, topk_per_class, topk_all, iou_thres, conf_thres)
    keras_model = tf.keras.Model(inputs=inputs, outputs=outputs)
    keras_model.trainable = False
    keras_model.summary()
    if keras:
        keras_model.save(f, save_format='tf')
    else:
        spec = tf.TensorSpec(keras_model.inputs[0].shape, keras_model.inputs[0].dtype)
        m = tf.function(lambda x: keras_model(x))  # full model
        m = m.get_concrete_function(spec)
        frozen_func = convert_variables_to_constants_v2(m)
        tfm = tf.Module()
        tfm.__call__ = tf.function(lambda x: frozen_func(x)[:4] if tf_nms else frozen_func(x), [spec])
        tfm.__call__(im)
        tf.saved_model.save(tfm, f, options=tf.saved_model.SaveOptions(experimental_custom_gradients=False)
                           if check_version(tf.__version__, '2.6') else tf.saved_model.SaveOptions())
    
    print(f'{prefix} export success, saved as {f} ({file_size(f):.1f} MB)')
    return keras_model, f


def run_benchmarks(model, img, half, device, n_runs=5):
    """Run inference benchmarks."""
    print(f'\n{colorstr("Benchmarks:")} Running inference benchmarks...')
    
    # Warmup
    for _ in range(3):
        with torch.no_grad():
            _ = model(img)
    
    # Benchmark
    times = []
    for _ in range(n_runs):
        t1 = time.time()
        with torch.no_grad():
            _ = model(img)
        if device.type == 'cuda':
            torch.cuda.synchronize()
        t2 = time.time()
        times.append(t2 - t1)
    
    times = torch.tensor(times)
    speed = times.mean().item()
    fps = 1.0 / speed
    
    print(f'{colorstr("Speed:")} {speed*1000:.1f}ms per image')
    print(f'{colorstr("FPS:")} {fps:.1f}')
    
    return speed, fps


def main():
    """Main export function."""
    # Parse arguments
    args = parse_args()
    
    # Set up logging
    set_logging()
    
    # Set up device
    device = select_device(args.device)
    
    # Load model
    print(f'{colorstr("PyTorch:")} starting from {args.weights} on {device}')
    
    # Load checkpoint
    ckpt = torch.load(args.weights, map_location=device)
    
    # Extract model configuration
    if 'config' in ckpt:
        model_config = ckpt['config']
    else:
        # Default configuration
        model_config = {'nc': 1}
    
    # Create model
    model = SFYOLO11(config=model_config)
    
    # Load state dict
    if 'model' in ckpt:
        state_dict = ckpt['model']
    elif 'state_dict' in ckpt:
        state_dict = ckpt['state_dict']
    else:
        state_dict = ckpt
    
    # Load weights
    model.load_state_dict(state_dict, strict=False)
    model = model.to(device)
    
    # Model info
    for k, v in model.named_parameters():
        v.requires_grad = False
    model.eval()
    
    # Input
    gs = int(max(model.stride))  # grid size (max stride)
    imgsz = [check_img_size(x, gs) for x in args.img_size]  # verify img_size are gs-multiples
    im = torch.zeros(args.batch_size, 3, *imgsz).to(device)  # image size(1,3,320,192) BCHW iDetection
    
    # Update model
    model.train() if args.optimize else model.eval()  # training mode = no Detect() layer grid construction
    for k, m in model.named_modules():
        if isinstance(m, (nn.Hardswish, nn.LeakyReLU, nn.ReLU, nn.ReLU6, nn.SiLU)):
            m.inplace = args.inplace
        elif isinstance(m, nn.Upsample) and not hasattr(m, 'recompute_scale_factor'):
            m.recompute_scale_factor = None  # torch 1.11.0 compatibility
    
    # Dry runs
    for _ in range(2):
        y = model(im)  # dry runs
    if args.half and not args.device == 'cpu':
        im, model = im.half(), model.half()  # to FP16
    
    shape = tuple((y[0] if isinstance(y, tuple) else y).shape)  # model output shape
    metadata = {'stride': int(max(model.stride)), 'names': model.names}  # model metadata
    print(f"\n{colorstr('PyTorch:')} model summary: {sum(x.numel() for x in model.parameters())} parameters, "
          f"{sum(x.numel() for x in model.parameters() if x.requires_grad)} gradients, "
          f"{sum(x.numel() for x in model.buffers())} buffers")
    
    # Exports
    f = Path(args.weights)  # filename
    exports = []
    
    # TorchScript
    if 'torchscript' in args.include:
        export_file = export_torchscript(model, im, f, args.optimize)
        exports.append(export_file)
    
    # ONNX
    if 'onnx' in args.include:
        export_file = export_onnx(model, im, f, args.opset, args.dynamic, args.simplify)
        exports.append(export_file)
    
    # OpenVINO
    if 'openvino' in args.include:
        export_file = export_openvino(f.with_suffix('.onnx'), metadata, args.half)
        exports.append(export_file)
    
    # TensorRT
    if 'engine' in args.include:
        export_file = export_engine(model, im, f, args.half, args.dynamic, args.simplify, args.workspace, args.verbose)
        exports.append(export_file)
    
    # CoreML
    if 'coreml' in args.include:
        _, export_file = export_coreml(model, im, f, args.int8, args.half)
        exports.append(export_file)
    
    # TensorFlow SavedModel
    if any(x in args.include for x in ['saved_model', 'pb', 'tflite', 'edgetpu', 'tfjs']):
        if 'pb' in args.include or 'tfjs' in args.include:
            args.keras = True
        _, export_file = export_saved_model(model, im, f, args.dynamic, tf_nms=args.nms or args.agnostic_nms,
                                          agnostic_nms=args.agnostic_nms, topk_per_class=args.topk_per_class,
                                          topk_all=args.topk_all, iou_thres=args.iou_thres,
                                          conf_thres=args.conf_thres, keras=args.keras)
        exports.append(export_file)
    
    # Run benchmarks
    if device.type != 'cpu':
        speed, fps = run_benchmarks(model, im, args.half, device)
    
    # Finish
    print(f'\nExport complete ({time.time() - t:.1f}s)'
          f"\nResults saved to {colorstr('bold', f.parent.resolve())}"
          f"\nDetect:          python detect.py --weights {f.with_suffix('.pt')}"
          f"\nValidate:        python val.py --weights {f.with_suffix('.pt')}"
          f"\nPyTorch Hub:     model = torch.hub.load('ultralytics/yolov5', 'custom', '{f.with_suffix('.pt')}')"
          f"\nVisualize:       https://netron.app")
    
    return exports  # return list of exported files/dirs


if __name__ == '__main__':
    t = time.time()
    main()