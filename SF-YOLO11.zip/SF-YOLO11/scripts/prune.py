#!/usr/bin/env python3
"""
SF-YOLO11 Adaptive Structured Pruning Script
============================================

This script implements adaptive structured pruning for SF-YOLO11 models,
specifically optimized for winter jujube detection tasks.

Usage:
    python scripts/prune.py --model weights/sf_yolo11n.pt --config configs/prune_config.yaml
    python scripts/prune.py --model weights/best.pt --sparsity 0.5 --output weights/pruned_model.pt

Author: SF-YOLO11 Research Team
"""

import argparse
import os
import sys
import time
from pathlib import Path
import copy
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
import yaml

# Add project root to path
FILE = Path(__file__).resolve()
ROOT = FILE.parents[1]  # SF-YOLO11 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

# Import SF-YOLO11 modules
from models.sf_yolo11 import SFYOLO11
from models.adaptive_pruning import AdaptivePruningStrategy
from utils.datasets import create_dataloader
from utils.general import (
    set_logging, check_requirements, colorstr, increment_path,
    yaml_load, yaml_save, make_dirs, init_seeds
)
from utils.torch_utils import (
    select_device, ModelEMA, smart_optimizer, 
    intersect_dicts, de_parallel, time_sync
)
from utils.loss import SFYOLO11Loss
from utils.metrics import DetectionMetrics


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='SF-YOLO11 Adaptive Pruning')
    
    # Model and configuration
    parser.add_argument('--model', type=str, required=True,
                       help='Path to model weights')
    parser.add_argument('--config', type=str, default='configs/prune_config.yaml',
                       help='Pruning configuration file')
    parser.add_argument('--data', type=str, default='data/winter_jujube.yaml',
                       help='Dataset configuration file')
    
    # Pruning parameters
    parser.add_argument('--sparsity', type=float, default=None,
                       help='Target sparsity ratio (overrides config)')
    parser.add_argument('--flops-reduction', type=float, default=None,
                       help='Target FLOPs reduction ratio')
    parser.add_argument('--params-reduction', type=float, default=None,
                       help='Target parameters reduction ratio')
    
    # Training parameters for fine-tuning
    parser.add_argument('--epochs', type=int, default=50,
                       help='Number of fine-tuning epochs')
    parser.add_argument('--batch-size', type=int, default=16,
                       help='Batch size for fine-tuning')
    parser.add_argument('--lr', type=float, default=0.001,
                       help='Learning rate for fine-tuning')
    parser.add_argument('--weight-decay', type=float, default=0.0005,
                       help='Weight decay')
    
    # Hardware configuration
    parser.add_argument('--device', default='',
                       help='CUDA device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--workers', type=int, default=8,
                       help='Number of data loading workers')
    
    # Output options
    parser.add_argument('--output', type=str, default='weights/pruned_model.pt',
                       help='Output path for pruned model')
    parser.add_argument('--project', type=str, default='runs/prune',
                       help='Save results to project/name')
    parser.add_argument('--name', type=str, default='exp',
                       help='Save results to project/name')
    parser.add_argument('--exist-ok', action='store_true',
                       help='Existing project/name ok, do not increment')
    
    # Advanced options
    parser.add_argument('--resume', type=str, default='',
                       help='Resume pruning from checkpoint')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed')
    parser.add_argument('--verbose', action='store_true',
                       help='Verbose output')
    
    return parser.parse_args()


def load_model_and_config(model_path, device):
    """Load model and extract configuration."""
    print(f"{colorstr('Model:')} Loading model from {model_path}")
    
    # Load checkpoint
    ckpt = torch.load(model_path, map_location=device)
    
    # Extract model configuration
    if 'config' in ckpt:
        model_config = ckpt['config']
    else:
        # Default configuration for SF-YOLO11n
        model_config = {
            'nc': 1,  # number of classes
            'depth_multiple': 0.33,
            'width_multiple': 0.25,
            'anchors': 3,
        }
    
    # Create model
    model = SFYOLO11(config=model_config)
    
    # Load state dict
    if 'model' in ckpt:
        state_dict = ckpt['model']
    elif 'state_dict' in ckpt:
        state_dict = ckpt['state_dict']
    else:
        state_dict = ckpt
    
    # Load weights
    model.load_state_dict(state_dict, strict=False)
    model = model.to(device)
    
    return model, model_config, ckpt


def calculate_model_stats(model):
    """Calculate model statistics (parameters, FLOPs)."""
    # Count parameters
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    # Estimate FLOPs (simplified calculation)
    # This is a rough estimate - for accurate FLOPs, use tools like thop or fvcore
    dummy_input = torch.randn(1, 3, 640, 640).to(next(model.parameters()).device)
    
    def count_flops(module, input, output):
        if isinstance(module, nn.Conv2d):
            # FLOPs = output_elements * (kernel_size * input_channels + bias)
            output_elements = output.numel()
            kernel_flops = module.kernel_size[0] * module.kernel_size[1] * module.in_channels
            if module.bias is not None:
                kernel_flops += 1
            flops = output_elements * kernel_flops
            module.__flops__ += flops
        elif isinstance(module, nn.Linear):
            flops = module.in_features * module.out_features
            if module.bias is not None:
                flops += module.out_features
            module.__flops__ += flops
    
    # Initialize FLOP counters
    for module in model.modules():
        module.__flops__ = 0
    
    # Register hooks
    hooks = []
    for module in model.modules():
        if isinstance(module, (nn.Conv2d, nn.Linear)):
            hooks.append(module.register_forward_hook(count_flops))
    
    # Forward pass
    with torch.no_grad():
        model(dummy_input)
    
    # Calculate total FLOPs
    total_flops = sum(module.__flops__ for module in model.modules())
    
    # Remove hooks
    for hook in hooks:
        hook.remove()
    
    return {
        'total_params': total_params,
        'trainable_params': trainable_params,
        'flops': total_flops
    }


def evaluate_model(model, dataloader, device, loss_fn=None):
    """Evaluate model performance."""
    model.eval()
    metrics = DetectionMetrics()
    
    total_loss = 0.0
    num_batches = 0
    
    with torch.no_grad():
        for batch_i, (imgs, targets, paths, _) in enumerate(dataloader):
            imgs = imgs.to(device, non_blocking=True).float() / 255.0
            targets = targets.to(device)
            
            # Forward pass
            pred = model(imgs)
            
            # Calculate loss if loss function provided
            if loss_fn is not None:
                loss = loss_fn(pred, targets)[0]
                total_loss += loss.item()
                num_batches += 1
            
            # Update metrics
            metrics.update(pred, targets)
    
    # Calculate final metrics
    results = metrics.compute()
    
    if loss_fn is not None:
        results['loss'] = total_loss / num_batches if num_batches > 0 else 0.0
    
    return results


def fine_tune_model(model, train_loader, val_loader, device, args, pruning_strategy):
    """Fine-tune pruned model."""
    print(f"{colorstr('Fine-tuning:')} Starting fine-tuning for {args.epochs} epochs")
    
    # Set up optimizer
    optimizer = smart_optimizer(model, 'AdamW', args.lr, momentum=0.9, decay=args.weight_decay)
    
    # Set up loss function
    loss_fn = SFYOLO11Loss(model)
    
    # Set up EMA
    ema = ModelEMA(model)
    
    # Set up scheduler
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=args.epochs, eta_min=args.lr * 0.01
    )
    
    best_fitness = 0.0
    best_model = None
    
    for epoch in range(args.epochs):
        model.train()
        
        # Training loop
        total_loss = 0.0
        num_batches = 0
        
        for batch_i, (imgs, targets, paths, _) in enumerate(train_loader):
            imgs = imgs.to(device, non_blocking=True).float() / 255.0
            targets = targets.to(device)
            
            # Forward pass
            pred = model(imgs)
            
            # Calculate loss
            loss, loss_items = loss_fn(pred, targets)
            
            # Backward pass
            optimizer.zero_grad()
            loss.backward()
            
            # Apply pruning constraints during training
            pruning_strategy.apply_pruning_constraints(model)
            
            optimizer.step()
            
            # Update EMA
            ema.update(model)
            
            total_loss += loss.item()
            num_batches += 1
            
            # Print progress
            if batch_i % 50 == 0:
                print(f"Epoch {epoch+1}/{args.epochs}, Batch {batch_i}/{len(train_loader)}, "
                      f"Loss: {loss.item():.4f}")
        
        # Update scheduler
        scheduler.step()
        
        # Validation
        if val_loader is not None:
            val_results = evaluate_model(ema.ema, val_loader, device, loss_fn)
            
            # Calculate fitness (mAP@0.5)
            fitness = val_results.get('mAP@0.5', 0.0)
            
            print(f"Epoch {epoch+1}/{args.epochs} - "
                  f"Train Loss: {total_loss/num_batches:.4f}, "
                  f"Val mAP@0.5: {fitness:.4f}")
            
            # Save best model
            if fitness > best_fitness:
                best_fitness = fitness
                best_model = copy.deepcopy(ema.ema.state_dict())
        else:
            print(f"Epoch {epoch+1}/{args.epochs} - Train Loss: {total_loss/num_batches:.4f}")
    
    # Load best model if available
    if best_model is not None:
        model.load_state_dict(best_model)
    
    return model


def main():
    """Main pruning function."""
    # Parse arguments
    args = parse_args()
    
    # Set up logging
    set_logging()
    
    # Set random seed
    init_seeds(args.seed)
    
    # Set up device
    device = select_device(args.device)
    
    # Create save directory
    save_dir = increment_path(Path(args.project) / args.name, exist_ok=args.exist_ok)
    make_dirs(save_dir)
    
    # Load pruning configuration
    if os.path.exists(args.config):
        with open(args.config, 'r') as f:
            prune_config = yaml.safe_load(f)
    else:
        # Default pruning configuration
        prune_config = {
            'global': {
                'sparsity_target': 0.5,
                'flops_reduction_target': 0.3,
                'params_reduction_target': 0.4
            },
            'importance_calculation': {
                'gradient_sensitivity_weight': 0.4,
                'activation_variance_weight': 0.3,
                'task_relevance_weight': 0.3
            },
            'layer_wise_pruning': {
                'backbone': {'pruning_ratio': 0.6},
                'neck': {'pruning_ratio': 0.4},
                'head': {'pruning_ratio': 0.2}
            }
        }
    
    # Override config with command line arguments
    if args.sparsity is not None:
        prune_config['global']['sparsity_target'] = args.sparsity
    if args.flops_reduction is not None:
        prune_config['global']['flops_reduction_target'] = args.flops_reduction
    if args.params_reduction is not None:
        prune_config['global']['params_reduction_target'] = args.params_reduction
    
    # Load model
    model, model_config, ckpt = load_model_and_config(args.model, device)
    
    # Calculate original model statistics
    original_stats = calculate_model_stats(model)
    print(f"{colorstr('Original Model:')} "
          f"Parameters: {original_stats['total_params']:,}, "
          f"FLOPs: {original_stats['flops']:,}")
    
    # Load dataset configuration
    with open(args.data, 'r') as f:
        data_config = yaml.safe_load(f)
    
    # Create data loaders
    train_loader, val_loader = None, None
    
    if 'train' in data_config and os.path.exists(data_config['train']):
        train_loader = create_dataloader(
            data_config['train'],
            imgsz=640,
            batch_size=args.batch_size,
            stride=32,
            hyp=data_config.get('hyp', {}),
            augment=True,
            cache=False,
            rect=False,
            rank=-1,
            workers=args.workers,
            image_weights=False,
            quad=False,
            prefix='train: '
        )[0]
    
    if 'val' in data_config and os.path.exists(data_config['val']):
        val_loader = create_dataloader(
            data_config['val'],
            imgsz=640,
            batch_size=args.batch_size * 2,
            stride=32,
            hyp=data_config.get('hyp', {}),
            augment=False,
            cache=False,
            rect=True,
            rank=-1,
            workers=args.workers,
            image_weights=False,
            quad=False,
            prefix='val: '
        )[0]
    
    # Evaluate original model
    if val_loader is not None:
        print(f"{colorstr('Evaluation:')} Evaluating original model...")
        original_results = evaluate_model(model, val_loader, device)
        print(f"{colorstr('Original Results:')} mAP@0.5: {original_results.get('mAP@0.5', 0.0):.4f}")
    
    # Initialize adaptive pruning strategy
    pruning_strategy = AdaptivePruningStrategy(
        config=prune_config,
        model=model,
        dataloader=train_loader if train_loader else val_loader
    )
    
    # Perform pruning
    print(f"{colorstr('Pruning:')} Starting adaptive structured pruning...")
    pruned_model = pruning_strategy.prune_model(model)
    
    # Calculate pruned model statistics
    pruned_stats = calculate_model_stats(pruned_model)
    
    # Calculate reduction ratios
    params_reduction = 1 - (pruned_stats['total_params'] / original_stats['total_params'])
    flops_reduction = 1 - (pruned_stats['flops'] / original_stats['flops'])
    
    print(f"{colorstr('Pruned Model:')} "
          f"Parameters: {pruned_stats['total_params']:,} "
          f"({params_reduction:.1%} reduction), "
          f"FLOPs: {pruned_stats['flops']:,} "
          f"({flops_reduction:.1%} reduction)")
    
    # Fine-tune pruned model
    if train_loader is not None:
        pruned_model = fine_tune_model(
            pruned_model, train_loader, val_loader, device, args, pruning_strategy
        )
    
    # Evaluate pruned model
    if val_loader is not None:
        print(f"{colorstr('Evaluation:')} Evaluating pruned model...")
        pruned_results = evaluate_model(pruned_model, val_loader, device)
        print(f"{colorstr('Pruned Results:')} mAP@0.5: {pruned_results.get('mAP@0.5', 0.0):.4f}")
        
        # Calculate performance retention
        if 'mAP@0.5' in original_results and 'mAP@0.5' in pruned_results:
            performance_retention = pruned_results['mAP@0.5'] / original_results['mAP@0.5']
            print(f"{colorstr('Performance:')} Retention: {performance_retention:.1%}")
    
    # Save pruned model
    print(f"{colorstr('Saving:')} Saving pruned model to {args.output}")
    
    # Prepare checkpoint
    save_dict = {
        'model': de_parallel(pruned_model).state_dict(),
        'config': model_config,
        'pruning_config': prune_config,
        'original_stats': original_stats,
        'pruned_stats': pruned_stats,
        'reduction_ratios': {
            'parameters': params_reduction,
            'flops': flops_reduction
        }
    }
    
    # Add evaluation results if available
    if val_loader is not None:
        save_dict['original_results'] = original_results
        save_dict['pruned_results'] = pruned_results
    
    # Save model
    torch.save(save_dict, args.output)
    
    # Save pruning report
    report = {
        'model_path': args.model,
        'output_path': args.output,
        'pruning_config': prune_config,
        'original_stats': original_stats,
        'pruned_stats': pruned_stats,
        'reduction_ratios': {
            'parameters': float(params_reduction),
            'flops': float(flops_reduction)
        },
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
    }
    
    if val_loader is not None:
        report['original_results'] = {k: float(v) if isinstance(v, (int, float)) else v 
                                    for k, v in original_results.items()}
        report['pruned_results'] = {k: float(v) if isinstance(v, (int, float)) else v 
                                  for k, v in pruned_results.items()}
    
    report_path = save_dir / 'pruning_report.json'
    with open(report_path, 'w') as f:
        json.dump(report, f, indent=2)
    
    print(f"{colorstr('Report:')} Pruning report saved to {report_path}")
    
    # Print summary
    print(f"\n{colorstr('Summary:')}")
    print(f"  Original model: {original_stats['total_params']:,} parameters, {original_stats['flops']:,} FLOPs")
    print(f"  Pruned model: {pruned_stats['total_params']:,} parameters, {pruned_stats['flops']:,} FLOPs")
    print(f"  Reduction: {params_reduction:.1%} parameters, {flops_reduction:.1%} FLOPs")
    
    if val_loader is not None:
        print(f"  Performance: {original_results.get('mAP@0.5', 0.0):.4f} → "
              f"{pruned_results.get('mAP@0.5', 0.0):.4f} mAP@0.5")
    
    print(f"\n{colorstr('Pruning:')} Completed successfully!")


if __name__ == '__main__':
    main()