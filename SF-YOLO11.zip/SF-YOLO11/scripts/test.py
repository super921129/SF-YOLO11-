#!/usr/bin/env python3
"""
SF-YOLO11 Testing Script
=======================

This script performs comprehensive testing of the SF-YOLO11 model for winter jujube detection,
including inference on test datasets, performance evaluation, and result visualization.

Usage:
    python scripts/test.py --weights weights/best.pt --source data/test_images/
    python scripts/test.py --weights weights/sf_yolo11n.pt --source data/winter_jujube/test --save-txt
    python scripts/test.py --weights weights/pruned_model.pt --source video.mp4 --save-vid

Author: SF-YOLO11 Research Team
"""

import argparse
import cv2
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from PIL import Image
import yaml

# Add project root to path
FILE = Path(__file__).resolve()
ROOT = FILE.parents[1]  # SF-YOLO11 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

# Import SF-YOLO11 modules
from models.sf_yolo11 import SFYOLO11
from utils.datasets import LoadImages, LoadStreams, LoadWebcam
from utils.general import (
    set_logging, check_requirements, colorstr, increment_path,
    non_max_suppression, scale_coords, xyxy2xywh, clip_coords,
    yaml_load, make_dirs, check_img_size, letterbox
)
from utils.torch_utils import select_device, time_sync
from utils.plots import Annotator, colors, save_one_box


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='SF-YOLO11 Testing')
    
    # Model and source
    parser.add_argument('--weights', type=str, required=True,
                       help='Model weights path')
    parser.add_argument('--source', type=str, default='data/test_images',
                       help='Source: file/dir/URL/glob, 0 for webcam')
    parser.add_argument('--model-config', type=str, default='configs/sf_yolo11n.yaml',
                       help='Model configuration file')
    
    # Inference parameters
    parser.add_argument('--img-size', type=int, default=640,
                       help='Input image size')
    parser.add_argument('--conf-thres', type=float, default=0.25,
                       help='Confidence threshold')
    parser.add_argument('--iou-thres', type=float, default=0.45,
                       help='NMS IoU threshold')
    parser.add_argument('--max-det', type=int, default=1000,
                       help='Maximum detections per image')
    
    # Hardware configuration
    parser.add_argument('--device', default='',
                       help='CUDA device, i.e. 0 or 0,1,2,3 or cpu')
    
    # Output options
    parser.add_argument('--save-txt', action='store_true',
                       help='Save results to *.txt')
    parser.add_argument('--save-conf', action='store_true',
                       help='Save confidences in --save-txt labels')
    parser.add_argument('--save-crop', action='store_true',
                       help='Save cropped prediction boxes')
    parser.add_argument('--save-vid', action='store_true',
                       help='Save video results')
    parser.add_argument('--nosave', action='store_true',
                       help='Do not save images/videos')
    
    # Visualization options
    parser.add_argument('--view-img', action='store_true',
                       help='Show results')
    parser.add_argument('--hide-labels', action='store_true',
                       help='Hide labels')
    parser.add_argument('--hide-conf', action='store_true',
                       help='Hide confidences')
    parser.add_argument('--line-thickness', type=int, default=3,
                       help='Bounding box thickness (pixels)')
    
    # Save options
    parser.add_argument('--project', type=str, default='runs/detect',
                       help='Save results to project/name')
    parser.add_argument('--name', type=str, default='exp',
                       help='Save results to project/name')
    parser.add_argument('--exist-ok', action='store_true',
                       help='Existing project/name ok, do not increment')
    
    # Advanced options
    parser.add_argument('--half', action='store_true',
                       help='Use FP16 half-precision inference')
    parser.add_argument('--augment', action='store_true',
                       help='Augmented inference')
    parser.add_argument('--agnostic-nms', action='store_true',
                       help='Class-agnostic NMS')
    parser.add_argument('--update', action='store_true',
                       help='Update all models')
    
    # Benchmarking
    parser.add_argument('--benchmark', action='store_true',
                       help='Benchmark model speed')
    parser.add_argument('--profile', action='store_true',
                       help='Profile model layers')
    
    return parser.parse_args()


def load_model(weights_path, model_config_path, device, half=False):
    """Load SF-YOLO11 model from weights."""
    print(f"{colorstr('Model:')} Loading model from {weights_path}")
    
    # Load checkpoint
    ckpt = torch.load(weights_path, map_location=device)
    
    # Load model configuration
    if model_config_path and os.path.exists(model_config_path):
        with open(model_config_path, 'r') as f:
            model_config = yaml.safe_load(f)
    else:
        # Try to get config from checkpoint
        model_config = ckpt.get('config', {})
    
    # Create model
    model = SFYOLO11(config=model_config)
    
    # Load state dict
    if 'model' in ckpt:
        state_dict = ckpt['model']
    elif 'state_dict' in ckpt:
        state_dict = ckpt['state_dict']
    else:
        state_dict = ckpt
    
    # Load weights
    model.load_state_dict(state_dict, strict=False)
    model = model.to(device)
    
    # Set to evaluation mode
    model.eval()
    
    # Convert to half precision if requested
    if half:
        model.half()
    
    # Print model info
    n_params = sum(p.numel() for p in model.parameters())
    print(f"{colorstr('Model:')} {n_params:,} parameters")
    
    return model


def preprocess_image(img, img_size, device, half=False):
    """Preprocess image for inference."""
    # Letterbox
    img = letterbox(img, img_size, stride=32, auto=True)[0]
    
    # Convert
    img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
    img = np.ascontiguousarray(img)
    
    # To tensor
    img = torch.from_numpy(img).to(device)
    img = img.half() if half else img.float()  # uint8 to fp16/32
    img /= 255.0  # 0 - 255 to 0.0 - 1.0
    
    if img.ndimension() == 3:
        img = img.unsqueeze(0)
    
    return img


def run_inference(model, img, augment=False):
    """Run model inference."""
    with torch.no_grad():
        pred = model(img, augment=augment)[0]
    return pred


def process_detections(pred, img, im0s, conf_thres, iou_thres, max_det, 
                      agnostic_nms=False, classes=None):
    """Process model predictions."""
    # NMS
    pred = non_max_suppression(
        pred, conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det
    )
    
    # Process detections
    detections = []
    for i, det in enumerate(pred):  # per image
        im0 = im0s[i].copy() if isinstance(im0s, list) else im0s.copy()
        
        if len(det):
            # Rescale boxes from img_size to im0 size
            det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()
            
            # Convert to list format
            for *xyxy, conf, cls in reversed(det):
                detections.append({
                    'bbox': [int(x) for x in xyxy],
                    'confidence': float(conf),
                    'class': int(cls),
                    'class_name': 'winter_jujube'
                })
    
    return detections, im0


def draw_detections(im0, detections, names, hide_labels=False, hide_conf=False, 
                   line_thickness=3):
    """Draw detections on image."""
    annotator = Annotator(im0, line_width=line_thickness, example=str(names))
    
    for det in detections:
        xyxy = det['bbox']
        conf = det['confidence']
        cls = det['class']
        
        # Label
        if hide_labels:
            label = None
        elif hide_conf:
            label = names[cls]
        else:
            label = f'{names[cls]} {conf:.2f}'
        
        # Draw box
        annotator.box_label(xyxy, label, color=colors(cls, True))
    
    return annotator.result()


def save_results(detections, save_dir, img_path, save_txt=False, save_conf=False):
    """Save detection results."""
    if save_txt:
        # Save to txt file
        txt_path = save_dir / 'labels' / f'{Path(img_path).stem}.txt'
        txt_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(txt_path, 'w') as f:
            for det in detections:
                # Convert to YOLO format (normalized xywh)
                x1, y1, x2, y2 = det['bbox']
                # Note: This assumes image dimensions, should be passed as parameter
                # For now, using placeholder values
                img_w, img_h = 640, 640  # Should be actual image dimensions
                
                x_center = (x1 + x2) / 2 / img_w
                y_center = (y1 + y2) / 2 / img_h
                width = (x2 - x1) / img_w
                height = (y2 - y1) / img_h
                
                if save_conf:
                    f.write(f"{det['class']} {x_center:.6f} {y_center:.6f} "
                           f"{width:.6f} {height:.6f} {det['confidence']:.6f}\n")
                else:
                    f.write(f"{det['class']} {x_center:.6f} {y_center:.6f} "
                           f"{width:.6f} {height:.6f}\n")


def benchmark_model(model, img_size, device, half=False, num_runs=100):
    """Benchmark model inference speed."""
    print(f"{colorstr('Benchmark:')} Running speed benchmark...")
    
    # Create dummy input
    img = torch.randn(1, 3, img_size, img_size).to(device)
    if half:
        img = img.half()
    
    # Warmup
    for _ in range(10):
        with torch.no_grad():
            _ = model(img)
    
    # Benchmark
    torch.cuda.synchronize() if device.type == 'cuda' else None
    times = []
    
    for _ in range(num_runs):
        t1 = time_sync()
        with torch.no_grad():
            _ = model(img)
        t2 = time_sync()
        times.append(t2 - t1)
    
    # Calculate statistics
    times = np.array(times)
    mean_time = times.mean()
    std_time = times.std()
    fps = 1.0 / mean_time
    
    print(f"{colorstr('Speed:')} {mean_time*1000:.1f}±{std_time*1000:.1f}ms per image")
    print(f"{colorstr('FPS:')} {fps:.1f}")
    
    return mean_time, fps


def main():
    """Main testing function."""
    # Parse arguments
    args = parse_args()
    
    # Set up logging
    set_logging()
    
    # Set up device
    device = select_device(args.device)
    
    # Create save directory
    save_dir = increment_path(Path(args.project) / args.name, exist_ok=args.exist_ok)
    if not args.nosave:
        make_dirs(save_dir / 'labels' if args.save_txt else save_dir)
    
    # Load model
    model = load_model(args.weights, args.model_config, device, args.half)
    
    # Check image size
    img_size = check_img_size(args.img_size, s=32)  # check img_size
    
    # Class names
    names = {0: 'winter_jujube'}
    
    # Dataloader
    if args.source.isnumeric() or args.source.endswith('.txt') or args.source.lower().startswith(
            ('rtsp://', 'rtmp://', 'http://', 'https://')):
        view_img = check_imshow()
        cudnn.benchmark = True  # set True to speed up constant image size inference
        dataset = LoadStreams(args.source, img_size=img_size, stride=32, auto=True)
        bs = len(dataset)  # batch_size
    else:
        dataset = LoadImages(args.source, img_size=img_size, stride=32, auto=True)
        bs = 1  # batch_size
    
    # Initialize video writer
    vid_path, vid_writer = [None] * bs, [None] * bs
    
    # Initialize statistics
    seen, windows, dt = 0, [], [0.0, 0.0, 0.0]
    all_detections = []
    
    print(f"{colorstr('Testing:')} Starting inference...")
    
    # Run inference
    for path, im, im0s, vid_cap, s in dataset:
        t1 = time_sync()
        
        # Preprocess
        im = torch.from_numpy(im).to(device)
        im = im.half() if args.half else im.float()  # uint8 to fp16/32
        im /= 255  # 0 - 255 to 0.0 - 1.0
        if len(im.shape) == 3:
            im = im[None]  # expand for batch dim
        t2 = time_sync()
        dt[0] += t2 - t1
        
        # Inference
        pred = run_inference(model, im, args.augment)
        t3 = time_sync()
        dt[1] += t3 - t2
        
        # NMS
        pred = non_max_suppression(
            pred, args.conf_thres, args.iou_thres, None, args.agnostic_nms, max_det=args.max_det
        )
        dt[2] += time_sync() - t3
        
        # Process predictions
        for i, det in enumerate(pred):  # per image
            seen += 1
            if hasattr(dataset, 'mode') and dataset.mode == 'stream':  # batch_size >= 1
                p, im0, frame = path[i], im0s[i].copy(), dataset.count
                s += f'{i}: '
            else:
                p, im0, frame = path, im0s.copy(), getattr(dataset, 'frame', 0)
            
            p = Path(p)  # to Path
            save_path = str(save_dir / p.name)  # im.jpg
            txt_path = str(save_dir / 'labels' / p.stem) + ('' if dataset.mode == 'image' else f'_{frame}')  # im.txt
            s += '%gx%g ' % im.shape[2:]  # print string
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
            imc = im0.copy() if args.save_crop else im0  # for save_crop
            annotator = Annotator(im0, line_width=args.line_thickness, example=str(names))
            
            if len(det):
                # Rescale boxes from img_size to im0 size
                det[:, :4] = scale_coords(im.shape[2:], det[:, :4], im0.shape).round()
                
                # Print results
                for c in det[:, -1].unique():
                    n = (det[:, -1] == c).sum()  # detections per class
                    s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string
                
                # Write results
                detections = []
                for *xyxy, conf, cls in reversed(det):
                    # Save detection info
                    detection = {
                        'image_path': str(p),
                        'bbox': [int(x) for x in xyxy],
                        'confidence': float(conf),
                        'class': int(cls),
                        'class_name': names[int(cls)]
                    }
                    detections.append(detection)
                    all_detections.append(detection)
                    
                    if args.save_txt:  # Write to file
                        xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                        line = (cls, *xywh, conf) if args.save_conf else (cls, *xywh)  # label format
                        with open(f'{txt_path}.txt', 'a') as f:
                            f.write(('%g ' * len(line)).rstrip() % line + '\n')
                    
                    if args.save_crop:
                        save_one_box(xyxy, imc, file=save_dir / 'crops' / names[int(cls)] / f'{p.stem}.jpg', BGR=True)
                    
                    # Add bbox to image
                    if not args.nosave or args.view_img:  # Add bbox to image
                        c = int(cls)  # integer class
                        label = None if args.hide_labels else (names[c] if args.hide_conf else f'{names[c]} {conf:.2f}')
                        annotator.box_label(xyxy, label, color=colors(c, True))
            
            # Stream results
            im0 = annotator.result()
            if args.view_img:
                if hasattr(dataset, 'mode') and dataset.mode == 'stream':
                    cv2.imshow(str(p), im0)
                    cv2.waitKey(1)  # 1 millisecond
                else:
                    cv2.imshow(str(p), im0)
                    cv2.waitKey(0)  # Wait for key press
            
            # Save results (image with detections)
            if not args.nosave:
                if dataset.mode == 'image':
                    cv2.imwrite(save_path, im0)
                else:  # 'video' or 'stream'
                    if vid_path[i] != save_path:  # new video
                        vid_path[i] = save_path
                        if isinstance(vid_writer[i], cv2.VideoWriter):
                            vid_writer[i].release()  # release previous video writer
                        if vid_cap:  # video
                            fps = vid_cap.get(cv2.CAP_PROP_FPS)
                            w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                            h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        else:  # stream
                            fps, w, h = 30, im0.shape[1], im0.shape[0]
                        save_path = str(Path(save_path).with_suffix('.mp4'))  # force *.mp4 suffix on results videos
                        vid_writer[i] = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (w, h))
                    vid_writer[i].write(im0)
        
        # Print time (inference-only)
        print(f'{s}Done. ({t3 - t2:.3f}s)')
    
    # Print results
    t = tuple(x / seen * 1E3 for x in dt)  # speeds per image
    print(f'Speed: %.1fms pre-process, %.1fms inference, %.1fms NMS per image at shape (1, 3, {img_size}, {img_size})' % t)
    
    # Save detection results to JSON
    if not args.nosave:
        results_file = save_dir / 'detections.json'
        with open(results_file, 'w') as f:
            json.dump(all_detections, f, indent=2)
        print(f"{colorstr('Results:')} Detections saved to {results_file}")
    
    # Benchmark speed if requested
    if args.benchmark:
        benchmark_model(model, img_size, device, args.half)
    
    # Print summary
    print(f"\n{colorstr('Testing:')} Testing completed successfully!")
    print(f"{colorstr('Images:')} Processed {seen} images")
    print(f"{colorstr('Detections:')} Found {len(all_detections)} winter jujube detections")
    if not args.nosave:
        print(f"{colorstr('Results:')} Results saved to {save_dir}")


if __name__ == '__main__':
    main()