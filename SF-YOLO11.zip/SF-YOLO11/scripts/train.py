#!/usr/bin/env python3
"""
SF-YOLO11 Training Script
========================

This script trains the SF-YOLO11 model for winter jujube detection with
adaptive structured pruning, LightSPPF module, and improved sequential
scale feature fusion (ISSFF).

Usage:
    python scripts/train.py --config configs/train_config.yaml --data data/winter_jujube.yaml
    python scripts/train.py --model configs/sf_yolo11n.yaml --epochs 300 --batch-size 16
    python scripts/train.py --resume runs/train/exp/weights/last.pt

Author: SF-YOLO11 Research Team
"""

import argparse
import os
import sys
import time
import warnings
from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import yaml
import numpy as np
from tqdm import tqdm

# Add project root to path
FILE = Path(__file__).resolve()
ROOT = FILE.parents[1]  # SF-YOLO11 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

# Import SF-YOLO11 modules
from models.sf_yolo11 import SFYOLO11
from models.adaptive_pruning import AdaptivePruningStrategy
from utils.datasets import create_dataloader, load_dataset_config
from utils.loss import SFYOLO11Loss
from utils.metrics import DetectionMetrics
from utils.general import (
    set_logging, check_requirements, check_version, colorstr,
    increment_path, init_seeds, intersect_dicts, strip_optimizer,
    yaml_load, yaml_save, make_dirs
)
from utils.torch_utils import (
    select_device, ModelEMA, smart_optimizer, smart_resume,
    EarlyStopping, de_parallel, torch_distributed_zero_first
)
from utils.plots import plot_results, plot_lr_scheduler, plot_evolve

# Suppress warnings
warnings.filterwarnings('ignore')


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='SF-YOLO11 Training')
    
    # Model and data configuration
    parser.add_argument('--config', type=str, default='configs/train_config.yaml',
                       help='Training configuration file')
    parser.add_argument('--model', type=str, default='configs/sf_yolo11n.yaml',
                       help='Model configuration file')
    parser.add_argument('--data', type=str, default='data/winter_jujube.yaml',
                       help='Dataset configuration file')
    
    # Training parameters
    parser.add_argument('--epochs', type=int, default=300,
                       help='Number of training epochs')
    parser.add_argument('--batch-size', type=int, default=16,
                       help='Batch size for training')
    parser.add_argument('--img-size', type=int, default=640,
                       help='Input image size')
    
    # Optimizer and learning rate
    parser.add_argument('--lr', type=float, default=0.001,
                       help='Initial learning rate')
    parser.add_argument('--optimizer', type=str, default='AdamW',
                       choices=['SGD', 'Adam', 'AdamW'],
                       help='Optimizer type')
    
    # Hardware configuration
    parser.add_argument('--device', default='',
                       help='CUDA device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--workers', type=int, default=8,
                       help='Maximum number of dataloader workers')
    
    # Pruning configuration
    parser.add_argument('--prune', action='store_true',
                       help='Enable adaptive structured pruning')
    parser.add_argument('--prune-config', type=str, default='configs/prune_config.yaml',
                       help='Pruning configuration file')
    
    # Checkpointing and resuming
    parser.add_argument('--resume', type=str, default='',
                       help='Resume training from checkpoint')
    parser.add_argument('--weights', type=str, default='',
                       help='Initial weights path')
    
    # Logging and saving
    parser.add_argument('--project', type=str, default='runs/train',
                       help='Save results to project/name')
    parser.add_argument('--name', type=str, default='exp',
                       help='Save results to project/name')
    parser.add_argument('--exist-ok', action='store_true',
                       help='Existing project/name ok, do not increment')
    
    # Advanced options
    parser.add_argument('--amp', action='store_true',
                       help='Automatic Mixed Precision training')
    parser.add_argument('--sync-bn', action='store_true',
                       help='Use SyncBatchNorm, only available in DDP mode')
    parser.add_argument('--local-rank', type=int, default=-1,
                       help='DDP parameter, do not modify')
    
    # Debugging
    parser.add_argument('--debug', action='store_true',
                       help='Enable debug mode')
    parser.add_argument('--profile', action='store_true',
                       help='Profile model performance')
    
    return parser.parse_args()


def load_config(config_path):
    """Load configuration from YAML file."""
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    return config


def create_model(model_config, device, num_classes=1):
    """Create SF-YOLO11 model."""
    print(f"{colorstr('Model:')} Creating SF-YOLO11 model...")
    
    # Load model configuration
    if isinstance(model_config, str):
        model_config = load_config(model_config)
    
    # Create model
    model = SFYOLO11(
        config=model_config,
        num_classes=num_classes,
        anchors=None  # Anchor-free detection
    )
    
    # Move to device
    model = model.to(device)
    
    # Print model info
    n_params = sum(p.numel() for p in model.parameters())
    n_trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    print(f"{colorstr('Model:')} {n_params:,} parameters, {n_trainable:,} trainable")
    
    return model


def create_optimizer(model, config):
    """Create optimizer based on configuration."""
    opt_config = config.get('training', {}).get('optimizer', {})
    opt_type = opt_config.get('type', 'AdamW')
    lr = opt_config.get('lr0', 0.001)
    weight_decay = opt_config.get('weight_decay', 0.0005)
    
    # Get model parameters
    g = [], [], []  # optimizer parameter groups
    bn = tuple(v for k, v in nn.__dict__.items() if 'Norm' in k)  # normalization layers
    
    for v in model.modules():
        if hasattr(v, 'bias') and isinstance(v.bias, nn.Parameter):  # bias
            g[2].append(v.bias)
        if isinstance(v, bn):  # weight (no decay)
            g[1].append(v.weight)
        elif hasattr(v, 'weight') and isinstance(v.weight, nn.Parameter):  # weight (with decay)
            g[0].append(v.weight)
    
    # Create optimizer
    if opt_type == 'Adam':
        optimizer = optim.Adam(g[2], lr=lr, betas=(0.9, 0.999))
    elif opt_type == 'AdamW':
        optimizer = optim.AdamW(g[2], lr=lr, betas=(0.9, 0.999), weight_decay=0.0)
    elif opt_type == 'SGD':
        optimizer = optim.SGD(g[2], lr=lr, momentum=0.937, nesterov=True)
    else:
        raise ValueError(f"Unsupported optimizer: {opt_type}")
    
    # Add parameter groups
    optimizer.add_param_group({'params': g[0], 'weight_decay': weight_decay})  # add g0 with weight_decay
    optimizer.add_param_group({'params': g[1]})  # add g1 (BatchNorm2d weights)
    
    print(f"{colorstr('Optimizer:')} {opt_type} with parameter groups "
          f"{len(g[1])} weight (no decay), {len(g[0])} weight, {len(g[2])} bias")
    
    return optimizer


def create_scheduler(optimizer, config, epochs):
    """Create learning rate scheduler."""
    lr_config = config.get('training', {}).get('lr_scheduler', {})
    scheduler_type = lr_config.get('type', 'cosine')
    
    if scheduler_type == 'cosine':
        T_max = lr_config.get('T_max', epochs)
        eta_min = lr_config.get('eta_min', 0.00001)
        scheduler = optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=T_max, eta_min=eta_min
        )
    elif scheduler_type == 'step':
        step_size = lr_config.get('step_size', 100)
        gamma = lr_config.get('gamma', 0.1)
        scheduler = optim.lr_scheduler.StepLR(
            optimizer, step_size=step_size, gamma=gamma
        )
    elif scheduler_type == 'multistep':
        milestones = lr_config.get('milestones', [150, 250])
        gamma = lr_config.get('gamma', 0.1)
        scheduler = optim.lr_scheduler.MultiStepLR(
            optimizer, milestones=milestones, gamma=gamma
        )
    else:
        scheduler = None
    
    return scheduler


def train_one_epoch(model, dataloader, optimizer, criterion, device, epoch, 
                   config, scaler=None, pruning_strategy=None):
    """Train for one epoch."""
    model.train()
    
    # Initialize metrics
    running_loss = 0.0
    running_cls_loss = 0.0
    running_box_loss = 0.0
    running_obj_loss = 0.0
    
    # Progress bar
    pbar = tqdm(dataloader, desc=f'Epoch {epoch}')
    
    for batch_idx, (images, targets) in enumerate(pbar):
        # Move to device
        images = images.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        
        # Zero gradients
        optimizer.zero_grad()
        
        # Forward pass with mixed precision
        if scaler is not None:
            with torch.cuda.amp.autocast():
                outputs = model(images)
                loss, loss_items = criterion(outputs, targets)
        else:
            outputs = model(images)
            loss, loss_items = criterion(outputs, targets)
        
        # Backward pass
        if scaler is not None:
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            loss.backward()
            optimizer.step()
        
        # Update pruning strategy
        if pruning_strategy is not None:
            pruning_strategy.update_gradients(model)
        
        # Update metrics
        running_loss += loss.item()
        if len(loss_items) >= 3:
            running_cls_loss += loss_items[0].item()
            running_box_loss += loss_items[1].item()
            running_obj_loss += loss_items[2].item()
        
        # Update progress bar
        pbar.set_postfix({
            'Loss': f'{loss.item():.4f}',
            'Cls': f'{loss_items[0].item():.4f}' if len(loss_items) > 0 else '0.0000',
            'Box': f'{loss_items[1].item():.4f}' if len(loss_items) > 1 else '0.0000',
            'Obj': f'{loss_items[2].item():.4f}' if len(loss_items) > 2 else '0.0000'
        })
    
    # Calculate average losses
    avg_loss = running_loss / len(dataloader)
    avg_cls_loss = running_cls_loss / len(dataloader)
    avg_box_loss = running_box_loss / len(dataloader)
    avg_obj_loss = running_obj_loss / len(dataloader)
    
    return avg_loss, avg_cls_loss, avg_box_loss, avg_obj_loss


def validate(model, dataloader, criterion, device, metrics_calculator):
    """Validate the model."""
    model.eval()
    
    running_loss = 0.0
    all_predictions = []
    all_targets = []
    
    with torch.no_grad():
        for images, targets in tqdm(dataloader, desc='Validating'):
            images = images.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)
            
            # Forward pass
            outputs = model(images)
            loss, _ = criterion(outputs, targets)
            
            running_loss += loss.item()
            
            # Collect predictions and targets for metrics
            all_predictions.append(outputs)
            all_targets.append(targets)
    
    # Calculate metrics
    avg_loss = running_loss / len(dataloader)
    
    # Calculate detection metrics
    metrics = metrics_calculator.calculate_metrics(all_predictions, all_targets)
    
    return avg_loss, metrics


def main():
    """Main training function."""
    # Parse arguments
    args = parse_args()
    
    # Set up logging
    set_logging()
    
    # Load configurations
    print(f"{colorstr('Config:')} Loading configurations...")
    train_config = load_config(args.config)
    model_config = load_config(args.model)
    data_config = load_dataset_config(args.data)
    
    # Override config with command line arguments
    if args.epochs:
        train_config['training']['epochs'] = args.epochs
    if args.batch_size:
        train_config['data']['batch_size'] = args.batch_size
    if args.lr:
        train_config['training']['optimizer']['lr0'] = args.lr
    
    # Set up device
    device = select_device(args.device)
    print(f"{colorstr('Device:')} {device}")
    
    # Set random seeds
    init_seeds(train_config.get('seed', 42))
    
    # Create save directory
    save_dir = increment_path(Path(args.project) / args.name, exist_ok=args.exist_ok)
    make_dirs(save_dir)
    
    # Save configurations
    yaml_save(save_dir / 'train_config.yaml', train_config)
    yaml_save(save_dir / 'model_config.yaml', model_config)
    yaml_save(save_dir / 'data_config.yaml', data_config)
    
    # Create model
    num_classes = data_config.get('nc', 1)
    model = create_model(model_config, device, num_classes)
    
    # Load weights if specified
    if args.weights:
        print(f"{colorstr('Weights:')} Loading weights from {args.weights}")
        ckpt = torch.load(args.weights, map_location=device)
        model.load_state_dict(ckpt['model'], strict=False)
    
    # Create data loaders
    print(f"{colorstr('Data:')} Creating data loaders...")
    train_loader = create_dataloader(
        path=data_config['train'],
        img_size=args.img_size,
        batch_size=args.batch_size,
        augment=True,
        hyp=train_config.get('data', {}).get('augmentation', {}),
        workers=args.workers,
        shuffle=True
    )
    
    val_loader = create_dataloader(
        path=data_config['val'],
        img_size=args.img_size,
        batch_size=args.batch_size,
        augment=False,
        hyp=None,
        workers=args.workers,
        shuffle=False
    )
    
    # Create loss function
    criterion = SFYOLO11Loss(
        num_classes=num_classes,
        device=device,
        **train_config.get('loss', {})
    )
    
    # Create optimizer and scheduler
    optimizer = create_optimizer(model, train_config)
    scheduler = create_scheduler(optimizer, train_config, args.epochs)
    
    # Create metrics calculator
    metrics_calculator = DetectionMetrics(num_classes=num_classes)
    
    # Create EMA model
    ema = ModelEMA(model) if train_config.get('training', {}).get('ema', True) else None
    
    # Create early stopping
    early_stopping = EarlyStopping(
        patience=train_config.get('training', {}).get('patience', 50)
    )
    
    # Create pruning strategy
    pruning_strategy = None
    if args.prune:
        prune_config = load_config(args.prune_config)
        pruning_strategy = AdaptivePruningStrategy(
            model=model,
            config=prune_config,
            device=device
        )
    
    # Mixed precision scaler
    scaler = torch.cuda.amp.GradScaler() if args.amp else None
    
    # Resume training if specified
    start_epoch = 0
    best_fitness = 0.0
    
    if args.resume:
        print(f"{colorstr('Resume:')} Resuming training from {args.resume}")
        ckpt = torch.load(args.resume, map_location=device)
        model.load_state_dict(ckpt['model'])
        optimizer.load_state_dict(ckpt['optimizer'])
        if scheduler:
            scheduler.load_state_dict(ckpt['scheduler'])
        start_epoch = ckpt['epoch'] + 1
        best_fitness = ckpt.get('best_fitness', 0.0)
        if ema:
            ema.ema.load_state_dict(ckpt['ema'])
        if scaler and 'scaler' in ckpt:
            scaler.load_state_dict(ckpt['scaler'])
    
    # Training loop
    print(f"{colorstr('Training:')} Starting training for {args.epochs} epochs...")
    
    results = []
    
    for epoch in range(start_epoch, args.epochs):
        # Train one epoch
        train_loss, cls_loss, box_loss, obj_loss = train_one_epoch(
            model, train_loader, optimizer, criterion, device, epoch,
            train_config, scaler, pruning_strategy
        )
        
        # Update EMA
        if ema:
            ema.update(model)
        
        # Update scheduler
        if scheduler:
            scheduler.step()
        
        # Validate
        val_loss, metrics = validate(
            ema.ema if ema else model, val_loader, criterion, device, metrics_calculator
        )
        
        # Calculate fitness (mAP50)
        fitness = metrics.get('mAP50', 0.0)
        
        # Apply pruning
        if pruning_strategy and pruning_strategy.should_prune(epoch):
            print(f"{colorstr('Pruning:')} Applying adaptive structured pruning...")
            pruning_strategy.prune_model()
            pruning_strategy.fine_tune(train_loader, optimizer, criterion, device)
        
        # Log results
        result = [epoch, train_loss, cls_loss, box_loss, obj_loss, val_loss] + list(metrics.values())
        results.append(result)
        
        # Print epoch results
        print(f"Epoch {epoch:3d}/{args.epochs-1:3d} "
              f"Train Loss: {train_loss:.4f} "
              f"Val Loss: {val_loss:.4f} "
              f"mAP50: {metrics.get('mAP50', 0.0):.4f} "
              f"mAP50-95: {metrics.get('mAP50-95', 0.0):.4f}")
        
        # Save checkpoint
        is_best = fitness > best_fitness
        best_fitness = max(fitness, best_fitness)
        
        ckpt = {
            'epoch': epoch,
            'model': de_parallel(model).state_dict(),
            'optimizer': optimizer.state_dict(),
            'scheduler': scheduler.state_dict() if scheduler else None,
            'best_fitness': best_fitness,
            'ema': ema.ema.state_dict() if ema else None,
            'scaler': scaler.state_dict() if scaler else None,
            'config': train_config
        }
        
        # Save last checkpoint
        torch.save(ckpt, save_dir / 'last.pt')
        
        # Save best checkpoint
        if is_best:
            torch.save(ckpt, save_dir / 'best.pt')
        
        # Early stopping
        early_stopping(val_loss)
        if early_stopping.early_stop:
            print(f"{colorstr('Early Stopping:')} Training stopped at epoch {epoch}")
            break
    
    # Save final results
    print(f"{colorstr('Results:')} Saving training results...")
    
    # Save results CSV
    import pandas as pd
    columns = ['epoch', 'train_loss', 'cls_loss', 'box_loss', 'obj_loss', 'val_loss'] + list(metrics.keys())
    df = pd.DataFrame(results, columns=columns)
    df.to_csv(save_dir / 'results.csv', index=False)
    
    # Plot results
    plot_results(save_dir / 'results.csv', save_dir)
    
    # Strip optimizer from final model
    final_model = save_dir / 'best.pt'
    strip_optimizer(final_model, save_dir / 'best_stripped.pt')
    
    print(f"{colorstr('Training:')} Training completed successfully!")
    print(f"{colorstr('Results:')} Results saved to {save_dir}")
    print(f"{colorstr('Best mAP50:')} {best_fitness:.4f}")


if __name__ == '__main__':
    main()