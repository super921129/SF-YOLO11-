#!/usr/bin/env python3
"""
SF-YOLO11 Validation Script
==========================

This script validates the SF-YOLO11 model for winter jujube detection,
providing comprehensive evaluation metrics including mAP, precision, recall,
and specialized metrics for small object detection.

Usage:
    python scripts/val.py --weights weights/best.pt --data data/winter_jujube.yaml
    python scripts/val.py --weights weights/sf_yolo11n.pt --img-size 640 --batch-size 32
    python scripts/val.py --weights weights/pruned_model.pt --save-json --save-txt

Author: SF-YOLO11 Research Team
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from tqdm import tqdm
import yaml

# Add project root to path
FILE = Path(__file__).resolve()
ROOT = FILE.parents[1]  # SF-YOLO11 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

# Import SF-YOLO11 modules
from models.sf_yolo11 import SFYOLO11
from utils.datasets import create_dataloader, load_dataset_config
from utils.metrics import DetectionMetrics, ConfusionMatrix
from utils.general import (
    set_logging, check_requirements, colorstr, increment_path,
    non_max_suppression, scale_coords, xyxy2xywh, xywh2xyxy,
    clip_coords, yaml_load, make_dirs
)
from utils.torch_utils import select_device, time_sync
from utils.plots import plot_images, output_to_target, plot_val_study


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='SF-YOLO11 Validation')
    
    # Model and data
    parser.add_argument('--weights', type=str, required=True,
                       help='Model weights path')
    parser.add_argument('--data', type=str, default='data/winter_jujube.yaml',
                       help='Dataset configuration file')
    parser.add_argument('--model-config', type=str, default='configs/sf_yolo11n.yaml',
                       help='Model configuration file')
    
    # Validation parameters
    parser.add_argument('--batch-size', type=int, default=32,
                       help='Batch size for validation')
    parser.add_argument('--img-size', type=int, default=640,
                       help='Input image size')
    parser.add_argument('--conf-thres', type=float, default=0.001,
                       help='Confidence threshold')
    parser.add_argument('--iou-thres', type=float, default=0.6,
                       help='NMS IoU threshold')
    parser.add_argument('--max-det', type=int, default=300,
                       help='Maximum detections per image')
    
    # Hardware configuration
    parser.add_argument('--device', default='',
                       help='CUDA device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--workers', type=int, default=8,
                       help='Maximum number of dataloader workers')
    
    # Output options
    parser.add_argument('--save-txt', action='store_true',
                       help='Save results to *.txt')
    parser.add_argument('--save-conf', action='store_true',
                       help='Save confidences in --save-txt labels')
    parser.add_argument('--save-json', action='store_true',
                       help='Save results to JSON file')
    parser.add_argument('--save-hybrid', action='store_true',
                       help='Save hybrid version of labels')
    
    # Visualization options
    parser.add_argument('--plots', action='store_true',
                       help='Save validation plots')
    parser.add_argument('--save-dir', type=str, default='runs/val',
                       help='Save directory')
    parser.add_argument('--name', type=str, default='exp',
                       help='Save results to save_dir/name')
    parser.add_argument('--exist-ok', action='store_true',
                       help='Existing project/name ok, do not increment')
    
    # Advanced options
    parser.add_argument('--half', action='store_true',
                       help='Use FP16 half-precision inference')
    parser.add_argument('--augment', action='store_true',
                       help='Augmented inference')
    parser.add_argument('--verbose', action='store_true',
                       help='Report mAP by class')
    parser.add_argument('--single-cls', action='store_true',
                       help='Treat as single-class dataset')
    
    # Speed benchmarking
    parser.add_argument('--benchmark', action='store_true',
                       help='Benchmark model speed')
    parser.add_argument('--profile', action='store_true',
                       help='Profile model layers')
    
    return parser.parse_args()


def load_model(weights_path, model_config_path, device, half=False):
    """Load SF-YOLO11 model from weights."""
    print(f"{colorstr('Model:')} Loading model from {weights_path}")
    
    # Load checkpoint
    ckpt = torch.load(weights_path, map_location=device)
    
    # Load model configuration
    if model_config_path and os.path.exists(model_config_path):
        with open(model_config_path, 'r') as f:
            model_config = yaml.safe_load(f)
    else:
        # Try to get config from checkpoint
        model_config = ckpt.get('config', {})
    
    # Create model
    model = SFYOLO11(config=model_config)
    
    # Load state dict
    if 'model' in ckpt:
        state_dict = ckpt['model']
    elif 'state_dict' in ckpt:
        state_dict = ckpt['state_dict']
    else:
        state_dict = ckpt
    
    # Load weights
    model.load_state_dict(state_dict, strict=False)
    model = model.to(device)
    
    # Set to evaluation mode
    model.eval()
    
    # Convert to half precision if requested
    if half:
        model.half()
    
    # Print model info
    n_params = sum(p.numel() for p in model.parameters())
    print(f"{colorstr('Model:')} {n_params:,} parameters")
    
    return model


def process_batch(detections, labels, iouv):
    """
    Return correct predictions matrix. Both sets of boxes are in (x1, y1, x2, y2) format.
    Arguments:
        detections (Array[N, 6]), x1, y1, x2, y2, conf, class
        labels (Array[M, 5]), class, x1, y1, x2, y2
    Returns:
        correct (Array[N, 10]), for 10 IoU levels
    """
    correct = torch.zeros(detections.shape[0], iouv.shape[0], dtype=torch.bool, device=iouv.device)
    iou = box_iou(labels[:, 1:], detections[:, :4])
    x = torch.where((iou >= iouv[0]) & (labels[:, 0:1] == detections[:, 5]))  # IoU above threshold and classes match
    if x[0].shape[0]:
        matches = torch.cat((torch.stack(x, 1), iou[x[0], x[1]][:, None]), 1).cpu().numpy()  # [label, detection, iou]
        if x[0].shape[0] > 1:
            matches = matches[matches[:, 2].argsort()[::-1]]
            matches = matches[np.unique(matches[:, 1], return_index=True)[1]]
            matches = matches[np.unique(matches[:, 0], return_index=True)[1]]
        matches = torch.Tensor(matches).to(iouv.device)
        correct[matches[:, 1].long()] = matches[:, 2:3] >= iouv
    return correct


def box_iou(box1, box2):
    """
    Return intersection-over-union (Jaccard index) of boxes.
    Both sets of boxes are expected to be in (x1, y1, x2, y2) format.
    Arguments:
        box1 (Tensor[N, 4])
        box2 (Tensor[M, 4])
    Returns:
        iou (Tensor[N, M]): the NxM matrix containing the pairwise IoU values for every element in boxes1 and boxes2
    """
    def box_area(box):
        # box = 4xn
        return (box[2] - box[0]) * (box[3] - box[1])

    area1 = box_area(box1.T)
    area2 = box_area(box2.T)

    # inter(N,M) = (rb(N,M,2) - lt(N,M,2)).clamp(0).prod(2)
    inter = (torch.min(box1[:, None, 2:], box2[:, 2:]) - torch.max(box1[:, None, :2], box2[:, :2])).clamp(0).prod(2)
    return inter / (area1[:, None] + area2 - inter)  # iou = inter / (area1 + area2 - inter)


def ap_per_class(tp, conf, pred_cls, target_cls, plot=False, save_dir='.', names=()):
    """
    Compute the average precision, given the recall and precision curves.
    Source: https://github.com/rafaelpadilla/Object-Detection-Metrics.
    # Arguments
        tp:  True positives (nparray, nx1 or nx10).
        conf:  Objectness value from 0-1 (nparray).
        pred_cls:  Predicted object classes (nparray).
        target_cls:  True object classes (nparray).
        plot:  Plot precision-recall curve at mAP@0.5
        save_dir:  Plot save directory
    # Returns
        The average precision as computed in py-faster-rcnn.
    """

    # Sort by objectness
    i = np.argsort(-conf)
    tp, conf, pred_cls = tp[i], conf[i], pred_cls[i]

    # Find unique classes
    unique_classes = np.unique(target_cls)
    nc = unique_classes.shape[0]  # number of classes, number of detections

    # Create Precision-Recall curve and compute AP for each class
    px, py = np.linspace(0, 1, 1000), []  # for plotting
    ap, p, r = np.zeros((nc, tp.shape[1])), np.zeros((nc, 1000)), np.zeros((nc, 1000))
    for ci, c in enumerate(unique_classes):
        i = pred_cls == c
        n_l = (target_cls == c).sum()  # number of labels
        n_p = i.sum()  # number of predictions

        if n_p == 0 or n_l == 0:
            continue
        else:
            # Accumulate FPs and TPs
            fpc = (1 - tp[i]).cumsum(0)
            tpc = tp[i].cumsum(0)

            # Recall
            recall = tpc / (n_l + 1e-16)  # recall curve
            r[ci] = np.interp(-px, -conf[i], recall[:, 0], left=0)  # negative x, xp because xp decreases

            # Precision
            precision = tpc / (tpc + fpc)  # precision curve
            p[ci] = np.interp(-px, -conf[i], precision[:, 0], left=1)  # p at pr_score

            # AP from recall-precision curve
            for j in range(tp.shape[1]):
                ap[ci, j], mpre, mrec = compute_ap(recall[:, j], precision[:, j])
                if plot and j == 0:
                    py.append(np.interp(px, mrec, mpre))  # precision at mAP@0.5

    # Compute F1 (harmonic mean of precision and recall)
    f1 = 2 * p * r / (p + r + 1e-16)
    names = [v for k, v in names.items() if k in unique_classes] if names else unique_classes
    names = {i: v for i, v in enumerate(names)}  # to dict
    if plot:
        plot_pr_curve(px, py, ap, Path(save_dir) / 'PR_curve.png', names)
        plot_mc_curve(px, f1, Path(save_dir) / 'F1_curve.png', names, ylabel='F1')
        plot_mc_curve(px, p, Path(save_dir) / 'P_curve.png', names, ylabel='Precision')
        plot_mc_curve(px, r, Path(save_dir) / 'R_curve.png', names, ylabel='Recall')

    i = f1.mean(0).argmax()  # max F1 index
    return p[:, i], r[:, i], ap, f1[:, i], unique_classes.astype('int32')


def compute_ap(recall, precision):
    """
    Compute the average precision, given the recall and precision curves
    # Arguments
        recall:    The recall curve (list)
        precision: The precision curve (list)
    # Returns
        Average precision, precision curve, recall curve
    """

    # Append sentinel values to beginning and end
    mrec = np.concatenate(([0.0], recall, [1.0]))
    mpre = np.concatenate(([1.0], precision, [0.0]))

    # Compute the precision envelope
    mpre = np.flip(np.maximum.accumulate(np.flip(mpre)))

    # Integrate area under curve
    method = 'interp'  # methods: 'continuous', 'interp'
    if method == 'interp':
        x = np.linspace(0, 1, 101)  # 101-point interp (COCO)
        ap = np.trapz(np.interp(x, mrec, mpre), x)  # integrate
    else:  # 'continuous'
        i = np.where(mrec[1:] != mrec[:-1])[0]  # points where x axis (recall) changes
        ap = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])  # area under curve

    return ap, mpre, mrec


def validate_model(model, dataloader, device, conf_thres=0.001, iou_thres=0.6, 
                  max_det=300, half=False, augment=False, verbose=False, 
                  save_dir=None, save_txt=False, save_conf=False, save_json=False,
                  single_cls=False, plots=False, names=None):
    """Validate SF-YOLO11 model."""
    
    # Initialize metrics
    nc = 1  # number of classes (winter jujube)
    iouv = torch.linspace(0.5, 0.95, 10).to(device)  # iou vector for mAP@0.5:0.95
    niou = iouv.numel()
    
    # Initialize statistics
    seen = 0
    confusion_matrix = ConfusionMatrix(nc=nc)
    names = {0: 'winter_jujube'} if names is None else names
    s = ('%20s' + '%11s' * 6) % ('Class', 'Images', 'Labels', 'P', 'R', 'mAP@.5', 'mAP@.5:.95')
    dt, p, r, f1, mp, mr, map50, map = [0.0, 0.0, 0.0], 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    loss = torch.zeros(3, device=device)
    jdict, stats, ap, ap_class = [], [], [], []
    
    # Initialize timing
    t0 = time.time()
    
    # Validation loop
    pbar = tqdm(dataloader, desc=s, bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}')
    
    for batch_i, (im, targets, paths, shapes) in enumerate(pbar):
        t1 = time_sync()
        
        # Preprocess
        im = im.to(device, non_blocking=True)
        targets = targets.to(device)
        im = im.half() if half else im.float()  # uint8 to fp16/32
        im /= 255  # 0 - 255 to 0.0 - 1.0
        nb, _, height, width = im.shape  # batch size, channels, height, width
        t2 = time_sync()
        dt[0] += t2 - t1
        
        # Inference
        with torch.no_grad():
            out, train_out = model(im) if augment else model(im, augment=False)  # inference, loss outputs
        dt[1] += time_sync() - t2
        
        # NMS
        targets[:, 2:] *= torch.Tensor([width, height, width, height]).to(device)  # to pixels
        lb = [targets[targets[:, 0] == i, 1:] for i in range(nb)] if save_hybrid else []  # for autolabelling
        t3 = time_sync()
        out = non_max_suppression(out, conf_thres, iou_thres, labels=lb, multi_label=True, agnostic=single_cls, max_det=max_det)
        dt[2] += time_sync() - t3
        
        # Metrics
        for si, pred in enumerate(out):
            labels = targets[targets[:, 0] == si, 1:]
            nl = len(labels)
            tcls = labels[:, 0].tolist() if nl else []  # target class
            path, shape = Path(paths[si]), shapes[si][0]
            seen += 1
            
            if len(pred) == 0:
                if nl:
                    stats.append((torch.zeros(0, niou, dtype=torch.bool), torch.Tensor(), torch.Tensor(), tcls))
                continue
            
            # Predictions
            if single_cls:
                pred[:, 5] = 0
            predn = pred.clone()
            scale_coords(im[si].shape[1:], predn[:, :4], shape, shapes[si][1])  # native-space pred
            
            # Evaluate
            if nl:
                tbox = xywh2xyxy(labels[:, 1:5])  # target boxes
                scale_coords(im[si].shape[1:], tbox, shape, shapes[si][1])  # native-space labels
                labelsn = torch.cat((labels[:, 0:1], tbox), 1)  # native-space labels
                correct = process_batch(predn, labelsn, iouv)
                if plots:
                    confusion_matrix.process_batch(predn, labelsn)
            else:
                correct = torch.zeros(pred.shape[0], niou, dtype=torch.bool)
            stats.append((correct.cpu(), pred[:, 4].cpu(), pred[:, 5].cpu(), tcls))  # (correct, conf, pcls, tcls)
            
            # Save/log
            if save_txt:
                save_one_txt(predn, save_conf, shape, file=save_dir / 'labels' / (path.stem + '.txt'))
            if save_json:
                save_one_json(predn, jdict, path, names)  # append to COCO-JSON dictionary
            
        # Plot images
        if plots and batch_i < 3:
            f = save_dir / f'val_batch{batch_i}_labels.jpg'  # labels
            Thread(target=plot_images, args=(im, targets, paths, f, names), daemon=True).start()
            f = save_dir / f'val_batch{batch_i}_pred.jpg'  # predictions
            Thread(target=plot_images, args=(im, output_to_target(out), paths, f, names), daemon=True).start()
    
    # Compute metrics
    stats = [np.concatenate(x, 0) for x in zip(*stats)]  # to numpy
    if len(stats) and stats[0].any():
        p, r, ap, f1, ap_class = ap_per_class(*stats, plot=plots, save_dir=save_dir, names=names)
        ap50, ap = ap[:, 0], ap.mean(1)  # AP@0.5, AP@0.5:0.95
        mp, mr, map50, map = p.mean(), r.mean(), ap50.mean(), ap.mean()
        nt = np.bincount(stats[3].astype(np.int64), minlength=nc)  # number of targets per class
    else:
        nt = torch.zeros(1)
    
    # Print results
    pf = '%20s' + '%11i' * 2 + '%11.3g' * 4  # print format
    print(pf % ('all', seen, nt.sum(), mp, mr, map50, map))
    
    # Print results per class
    if (verbose or (nc < 50 and not training)) and nc > 1 and len(stats):
        for i, c in enumerate(ap_class):
            print(pf % (names[c], seen, nt[c], p[i], r[i], ap50[i], ap[i]))
    
    # Print speeds
    t = tuple(x / seen * 1E3 for x in dt)  # speeds per image
    if not training:
        shape = (1, 3, height, width)
        print(f'Speed: %.1fms pre-process, %.1fms inference, %.1fms NMS per image at shape {shape}' % t)
    
    # Plots
    if plots:
        confusion_matrix.plot(save_dir=save_dir, names=list(names.values()))
    
    # Save JSON
    if save_json and len(jdict):
        w = Path(weights[0] if isinstance(weights, list) else weights).stem if weights is not None else ''  # weights
        anno_json = str(Path(data.get('path', '../coco')) / 'annotations/instances_val2017.json')  # annotations json
        pred_json = str(save_dir / f"{w}_predictions.json")  # predictions json
        print(f'\nEvaluating pycocotools mAP... saving {pred_json}...')
        with open(pred_json, 'w') as f:
            json.dump(jdict, f)
    
    # Return results
    model.float()  # for training
    if not training:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        print(f"Results saved to {colorstr('bold', save_dir)}{s}")
    
    maps = np.zeros(nc) + map
    for i, c in enumerate(ap_class):
        maps[c] = ap[i]
    
    return (mp, mr, map50, map, *(loss.cpu() / len(dataloader)).tolist()), maps, t


def save_one_txt(predn, conf, shape, file):
    """Save one txt result."""
    # Normalized xywh
    gn = torch.tensor(shape)[[1, 0, 1, 0]]  # normalization gain whwh
    for *xyxy, conf, cls in predn.tolist():
        xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
        line = (cls, *xywh, conf) if conf else (cls, *xywh)  # label format
        with open(file, 'a') as f:
            f.write(('%g ' * len(line)).rstrip() % line + '\n')


def save_one_json(predn, jdict, path, names):
    """Save one JSON result {"image_id": 42, "category_id": 18, "bbox": [258.15, 41.29, 348.26, 243.78], "score": 0.236}."""
    image_id = int(path.stem) if path.stem.isnumeric() else path.stem
    box = xyxy2xywh(predn[:, :4])  # xywh
    box[:, :2] -= box[:, 2:] / 2  # xy center to top-left corner
    for p, b in zip(predn.tolist(), box.tolist()):
        jdict.append({'image_id': image_id,
                      'category_id': names[int(p[5])],
                      'bbox': [round(x, 3) for x in b],
                      'score': round(p[4], 5)})


def benchmark_speed(model, dataloader, device, half=False):
    """Benchmark model inference speed."""
    print(f"{colorstr('Benchmark:')} Running speed benchmark...")
    
    model.eval()
    times = []
    
    # Warmup
    for _ in range(10):
        with torch.no_grad():
            for images, _ in dataloader:
                images = images.to(device, non_blocking=True)
                if half:
                    images = images.half()
                _ = model(images)
                break
        break
    
    # Benchmark
    torch.cuda.synchronize() if device.type == 'cuda' else None
    t0 = time.time()
    
    for batch_idx, (images, _) in enumerate(dataloader):
        if batch_idx >= 100:  # Limit to 100 batches
            break
            
        images = images.to(device, non_blocking=True)
        if half:
            images = images.half()
            
        t1 = time_sync()
        with torch.no_grad():
            _ = model(images)
        t2 = time_sync()
        
        times.append(t2 - t1)
    
    # Calculate statistics
    times = np.array(times)
    mean_time = times.mean()
    std_time = times.std()
    fps = 1.0 / mean_time
    
    print(f"{colorstr('Speed:')} {mean_time*1000:.1f}±{std_time*1000:.1f}ms per batch")
    print(f"{colorstr('FPS:')} {fps:.1f}")
    
    return mean_time, fps


def main():
    """Main validation function."""
    # Parse arguments
    args = parse_args()
    
    # Set up logging
    set_logging()
    
    # Set up device
    device = select_device(args.device, batch_size=args.batch_size)
    
    # Create save directory
    save_dir = increment_path(Path(args.save_dir) / args.name, exist_ok=args.exist_ok)
    make_dirs(save_dir / 'labels' if args.save_txt else save_dir)
    
    # Load model
    model = load_model(args.weights, args.model_config, device, args.half)
    
    # Load dataset configuration
    data_config = load_dataset_config(args.data)
    
    # Create validation dataloader
    val_loader = create_dataloader(
        path=data_config['val'],
        img_size=args.img_size,
        batch_size=args.batch_size,
        augment=False,
        hyp=None,
        workers=args.workers,
        shuffle=False,
        pad=0.5,
        rect=True
    )
    
    # Get class names
    names = data_config.get('names', {0: 'winter_jujube'})
    
    print(f"{colorstr('Validation:')} Starting validation...")
    
    # Run validation
    results, maps, times = validate_model(
        model=model,
        dataloader=val_loader,
        device=device,
        conf_thres=args.conf_thres,
        iou_thres=args.iou_thres,
        max_det=args.max_det,
        half=args.half,
        augment=args.augment,
        verbose=args.verbose,
        save_dir=save_dir,
        save_txt=args.save_txt,
        save_conf=args.save_conf,
        save_json=args.save_json,
        single_cls=args.single_cls,
        plots=args.plots,
        names=names
    )
    
    # Print final results
    mp, mr, map50, map95 = results[:4]
    print(f"\n{colorstr('Results:')}")
    print(f"Precision: {mp:.4f}")
    print(f"Recall: {mr:.4f}")
    print(f"mAP@0.5: {map50:.4f}")
    print(f"mAP@0.5:0.95: {map95:.4f}")
    
    # Speed benchmark
    if args.benchmark:
        mean_time, fps = benchmark_speed(model, val_loader, device, args.half)
    
    # Save results
    results_dict = {
        'precision': float(mp),
        'recall': float(mr),
        'mAP50': float(map50),
        'mAP50-95': float(map95),
        'inference_time_ms': float(times[1] * 1000),
        'nms_time_ms': float(times[2] * 1000),
        'total_time_ms': float(sum(times) * 1000)
    }
    
    if args.benchmark:
        results_dict.update({
            'mean_inference_time_ms': float(mean_time * 1000),
            'fps': float(fps)
        })
    
    # Save results to JSON
    with open(save_dir / 'results.json', 'w') as f:
        json.dump(results_dict, f, indent=2)
    
    print(f"\n{colorstr('Validation:')} Validation completed successfully!")
    print(f"{colorstr('Results:')} Results saved to {save_dir}")


if __name__ == '__main__':
    main()