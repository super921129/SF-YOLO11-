#!/usr/bin/env python3
"""
SF-YOLO11 Setup Script
Structured-Pruning Optimized YOLO for Winter Jujube Detection
"""

import os
import re
from pathlib import Path
from setuptools import setup, find_packages

# Read version from __init__.py
def get_version():
    """Get version from __init__.py file."""
    init_file = Path(__file__).parent / "models" / "__init__.py"
    if init_file.exists():
        with open(init_file, 'r', encoding='utf-8') as f:
            content = f.read()
            match = re.search(r"__version__\s*=\s*['\"]([^'\"]*)['\"]", content)
            if match:
                return match.group(1)
    return "0.1.0"

# Read long description from README
def get_long_description():
    """Get long description from README.md."""
    readme_file = Path(__file__).parent / "README.md"
    if readme_file.exists():
        with open(readme_file, 'r', encoding='utf-8') as f:
            return f.read()
    return ""

# Read requirements from requirements.txt
def get_requirements():
    """Get requirements from requirements.txt."""
    requirements_file = Path(__file__).parent / "requirements.txt"
    requirements = []
    if requirements_file.exists():
        with open(requirements_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    # Remove version constraints for setup.py
                    package = re.split(r'[><=!]', line)[0].strip()
                    requirements.append(package)
    return requirements

# Development requirements
dev_requirements = [
    'pytest>=6.0',
    'pytest-cov>=2.0',
    'black>=22.0',
    'flake8>=4.0',
    'isort>=5.0',
    'mypy>=0.900',
    'pre-commit>=2.0',
    'sphinx>=4.0',
    'sphinx-rtd-theme>=1.0',
]

# Export requirements
export_requirements = [
    'onnx>=1.12.0',
    'onnxsim>=0.4.0',
    'onnxruntime>=1.12.0',
    'openvino-dev>=2022.1.0',
    'tensorrt>=8.0.0',
    'coremltools>=6.0',
    'tensorflow>=2.8.0',
]

# Visualization requirements
viz_requirements = [
    'tensorboard>=2.8.0',
    'wandb>=0.12.0',
    'mlflow>=1.20.0',
    'plotly>=5.0.0',
    'streamlit>=1.10.0',
]

setup(
    name="sf-yolo11",
    version=get_version(),
    author="SF-YOLO11 Team",
    author_email="sf.yolo11@example.com",
    description="Structured-Pruning Optimized YOLO for Winter Jujube Detection",
    long_description=get_long_description(),
    long_description_content_type="text/markdown",
    url="https://github.com/your-username/SF-YOLO11",
    project_urls={
        "Bug Reports": "https://github.com/your-username/SF-YOLO11/issues",
        "Source": "https://github.com/your-username/SF-YOLO11",
        "Documentation": "https://sf-yolo11.readthedocs.io/",
    },
    packages=find_packages(exclude=["tests", "experiments", "docs"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Image Recognition",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=get_requirements(),
    extras_require={
        "dev": dev_requirements,
        "export": export_requirements,
        "viz": viz_requirements,
        "all": dev_requirements + export_requirements + viz_requirements,
    },
    entry_points={
        "console_scripts": [
            "sf-yolo11-train=scripts.train:main",
            "sf-yolo11-val=scripts.val:main",
            "sf-yolo11-test=scripts.test:main",
            "sf-yolo11-prune=scripts.prune:main",
            "sf-yolo11-export=scripts.export:main",
            "sf-yolo11-demo=scripts.demo:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.yaml", "*.yml", "*.json", "*.txt", "*.md"],
        "configs": ["*.yaml", "*.yml"],
        "data": ["*.yaml", "*.yml"],
    },
    zip_safe=False,
    keywords=[
        "yolo",
        "object-detection",
        "computer-vision",
        "deep-learning",
        "pytorch",
        "pruning",
        "model-compression",
        "agricultural-ai",
        "winter-jujube",
        "small-object-detection",
    ],
    # Additional metadata
    platforms=["any"],
    license="MIT",
    # Test suite
    test_suite="tests",
    tests_require=[
        "pytest>=6.0",
        "pytest-cov>=2.0",
    ],
)