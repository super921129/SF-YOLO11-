"""
Utils Package for SF-YOLO11
===========================

This package contains utility functions and classes for SF-YOLO11 model training,
evaluation, and inference.

Modules:
- datasets: Data loading and augmentation utilities
- loss: Loss functions for training
- metrics: Evaluation metrics (mAP, Recall, Precision)
- general: General utility functions
- torch_utils: PyTorch-specific utilities
- plots: Visualization and plotting utilities
"""

from .datasets import *
from .loss import *
from .metrics import *
from .general import *
from .torch_utils import *
from .plots import *

__version__ = "1.0.0"
__author__ = "SF-YOLO11 Team"