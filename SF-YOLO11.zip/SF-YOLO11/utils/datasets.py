"""
Dataset Utilities for SF-YOLO11
===============================

This module provides dataset loading and augmentation utilities optimized
for winter jujube detection, including specialized augmentations for small
object detection and agricultural scenarios.

Key Features:
1. Winter jujube dataset loading
2. Small object-aware augmentations
3. Agricultural scene-specific transforms
4. Multi-scale training support
5. Efficient data loading with caching
"""

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
import cv2
import numpy as np
import os
import json
import yaml
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Union, Callable
import albumentations as A
from albumentations.pytorch import ToTensorV2
import random
import math
from PIL import Image, ImageDraw, ImageFont


class WinterJujubeDataset(Dataset):
    """
    Winter Jujube Dataset for SF-YOLO11
    
    Supports YOLO format annotations with specialized augmentations
    for small object detection in agricultural scenarios.
    """
    
    def __init__(self, 
                 data_path: str,
                 img_size: int = 640,
                 augment: bool = True,
                 cache_images: bool = False,
                 single_cls: bool = False,
                 stride: int = 32,
                 pad: float = 0.0,
                 prefix: str = ''):
        """
        Args:
            data_path: Path to dataset YAML file or image directory
            img_size: Target image size
            augment: Enable augmentations
            cache_images: Cache images in memory
            single_cls: Use single class (winter jujube only)
            stride: Model stride for padding
            pad: Padding ratio
            prefix: Logging prefix
        """
        self.img_size = img_size
        self.augment = augment
        self.cache_images = cache_images
        self.single_cls = single_cls
        self.stride = stride
        self.pad = pad
        self.prefix = prefix
        
        # Load dataset configuration
        if data_path.endswith('.yaml'):
            with open(data_path, 'r', encoding='utf-8') as f:
                data_config = yaml.safe_load(f)
            self.data_root = Path(data_config['path'])
            self.img_paths = self._load_image_paths(data_config)
            self.class_names = data_config['names']
        else:
            self.data_root = Path(data_path)
            self.img_paths = self._load_image_paths_from_dir(data_path)
            self.class_names = ['winter_jujube']
        
        self.num_classes = len(self.class_names)
        
        # Load labels
        self.labels = self._load_labels()
        
        # Cache images if requested
        self.imgs = [None] * len(self.img_paths)
        if cache_images:
            self._cache_images()
        
        # Initialize augmentation pipeline
        self.transforms = self._create_transforms()
    
    def _load_image_paths(self, data_config: Dict) -> List[str]:
        """Load image paths from dataset configuration"""
        img_paths = []
        
        # Handle different dataset splits
        for split in ['train', 'val', 'test']:
            if split in data_config:
                split_path = self.data_root / data_config[split]
                if split_path.is_file():
                    # Load from text file
                    with open(split_path, 'r') as f:
                        paths = [line.strip() for line in f.readlines()]
                    img_paths.extend(paths)
                elif split_path.is_dir():
                    # Load from directory
                    for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp']:
                        img_paths.extend(list(split_path.glob(ext)))
        
        return [str(p) for p in img_paths]
    
    def _load_image_paths_from_dir(self, data_path: str) -> List[str]:
        """Load image paths from directory"""
        img_paths = []
        data_dir = Path(data_path)
        
        for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp']:
            img_paths.extend(list(data_dir.glob(ext)))
        
        return [str(p) for p in img_paths]
    
    def _load_labels(self) -> List[np.ndarray]:
        """Load YOLO format labels"""
        labels = []
        
        for img_path in self.img_paths:
            # Convert image path to label path
            label_path = img_path.replace('/images/', '/labels/').replace('.jpg', '.txt').replace('.png', '.txt')
            
            if os.path.exists(label_path):
                # Load YOLO format labels
                with open(label_path, 'r') as f:
                    lines = f.readlines()
                
                label_data = []
                for line in lines:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        cls_id = int(parts[0])
                        if self.single_cls:
                            cls_id = 0  # Convert to single class
                        
                        x_center, y_center, width, height = map(float, parts[1:5])
                        label_data.append([cls_id, x_center, y_center, width, height])
                
                labels.append(np.array(label_data, dtype=np.float32))
            else:
                # No labels for this image
                labels.append(np.zeros((0, 5), dtype=np.float32))
        
        return labels
    
    def _cache_images(self):
        """Cache images in memory for faster loading"""
        print(f"{self.prefix}Caching images...")
        
        for i, img_path in enumerate(self.img_paths):
            self.imgs[i] = cv2.imread(img_path)
            if i % 100 == 0:
                print(f"{self.prefix}Cached {i}/{len(self.img_paths)} images")
    
    def _create_transforms(self) -> Callable:
        """Create augmentation pipeline optimized for winter jujube detection"""
        if self.augment:
            # Training augmentations with small object focus
            transform = A.Compose([
                # Geometric augmentations
                A.RandomResizedCrop(height=self.img_size, width=self.img_size, 
                                  scale=(0.8, 1.0), ratio=(0.8, 1.2), p=0.5),
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.2),
                A.RandomRotate90(p=0.2),
                A.Rotate(limit=15, p=0.3),
                
                # Color augmentations (important for fruit detection)
                A.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1, p=0.5),
                A.HueSaturationValue(hue_shift_limit=10, sat_shift_limit=20, val_shift_limit=20, p=0.5),
                A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2, p=0.5),
                
                # Weather and lighting augmentations
                A.RandomShadow(p=0.2),
                A.RandomSunFlare(p=0.1),
                A.RandomFog(p=0.1),
                
                # Noise and blur (simulate camera conditions)
                A.GaussNoise(var_limit=(10, 50), p=0.2),
                A.MotionBlur(blur_limit=3, p=0.2),
                A.GaussianBlur(blur_limit=3, p=0.1),
                
                # Small object enhancement
                A.SmallObjectAugmentation(p=0.3),
                
                # Normalization
                A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                ToTensorV2(),
            ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels']))
        else:
            # Validation/test transforms
            transform = A.Compose([
                A.Resize(height=self.img_size, width=self.img_size),
                A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                ToTensorV2(),
            ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels']))
        
        return transform
    
    def __len__(self) -> int:
        return len(self.img_paths)
    
    def __getitem__(self, index: int) -> Tuple[torch.Tensor, torch.Tensor, str, Tuple[int, int]]:
        """
        Get dataset item
        
        Returns:
            image: Preprocessed image tensor
            targets: Label tensor [num_objects, 6] (batch_idx, class, x, y, w, h)
            img_path: Image file path
            img_shape: Original image shape (h, w)
        """
        # Load image
        if self.imgs[index] is not None:
            img = self.imgs[index].copy()
        else:
            img = cv2.imread(self.img_paths[index])
        
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        h0, w0 = img.shape[:2]  # Original shape
        
        # Load labels
        labels = self.labels[index].copy()
        
        # Apply transforms
        if len(labels):
            # Convert YOLO format to albumentations format
            bboxes = labels[:, 1:5].tolist()
            class_labels = labels[:, 0].astype(int).tolist()
            
            transformed = self.transforms(image=img, bboxes=bboxes, class_labels=class_labels)
            img = transformed['image']
            
            # Convert back to YOLO format
            if transformed['bboxes']:
                labels = np.array([[cls] + list(bbox) for cls, bbox in 
                                 zip(transformed['class_labels'], transformed['bboxes'])], 
                                dtype=np.float32)
            else:
                labels = np.zeros((0, 5), dtype=np.float32)
        else:
            # No labels, just transform image
            transformed = self.transforms(image=img, bboxes=[], class_labels=[])
            img = transformed['image']
        
        # Convert labels to tensor format [num_objects, 6] (batch_idx, class, x, y, w, h)
        targets = torch.zeros((len(labels), 6))
        if len(labels):
            targets[:, 1:] = torch.from_numpy(labels)
        
        return img, targets, self.img_paths[index], (h0, w0)
    
    @staticmethod
    def collate_fn(batch):
        """Custom collate function for DataLoader"""
        imgs, targets, paths, shapes = zip(*batch)
        
        # Add batch index to targets
        for i, target in enumerate(targets):
            target[:, 0] = i
        
        return torch.stack(imgs, 0), torch.cat(targets, 0), paths, shapes


class SmallObjectAugmentation:
    """Custom augmentation for small object enhancement"""
    
    def __init__(self, p: float = 0.5, scale_range: Tuple[float, float] = (1.2, 2.0)):
        self.p = p
        self.scale_range = scale_range
    
    def __call__(self, image: np.ndarray, bboxes: List, class_labels: List) -> Dict:
        if random.random() > self.p or not bboxes:
            return {'image': image, 'bboxes': bboxes, 'class_labels': class_labels}
        
        h, w = image.shape[:2]
        enhanced_image = image.copy()
        enhanced_bboxes = bboxes.copy()
        enhanced_labels = class_labels.copy()
        
        # Find small objects (area < 0.01 of image)
        small_obj_indices = []
        for i, bbox in enumerate(bboxes):
            x_center, y_center, width, height = bbox
            area = width * height
            if area < 0.01:  # Small object threshold
                small_obj_indices.append(i)
        
        # Enhance small objects
        for idx in small_obj_indices:
            bbox = bboxes[idx]
            x_center, y_center, width, height = bbox
            
            # Calculate pixel coordinates
            x1 = int((x_center - width/2) * w)
            y1 = int((y_center - height/2) * h)
            x2 = int((x_center + width/2) * w)
            y2 = int((y_center + height/2) * h)
            
            # Extract object region
            obj_region = image[y1:y2, x1:x2]
            if obj_region.size == 0:
                continue
            
            # Scale up the object
            scale = random.uniform(*self.scale_range)
            new_h, new_w = int(obj_region.shape[0] * scale), int(obj_region.shape[1] * scale)
            scaled_obj = cv2.resize(obj_region, (new_w, new_h))
            
            # Find random position to place scaled object
            max_x = w - new_w
            max_y = h - new_h
            if max_x > 0 and max_y > 0:
                new_x = random.randint(0, max_x)
                new_y = random.randint(0, max_y)
                
                # Paste scaled object
                enhanced_image[new_y:new_y+new_h, new_x:new_x+new_w] = scaled_obj
                
                # Add new bbox
                new_bbox = [
                    (new_x + new_w/2) / w,  # x_center
                    (new_y + new_h/2) / h,  # y_center
                    new_w / w,              # width
                    new_h / h               # height
                ]
                enhanced_bboxes.append(new_bbox)
                enhanced_labels.append(class_labels[idx])
        
        return {
            'image': enhanced_image,
            'bboxes': enhanced_bboxes,
            'class_labels': enhanced_labels
        }


def create_dataloader(dataset: Dataset,
                     batch_size: int = 16,
                     shuffle: bool = True,
                     num_workers: int = 4,
                     pin_memory: bool = True,
                     drop_last: bool = False) -> DataLoader:
    """Create optimized DataLoader for SF-YOLO11"""
    
    return DataLoader(
        dataset=dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=drop_last,
        collate_fn=dataset.collate_fn,
        persistent_workers=num_workers > 0
    )


def load_dataset_config(config_path: str) -> Dict:
    """Load dataset configuration from YAML file"""
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    # Validate required fields
    required_fields = ['path', 'train', 'val', 'names']
    for field in required_fields:
        if field not in config:
            raise ValueError(f"Missing required field '{field}' in dataset config")
    
    return config


def verify_dataset(data_path: str) -> Dict[str, int]:
    """Verify dataset integrity and return statistics"""
    config = load_dataset_config(data_path)
    data_root = Path(config['path'])
    
    stats = {
        'total_images': 0,
        'total_labels': 0,
        'missing_labels': 0,
        'empty_labels': 0,
        'classes': len(config['names'])
    }
    
    # Check each split
    for split in ['train', 'val', 'test']:
        if split in config:
            split_path = data_root / config[split]
            
            if split_path.is_file():
                # Load image paths from file
                with open(split_path, 'r') as f:
                    img_paths = [line.strip() for line in f.readlines()]
            elif split_path.is_dir():
                # Load from directory
                img_paths = []
                for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp']:
                    img_paths.extend(list(split_path.glob(ext)))
                img_paths = [str(p) for p in img_paths]
            else:
                continue
            
            stats['total_images'] += len(img_paths)
            
            # Check labels
            for img_path in img_paths:
                label_path = img_path.replace('/images/', '/labels/').replace('.jpg', '.txt').replace('.png', '.txt')
                
                if os.path.exists(label_path):
                    stats['total_labels'] += 1
                    
                    # Check if label file is empty
                    with open(label_path, 'r') as f:
                        lines = f.readlines()
                    if not lines:
                        stats['empty_labels'] += 1
                else:
                    stats['missing_labels'] += 1
    
    return stats


if __name__ == "__main__":
    # Test dataset loading
    dataset_config = {
        'path': './data',
        'train': 'images/train',
        'val': 'images/val',
        'names': ['winter_jujube']
    }
    
    # Save test config
    with open('./data/winter_jujube.yaml', 'w') as f:
        yaml.dump(dataset_config, f)
    
    # Create dataset
    dataset = WinterJujubeDataset(
        data_path='./data/winter_jujube.yaml',
        img_size=640,
        augment=True
    )
    
    print(f"Dataset size: {len(dataset)}")
    print(f"Number of classes: {dataset.num_classes}")
    print(f"Class names: {dataset.class_names}")
    
    # Test data loading
    if len(dataset) > 0:
        img, targets, path, shape = dataset[0]
        print(f"Image shape: {img.shape}")
        print(f"Targets shape: {targets.shape}")
        print(f"Original shape: {shape}")
    
    # Create dataloader
    dataloader = create_dataloader(dataset, batch_size=4, num_workers=0)
    
    # Test batch loading
    for batch_idx, (images, targets, paths, shapes) in enumerate(dataloader):
        print(f"Batch {batch_idx}:")
        print(f"  Images shape: {images.shape}")
        print(f"  Targets shape: {targets.shape}")
        print(f"  Batch size: {len(paths)}")
        break