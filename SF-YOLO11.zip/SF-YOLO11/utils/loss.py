"""
Loss Functions for SF-YOLO11
============================

This module implements optimized loss functions for SF-YOLO11,
specifically designed for winter jujube detection with focus on
small object detection and class imbalance handling.

Key Features:
1. Focal Loss for class imbalance
2. IoU-aware loss functions (GIoU, DIoU, CIoU)
3. Small object enhancement loss
4. Adaptive loss weighting
5. Multi-scale loss computation
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Tuple, Dict, Optional, List
import numpy as np


class FocalLoss(nn.Module):
    """
    Focal Loss for addressing class imbalance in object detection
    
    Paper: "Focal Loss for Dense Object Detection"
    """
    
    def __init__(self, alpha: float = 0.25, gamma: float = 2.0, reduction: str = 'mean'):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
    
    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        Args:
            inputs: Predicted logits [N, C] or [N, H, W, C]
            targets: Ground truth labels [N] or [N, H, W]
        """
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss
        
        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss


class IoULoss(nn.Module):
    """
    IoU-based loss functions (IoU, GIoU, DIoU, CIoU)
    
    Supports multiple IoU variants for better bounding box regression
    """
    
    def __init__(self, iou_type: str = 'ciou', eps: float = 1e-7):
        super(IoULoss, self).__init__()
        self.iou_type = iou_type.lower()
        self.eps = eps
        
        assert self.iou_type in ['iou', 'giou', 'diou', 'ciou'], \
            f"Unsupported IoU type: {iou_type}"
    
    def forward(self, pred_boxes: torch.Tensor, target_boxes: torch.Tensor) -> torch.Tensor:
        """
        Args:
            pred_boxes: Predicted boxes [N, 4] (x1, y1, x2, y2)
            target_boxes: Target boxes [N, 4] (x1, y1, x2, y2)
        """
        if self.iou_type == 'iou':
            iou = self._calculate_iou(pred_boxes, target_boxes)
            return 1 - iou
        elif self.iou_type == 'giou':
            giou = self._calculate_giou(pred_boxes, target_boxes)
            return 1 - giou
        elif self.iou_type == 'diou':
            diou = self._calculate_diou(pred_boxes, target_boxes)
            return 1 - diou
        elif self.iou_type == 'ciou':
            ciou = self._calculate_ciou(pred_boxes, target_boxes)
            return 1 - ciou
    
    def _calculate_iou(self, box1: torch.Tensor, box2: torch.Tensor) -> torch.Tensor:
        """Calculate IoU between two sets of boxes"""
        # Intersection area
        inter_x1 = torch.max(box1[:, 0], box2[:, 0])
        inter_y1 = torch.max(box1[:, 1], box2[:, 1])
        inter_x2 = torch.min(box1[:, 2], box2[:, 2])
        inter_y2 = torch.min(box1[:, 3], box2[:, 3])
        
        inter_area = torch.clamp(inter_x2 - inter_x1, min=0) * \
                    torch.clamp(inter_y2 - inter_y1, min=0)
        
        # Union area
        box1_area = (box1[:, 2] - box1[:, 0]) * (box1[:, 3] - box1[:, 1])
        box2_area = (box2[:, 2] - box2[:, 0]) * (box2[:, 3] - box2[:, 1])
        union_area = box1_area + box2_area - inter_area
        
        iou = inter_area / (union_area + self.eps)
        return iou
    
    def _calculate_giou(self, box1: torch.Tensor, box2: torch.Tensor) -> torch.Tensor:
        """Calculate Generalized IoU"""
        iou = self._calculate_iou(box1, box2)
        
        # Enclosing box
        enclose_x1 = torch.min(box1[:, 0], box2[:, 0])
        enclose_y1 = torch.min(box1[:, 1], box2[:, 1])
        enclose_x2 = torch.max(box1[:, 2], box2[:, 2])
        enclose_y2 = torch.max(box1[:, 3], box2[:, 3])
        
        enclose_area = (enclose_x2 - enclose_x1) * (enclose_y2 - enclose_y1)
        
        # Union area
        box1_area = (box1[:, 2] - box1[:, 0]) * (box1[:, 3] - box1[:, 1])
        box2_area = (box2[:, 2] - box2[:, 0]) * (box2[:, 3] - box2[:, 1])
        union_area = box1_area + box2_area - iou * box1_area  # Approximate union
        
        giou = iou - (enclose_area - union_area) / (enclose_area + self.eps)
        return giou
    
    def _calculate_diou(self, box1: torch.Tensor, box2: torch.Tensor) -> torch.Tensor:
        """Calculate Distance IoU"""
        iou = self._calculate_iou(box1, box2)
        
        # Center points
        box1_center_x = (box1[:, 0] + box1[:, 2]) / 2
        box1_center_y = (box1[:, 1] + box1[:, 3]) / 2
        box2_center_x = (box2[:, 0] + box2[:, 2]) / 2
        box2_center_y = (box2[:, 1] + box2[:, 3]) / 2
        
        # Distance between centers
        center_distance = (box1_center_x - box2_center_x) ** 2 + \
                         (box1_center_y - box2_center_y) ** 2
        
        # Diagonal of enclosing box
        enclose_x1 = torch.min(box1[:, 0], box2[:, 0])
        enclose_y1 = torch.min(box1[:, 1], box2[:, 1])
        enclose_x2 = torch.max(box1[:, 2], box2[:, 2])
        enclose_y2 = torch.max(box1[:, 3], box2[:, 3])
        
        diagonal_distance = (enclose_x2 - enclose_x1) ** 2 + \
                           (enclose_y2 - enclose_y1) ** 2
        
        diou = iou - center_distance / (diagonal_distance + self.eps)
        return diou
    
    def _calculate_ciou(self, box1: torch.Tensor, box2: torch.Tensor) -> torch.Tensor:
        """Calculate Complete IoU"""
        diou = self._calculate_diou(box1, box2)
        
        # Aspect ratio consistency
        box1_w = box1[:, 2] - box1[:, 0]
        box1_h = box1[:, 3] - box1[:, 1]
        box2_w = box2[:, 2] - box2[:, 0]
        box2_h = box2[:, 3] - box2[:, 1]
        
        v = (4 / (math.pi ** 2)) * torch.pow(
            torch.atan(box2_w / (box2_h + self.eps)) - 
            torch.atan(box1_w / (box1_h + self.eps)), 2
        )
        
        iou = self._calculate_iou(box1, box2)
        alpha = v / (1 - iou + v + self.eps)
        
        ciou = diou - alpha * v
        return ciou


class SmallObjectLoss(nn.Module):
    """
    Enhanced loss for small object detection
    
    Applies higher weights to small objects to improve detection performance
    """
    
    def __init__(self, 
                 small_threshold: float = 0.02,
                 scale_factor: float = 2.0,
                 base_loss: nn.Module = None):
        super(SmallObjectLoss, self).__init__()
        self.small_threshold = small_threshold
        self.scale_factor = scale_factor
        self.base_loss = base_loss or nn.MSELoss(reduction='none')
    
    def forward(self, 
                pred_boxes: torch.Tensor, 
                target_boxes: torch.Tensor,
                img_size: int = 640) -> torch.Tensor:
        """
        Args:
            pred_boxes: Predicted boxes [N, 4] (normalized)
            target_boxes: Target boxes [N, 4] (normalized)
            img_size: Image size for area calculation
        """
        # Calculate base loss
        base_loss = self.base_loss(pred_boxes, target_boxes)
        
        # Calculate object areas (normalized)
        target_areas = (target_boxes[:, 2] - target_boxes[:, 0]) * \
                      (target_boxes[:, 3] - target_boxes[:, 1])
        
        # Identify small objects
        small_mask = target_areas < self.small_threshold
        
        # Apply scale factor to small objects
        weights = torch.ones_like(target_areas)
        weights[small_mask] = self.scale_factor
        
        # Weight the loss
        weighted_loss = base_loss * weights.unsqueeze(-1)
        
        return weighted_loss.mean()


class SFYOLO11Loss(nn.Module):
    """
    Complete loss function for SF-YOLO11
    
    Combines classification, objectness, and box regression losses
    with optimizations for winter jujube detection
    """
    
    def __init__(self,
                 num_classes: int = 1,
                 img_size: int = 640,
                 cls_weight: float = 0.5,
                 obj_weight: float = 1.0,
                 box_weight: float = 0.05,
                 focal_loss: bool = True,
                 iou_type: str = 'ciou',
                 small_obj_enhancement: bool = True):
        super(SFYOLO11Loss, self).__init__()
        
        self.num_classes = num_classes
        self.img_size = img_size
        self.cls_weight = cls_weight
        self.obj_weight = obj_weight
        self.box_weight = box_weight
        
        # Loss functions
        if focal_loss:
            self.cls_loss_fn = FocalLoss(alpha=0.25, gamma=2.0)
            self.obj_loss_fn = FocalLoss(alpha=0.25, gamma=2.0)
        else:
            self.cls_loss_fn = nn.BCEWithLogitsLoss()
            self.obj_loss_fn = nn.BCEWithLogitsLoss()
        
        self.box_loss_fn = IoULoss(iou_type=iou_type)
        
        if small_obj_enhancement:
            self.small_obj_loss_fn = SmallObjectLoss(
                small_threshold=0.02,
                scale_factor=2.0,
                base_loss=self.box_loss_fn
            )
        else:
            self.small_obj_loss_fn = None
    
    def forward(self, 
                predictions: List[torch.Tensor], 
                targets: torch.Tensor,
                anchors: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Args:
            predictions: List of prediction tensors from different scales
            targets: Ground truth targets [num_targets, 6] (batch_idx, cls, x, y, w, h)
            anchors: Anchor boxes for each scale
        
        Returns:
            Dictionary containing individual and total losses
        """
        device = predictions[0].device
        
        # Initialize losses
        cls_loss = torch.zeros(1, device=device)
        obj_loss = torch.zeros(1, device=device)
        box_loss = torch.zeros(1, device=device)
        
        # Process each scale
        for i, pred in enumerate(predictions):
            batch_size, num_anchors, grid_h, grid_w, num_outputs = pred.shape
            
            # Reshape predictions
            pred = pred.view(batch_size, num_anchors, grid_h, grid_w, 
                           5 + self.num_classes)  # x, y, w, h, obj, cls...
            
            # Extract prediction components
            pred_xy = pred[..., 0:2]      # Center coordinates
            pred_wh = pred[..., 2:4]      # Width and height
            pred_obj = pred[..., 4:5]     # Objectness
            pred_cls = pred[..., 5:]      # Class probabilities
            
            # Build targets for this scale
            scale_targets = self._build_targets(targets, anchors[i], 
                                              grid_h, grid_w, batch_size, num_anchors)
            
            if scale_targets is not None:
                target_xy, target_wh, target_obj, target_cls, valid_mask = scale_targets
                
                # Calculate losses only for valid targets
                if valid_mask.sum() > 0:
                    # Box regression loss
                    pred_boxes = torch.cat([pred_xy, pred_wh], dim=-1)[valid_mask]
                    target_boxes = torch.cat([target_xy, target_wh], dim=-1)[valid_mask]
                    
                    if self.small_obj_loss_fn is not None:
                        box_loss += self.small_obj_loss_fn(pred_boxes, target_boxes)
                    else:
                        box_loss += self.box_loss_fn(
                            self._xywh_to_xyxy(pred_boxes),
                            self._xywh_to_xyxy(target_boxes)
                        ).mean()
                    
                    # Classification loss
                    if self.num_classes > 1:
                        cls_loss += self.cls_loss_fn(
                            pred_cls[valid_mask], 
                            target_cls[valid_mask]
                        )
                
                # Objectness loss (for all positions)
                obj_loss += self.obj_loss_fn(pred_obj.squeeze(-1), target_obj)
        
        # Combine losses
        total_loss = (self.cls_weight * cls_loss + 
                     self.obj_weight * obj_loss + 
                     self.box_weight * box_loss)
        
        return {
            'total_loss': total_loss,
            'cls_loss': cls_loss,
            'obj_loss': obj_loss,
            'box_loss': box_loss
        }
    
    def _build_targets(self, 
                      targets: torch.Tensor,
                      anchors: torch.Tensor,
                      grid_h: int,
                      grid_w: int,
                      batch_size: int,
                      num_anchors: int) -> Optional[Tuple]:
        """Build targets for a specific scale"""
        if targets.numel() == 0:
            return None
        
        device = targets.device
        
        # Initialize target tensors
        target_xy = torch.zeros(batch_size, num_anchors, grid_h, grid_w, 2, device=device)
        target_wh = torch.zeros(batch_size, num_anchors, grid_h, grid_w, 2, device=device)
        target_obj = torch.zeros(batch_size, num_anchors, grid_h, grid_w, device=device)
        target_cls = torch.zeros(batch_size, num_anchors, grid_h, grid_w, 
                               self.num_classes, device=device)
        valid_mask = torch.zeros(batch_size, num_anchors, grid_h, grid_w, 
                               dtype=torch.bool, device=device)
        
        # Process each target
        for target in targets:
            batch_idx = int(target[0])
            cls_id = int(target[1])
            x_center, y_center, width, height = target[2:6]
            
            # Convert to grid coordinates
            grid_x = x_center * grid_w
            grid_y = y_center * grid_h
            grid_i = int(grid_x)
            grid_j = int(grid_y)
            
            # Check bounds
            if 0 <= grid_i < grid_w and 0 <= grid_j < grid_h:
                # Find best matching anchor
                target_wh_scaled = torch.tensor([width * grid_w, height * grid_h], device=device)
                anchor_ious = self._calculate_anchor_iou(target_wh_scaled, anchors)
                best_anchor = torch.argmax(anchor_ious)
                
                # Set targets
                target_xy[batch_idx, best_anchor, grid_j, grid_i] = torch.tensor([grid_x - grid_i, grid_y - grid_j])
                target_wh[batch_idx, best_anchor, grid_j, grid_i] = target_wh_scaled / anchors[best_anchor]
                target_obj[batch_idx, best_anchor, grid_j, grid_i] = 1.0
                
                if self.num_classes > 1:
                    target_cls[batch_idx, best_anchor, grid_j, grid_i, cls_id] = 1.0
                
                valid_mask[batch_idx, best_anchor, grid_j, grid_i] = True
        
        return target_xy, target_wh, target_obj, target_cls, valid_mask
    
    def _calculate_anchor_iou(self, target_wh: torch.Tensor, anchors: torch.Tensor) -> torch.Tensor:
        """Calculate IoU between target and anchors"""
        # Assume anchors are centered at origin
        target_area = target_wh[0] * target_wh[1]
        anchor_areas = anchors[:, 0] * anchors[:, 1]
        
        # Intersection (minimum of widths and heights)
        inter_w = torch.min(target_wh[0], anchors[:, 0])
        inter_h = torch.min(target_wh[1], anchors[:, 1])
        inter_area = inter_w * inter_h
        
        # Union
        union_area = target_area + anchor_areas - inter_area
        
        # IoU
        iou = inter_area / (union_area + 1e-7)
        return iou
    
    def _xywh_to_xyxy(self, boxes: torch.Tensor) -> torch.Tensor:
        """Convert boxes from (x_center, y_center, width, height) to (x1, y1, x2, y2)"""
        x_center, y_center, width, height = boxes.unbind(-1)
        x1 = x_center - width / 2
        y1 = y_center - height / 2
        x2 = x_center + width / 2
        y2 = y_center + height / 2
        return torch.stack([x1, y1, x2, y2], dim=-1)


class AdaptiveLossWeighting(nn.Module):
    """
    Adaptive loss weighting based on training progress and performance
    """
    
    def __init__(self, 
                 initial_weights: Dict[str, float],
                 adaptation_rate: float = 0.01,
                 min_weight: float = 0.1,
                 max_weight: float = 2.0):
        super(AdaptiveLossWeighting, self).__init__()
        
        self.weights = nn.ParameterDict({
            k: nn.Parameter(torch.tensor(v, dtype=torch.float32))
            for k, v in initial_weights.items()
        })
        self.adaptation_rate = adaptation_rate
        self.min_weight = min_weight
        self.max_weight = max_weight
        
        # Track loss history for adaptation
        self.loss_history = {k: [] for k in initial_weights.keys()}
    
    def forward(self, losses: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Apply adaptive weighting to losses
        
        Args:
            losses: Dictionary of individual losses
            
        Returns:
            Weighted total loss
        """
        total_loss = torch.zeros(1, device=list(losses.values())[0].device)
        
        for loss_name, loss_value in losses.items():
            if loss_name in self.weights:
                weight = torch.clamp(self.weights[loss_name], 
                                   self.min_weight, self.max_weight)
                total_loss += weight * loss_value
                
                # Update loss history
                self.loss_history[loss_name].append(loss_value.item())
                if len(self.loss_history[loss_name]) > 100:
                    self.loss_history[loss_name].pop(0)
        
        return total_loss
    
    def adapt_weights(self):
        """Adapt weights based on loss history"""
        with torch.no_grad():
            for loss_name, weight in self.weights.items():
                if len(self.loss_history[loss_name]) > 10:
                    # Calculate recent loss trend
                    recent_losses = self.loss_history[loss_name][-10:]
                    trend = np.polyfit(range(len(recent_losses)), recent_losses, 1)[0]
                    
                    # Increase weight if loss is increasing (not improving)
                    if trend > 0:
                        weight.data += self.adaptation_rate
                    else:
                        weight.data -= self.adaptation_rate
                    
                    # Clamp weights
                    weight.data = torch.clamp(weight.data, self.min_weight, self.max_weight)


if __name__ == "__main__":
    # Test loss functions
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Test IoU Loss
    pred_boxes = torch.tensor([[0.1, 0.1, 0.3, 0.3],
                              [0.2, 0.2, 0.4, 0.4]], device=device)
    target_boxes = torch.tensor([[0.15, 0.15, 0.35, 0.35],
                                [0.25, 0.25, 0.45, 0.45]], device=device)
    
    iou_loss = IoULoss(iou_type='ciou')
    loss_value = iou_loss(pred_boxes, target_boxes)
    print(f"CIoU Loss: {loss_value.item():.4f}")
    
    # Test Focal Loss
    pred_logits = torch.randn(10, 2, device=device)
    target_labels = torch.randint(0, 2, (10,), device=device)
    
    focal_loss = FocalLoss(alpha=0.25, gamma=2.0)
    focal_loss_value = focal_loss(pred_logits, target_labels)
    print(f"Focal Loss: {focal_loss_value.item():.4f}")
    
    # Test SF-YOLO11 Loss
    sf_loss = SFYOLO11Loss(num_classes=1, img_size=640)
    
    # Mock predictions (3 scales)
    predictions = [
        torch.randn(2, 3, 20, 20, 6, device=device),  # Small scale
        torch.randn(2, 3, 40, 40, 6, device=device),  # Medium scale
        torch.randn(2, 3, 80, 80, 6, device=device),  # Large scale
    ]
    
    # Mock targets
    targets = torch.tensor([
        [0, 0, 0.5, 0.5, 0.2, 0.2],  # batch_idx, cls, x, y, w, h
        [1, 0, 0.3, 0.3, 0.1, 0.1],
    ], device=device)
    
    # Mock anchors
    anchors = torch.tensor([
        [[10, 13], [16, 30], [33, 23]],    # Small scale anchors
        [[30, 61], [62, 45], [59, 119]],   # Medium scale anchors
        [[116, 90], [156, 198], [373, 326]] # Large scale anchors
    ], device=device, dtype=torch.float32)
    
    loss_dict = sf_loss(predictions, targets, anchors)
    print(f"Total Loss: {loss_dict['total_loss'].item():.4f}")
    print(f"Classification Loss: {loss_dict['cls_loss'].item():.4f}")
    print(f"Objectness Loss: {loss_dict['obj_loss'].item():.4f}")
    print(f"Box Loss: {loss_dict['box_loss'].item():.4f}")