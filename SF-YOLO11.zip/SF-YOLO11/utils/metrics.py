"""
Evaluation Metrics for SF-YOLO11
================================

This module implements comprehensive evaluation metrics for object detection,
specifically optimized for winter jujube detection performance assessment.

Key Features:
1. mAP (mean Average Precision) calculation
2. Precision and Recall metrics
3. F1-Score computation
4. Small object detection metrics
5. Speed and efficiency metrics
6. Confusion matrix analysis
"""

import torch
import torch.nn as nn
import numpy as np
from typing import List, Dict, Tuple, Optional, Union
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import json
import time
from collections import defaultdict
import warnings


class DetectionMetrics:
    """
    Comprehensive detection metrics calculator for SF-YOLO11
    
    Supports multiple IoU thresholds, class-specific metrics,
    and small object analysis
    """
    
    def __init__(self, 
                 num_classes: int = 1,
                 iou_thresholds: List[float] = None,
                 conf_threshold: float = 0.001,
                 nms_threshold: float = 0.6,
                 class_names: List[str] = None):
        """
        Args:
            num_classes: Number of object classes
            iou_thresholds: IoU thresholds for mAP calculation
            conf_threshold: Confidence threshold for predictions
            nms_threshold: NMS threshold
            class_names: List of class names
        """
        self.num_classes = num_classes
        self.iou_thresholds = iou_thresholds or np.arange(0.5, 0.96, 0.05)
        self.conf_threshold = conf_threshold
        self.nms_threshold = nms_threshold
        self.class_names = class_names or [f'class_{i}' for i in range(num_classes)]
        
        # Storage for predictions and targets
        self.predictions = []
        self.targets = []
        self.image_ids = []
        
        # Timing information
        self.inference_times = []
        self.nms_times = []
    
    def update(self, 
               predictions: torch.Tensor,
               targets: torch.Tensor,
               image_id: Union[int, str] = None,
               inference_time: float = None,
               nms_time: float = None):
        """
        Update metrics with new predictions and targets
        
        Args:
            predictions: Predicted boxes [N, 6] (x1, y1, x2, y2, conf, class)
            targets: Ground truth boxes [M, 5] (x1, y1, x2, y2, class)
            image_id: Image identifier
            inference_time: Inference time in seconds
            nms_time: NMS time in seconds
        """
        self.predictions.append(predictions.cpu().numpy() if torch.is_tensor(predictions) else predictions)
        self.targets.append(targets.cpu().numpy() if torch.is_tensor(targets) else targets)
        self.image_ids.append(image_id or len(self.image_ids))
        
        if inference_time is not None:
            self.inference_times.append(inference_time)
        if nms_time is not None:
            self.nms_times.append(nms_time)
    
    def compute_ap(self, 
                   predictions: np.ndarray,
                   targets: np.ndarray,
                   iou_threshold: float = 0.5,
                   class_id: int = 0) -> Tuple[float, np.ndarray, np.ndarray]:
        """
        Compute Average Precision for a specific class and IoU threshold
        
        Args:
            predictions: Predicted boxes [N, 6] (x1, y1, x2, y2, conf, class)
            targets: Ground truth boxes [M, 5] (x1, y1, x2, y2, class)
            iou_threshold: IoU threshold for positive detection
            class_id: Class ID to evaluate
            
        Returns:
            ap: Average Precision
            precision: Precision curve
            recall: Recall curve
        """
        # Filter predictions and targets for specific class
        pred_mask = predictions[:, 5] == class_id
        target_mask = targets[:, 4] == class_id
        
        class_predictions = predictions[pred_mask]
        class_targets = targets[target_mask]
        
        if len(class_predictions) == 0:
            return 0.0, np.array([]), np.array([])
        
        if len(class_targets) == 0:
            return 0.0, np.zeros(len(class_predictions)), np.zeros(len(class_predictions))
        
        # Sort predictions by confidence (descending)
        sort_indices = np.argsort(-class_predictions[:, 4])
        class_predictions = class_predictions[sort_indices]
        
        # Initialize arrays
        num_predictions = len(class_predictions)
        num_targets = len(class_targets)
        
        tp = np.zeros(num_predictions)  # True positives
        fp = np.zeros(num_predictions)  # False positives
        
        # Track which targets have been matched
        target_matched = np.zeros(num_targets, dtype=bool)
        
        # For each prediction
        for pred_idx, pred in enumerate(class_predictions):
            pred_box = pred[:4]
            
            # Find best matching target
            best_iou = 0
            best_target_idx = -1
            
            for target_idx, target in enumerate(class_targets):
                if target_matched[target_idx]:
                    continue
                
                target_box = target[:4]
                iou = self._calculate_iou(pred_box, target_box)
                
                if iou > best_iou:
                    best_iou = iou
                    best_target_idx = target_idx
            
            # Check if prediction is positive
            if best_iou >= iou_threshold and best_target_idx >= 0:
                tp[pred_idx] = 1
                target_matched[best_target_idx] = True
            else:
                fp[pred_idx] = 1
        
        # Compute precision and recall
        tp_cumsum = np.cumsum(tp)
        fp_cumsum = np.cumsum(fp)
        
        precision = tp_cumsum / (tp_cumsum + fp_cumsum + 1e-7)
        recall = tp_cumsum / (num_targets + 1e-7)
        
        # Compute AP using 11-point interpolation
        ap = self._compute_ap_11point(precision, recall)
        
        return ap, precision, recall
    
    def compute_map(self, 
                   iou_threshold: float = 0.5,
                   class_specific: bool = True) -> Dict[str, float]:
        """
        Compute mean Average Precision (mAP)
        
        Args:
            iou_threshold: IoU threshold for positive detection
            class_specific: Return class-specific AP values
            
        Returns:
            Dictionary containing mAP and class-specific AP values
        """
        if not self.predictions or not self.targets:
            return {'mAP': 0.0}
        
        # Concatenate all predictions and targets
        all_predictions = np.concatenate(self.predictions, axis=0) if self.predictions[0].ndim > 1 else np.vstack(self.predictions)
        all_targets = np.concatenate(self.targets, axis=0) if self.targets[0].ndim > 1 else np.vstack(self.targets)
        
        # Filter by confidence threshold
        conf_mask = all_predictions[:, 4] >= self.conf_threshold
        all_predictions = all_predictions[conf_mask]
        
        ap_values = []
        results = {}
        
        # Compute AP for each class
        for class_id in range(self.num_classes):
            ap, _, _ = self.compute_ap(all_predictions, all_targets, iou_threshold, class_id)
            ap_values.append(ap)
            
            if class_specific:
                class_name = self.class_names[class_id] if class_id < len(self.class_names) else f'class_{class_id}'
                results[f'AP_{class_name}'] = ap
        
        # Compute mAP
        map_value = np.mean(ap_values) if ap_values else 0.0
        results['mAP'] = map_value
        
        return results
    
    def compute_map_range(self, 
                         iou_range: Tuple[float, float] = (0.5, 0.95),
                         step: float = 0.05) -> Dict[str, float]:
        """
        Compute mAP over a range of IoU thresholds (COCO-style)
        
        Args:
            iou_range: Range of IoU thresholds (start, end)
            step: Step size for IoU thresholds
            
        Returns:
            Dictionary containing mAP@[iou_range] and individual threshold results
        """
        iou_thresholds = np.arange(iou_range[0], iou_range[1] + step, step)
        map_values = []
        results = {}
        
        for iou_thresh in iou_thresholds:
            map_result = self.compute_map(iou_threshold=iou_thresh, class_specific=False)
            map_values.append(map_result['mAP'])
            results[f'mAP@{iou_thresh:.2f}'] = map_result['mAP']
        
        # Overall mAP
        overall_map = np.mean(map_values) if map_values else 0.0
        results[f'mAP@{iou_range[0]:.2f}:{iou_range[1]:.2f}'] = overall_map
        
        return results
    
    def compute_precision_recall(self, 
                                iou_threshold: float = 0.5,
                                class_id: int = 0) -> Tuple[float, float, float]:
        """
        Compute Precision, Recall, and F1-Score
        
        Args:
            iou_threshold: IoU threshold for positive detection
            class_id: Class ID to evaluate
            
        Returns:
            precision: Overall precision
            recall: Overall recall
            f1_score: F1-Score
        """
        if not self.predictions or not self.targets:
            return 0.0, 0.0, 0.0
        
        # Concatenate all predictions and targets
        all_predictions = np.concatenate(self.predictions, axis=0) if self.predictions[0].ndim > 1 else np.vstack(self.predictions)
        all_targets = np.concatenate(self.targets, axis=0) if self.targets[0].ndim > 1 else np.vstack(self.targets)
        
        # Filter by confidence threshold
        conf_mask = all_predictions[:, 4] >= self.conf_threshold
        all_predictions = all_predictions[conf_mask]
        
        # Compute AP and get precision/recall curves
        ap, precision_curve, recall_curve = self.compute_ap(
            all_predictions, all_targets, iou_threshold, class_id
        )
        
        # Get final precision and recall values
        if len(precision_curve) > 0 and len(recall_curve) > 0:
            precision = precision_curve[-1]
            recall = recall_curve[-1]
        else:
            precision = 0.0
            recall = 0.0
        
        # Compute F1-Score
        f1_score = 2 * (precision * recall) / (precision + recall + 1e-7)
        
        return precision, recall, f1_score
    
    def compute_small_object_metrics(self, 
                                   area_threshold: float = 32**2,
                                   iou_threshold: float = 0.5) -> Dict[str, float]:
        """
        Compute metrics specifically for small objects
        
        Args:
            area_threshold: Pixel area threshold for small objects
            iou_threshold: IoU threshold for positive detection
            
        Returns:
            Dictionary containing small object metrics
        """
        if not self.predictions or not self.targets:
            return {'small_mAP': 0.0, 'small_recall': 0.0, 'small_precision': 0.0}
        
        # Filter small objects from targets
        small_predictions = []
        small_targets = []
        
        for pred, target in zip(self.predictions, self.targets):
            # Filter small targets
            if len(target) > 0:
                target_areas = (target[:, 2] - target[:, 0]) * (target[:, 3] - target[:, 1])
                small_mask = target_areas <= area_threshold
                small_target = target[small_mask]
                
                if len(small_target) > 0:
                    small_targets.append(small_target)
                    small_predictions.append(pred)  # Keep all predictions for matching
        
        if not small_predictions or not small_targets:
            return {'small_mAP': 0.0, 'small_recall': 0.0, 'small_precision': 0.0}
        
        # Temporarily store original data
        original_predictions = self.predictions
        original_targets = self.targets
        
        # Set small object data
        self.predictions = small_predictions
        self.targets = small_targets
        
        # Compute metrics
        map_result = self.compute_map(iou_threshold=iou_threshold, class_specific=False)
        precision, recall, f1 = self.compute_precision_recall(iou_threshold=iou_threshold)
        
        # Restore original data
        self.predictions = original_predictions
        self.targets = original_targets
        
        return {
            'small_mAP': map_result['mAP'],
            'small_precision': precision,
            'small_recall': recall,
            'small_f1': f1
        }
    
    def compute_speed_metrics(self) -> Dict[str, float]:
        """
        Compute speed and efficiency metrics
        
        Returns:
            Dictionary containing speed metrics
        """
        results = {}
        
        if self.inference_times:
            results['avg_inference_time'] = np.mean(self.inference_times)
            results['fps'] = 1.0 / np.mean(self.inference_times)
            results['inference_std'] = np.std(self.inference_times)
        
        if self.nms_times:
            results['avg_nms_time'] = np.mean(self.nms_times)
            results['nms_std'] = np.std(self.nms_times)
        
        if self.inference_times and self.nms_times:
            total_times = np.array(self.inference_times) + np.array(self.nms_times)
            results['avg_total_time'] = np.mean(total_times)
            results['total_fps'] = 1.0 / np.mean(total_times)
        
        return results
    
    def compute_confusion_matrix(self, 
                               iou_threshold: float = 0.5,
                               normalize: bool = True) -> np.ndarray:
        """
        Compute confusion matrix for multi-class detection
        
        Args:
            iou_threshold: IoU threshold for positive detection
            normalize: Whether to normalize the matrix
            
        Returns:
            Confusion matrix [num_classes+1, num_classes+1] (including background)
        """
        if not self.predictions or not self.targets:
            return np.zeros((self.num_classes + 1, self.num_classes + 1))
        
        # Initialize confusion matrix (including background class)
        confusion_matrix = np.zeros((self.num_classes + 1, self.num_classes + 1))
        
        # Process each image
        for pred, target in zip(self.predictions, self.targets):
            if len(pred) == 0 and len(target) == 0:
                continue
            
            # Match predictions to targets
            matches = self._match_predictions_to_targets(pred, target, iou_threshold)
            
            # Update confusion matrix
            for pred_idx, target_idx in matches:
                pred_class = int(pred[pred_idx, 5])
                target_class = int(target[target_idx, 4])
                confusion_matrix[target_class, pred_class] += 1
            
            # Handle unmatched predictions (false positives)
            unmatched_preds = set(range(len(pred))) - set([m[0] for m in matches])
            for pred_idx in unmatched_preds:
                pred_class = int(pred[pred_idx, 5])
                confusion_matrix[self.num_classes, pred_class] += 1  # Background to predicted class
            
            # Handle unmatched targets (false negatives)
            unmatched_targets = set(range(len(target))) - set([m[1] for m in matches])
            for target_idx in unmatched_targets:
                target_class = int(target[target_idx, 4])
                confusion_matrix[target_class, self.num_classes] += 1  # True class to background
        
        # Normalize if requested
        if normalize:
            row_sums = confusion_matrix.sum(axis=1, keepdims=True)
            confusion_matrix = confusion_matrix / (row_sums + 1e-7)
        
        return confusion_matrix
    
    def plot_precision_recall_curve(self, 
                                   class_id: int = 0,
                                   iou_threshold: float = 0.5,
                                   save_path: Optional[str] = None) -> plt.Figure:
        """
        Plot Precision-Recall curve
        
        Args:
            class_id: Class ID to plot
            iou_threshold: IoU threshold
            save_path: Path to save the plot
            
        Returns:
            Matplotlib figure
        """
        if not self.predictions or not self.targets:
            fig, ax = plt.subplots(figsize=(8, 6))
            ax.text(0.5, 0.5, 'No data available', ha='center', va='center')
            return fig
        
        # Concatenate all predictions and targets
        all_predictions = np.concatenate(self.predictions, axis=0) if self.predictions[0].ndim > 1 else np.vstack(self.predictions)
        all_targets = np.concatenate(self.targets, axis=0) if self.targets[0].ndim > 1 else np.vstack(self.targets)
        
        # Compute AP and curves
        ap, precision, recall = self.compute_ap(all_predictions, all_targets, iou_threshold, class_id)
        
        # Create plot
        fig, ax = plt.subplots(figsize=(8, 6))
        
        if len(precision) > 0 and len(recall) > 0:
            ax.plot(recall, precision, linewidth=2, label=f'AP = {ap:.3f}')
            ax.fill_between(recall, precision, alpha=0.3)
        
        ax.set_xlabel('Recall')
        ax.set_ylabel('Precision')
        ax.set_title(f'Precision-Recall Curve - {self.class_names[class_id]}')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_xlim([0, 1])
        ax.set_ylim([0, 1])
        
        if save_path:
            fig.savefig(save_path, dpi=300, bbox_inches='tight')
        
        return fig
    
    def plot_confusion_matrix(self, 
                            iou_threshold: float = 0.5,
                            normalize: bool = True,
                            save_path: Optional[str] = None) -> plt.Figure:
        """
        Plot confusion matrix
        
        Args:
            iou_threshold: IoU threshold
            normalize: Whether to normalize the matrix
            save_path: Path to save the plot
            
        Returns:
            Matplotlib figure
        """
        cm = self.compute_confusion_matrix(iou_threshold, normalize)
        
        # Create labels (including background)
        labels = self.class_names + ['Background']
        
        # Create plot
        fig, ax = plt.subplots(figsize=(10, 8))
        
        sns.heatmap(cm, annot=True, fmt='.2f' if normalize else 'd',
                   xticklabels=labels, yticklabels=labels,
                   cmap='Blues', ax=ax)
        
        ax.set_xlabel('Predicted')
        ax.set_ylabel('True')
        ax.set_title(f'Confusion Matrix (IoU ≥ {iou_threshold})')
        
        if save_path:
            fig.savefig(save_path, dpi=300, bbox_inches='tight')
        
        return fig
    
    def generate_report(self, 
                       save_path: Optional[str] = None,
                       include_plots: bool = True) -> Dict:
        """
        Generate comprehensive evaluation report
        
        Args:
            save_path: Path to save the report
            include_plots: Whether to include plots in the report
            
        Returns:
            Dictionary containing all metrics
        """
        report = {}
        
        # Basic mAP metrics
        report['mAP_metrics'] = self.compute_map_range()
        
        # Class-specific metrics
        for class_id in range(self.num_classes):
            class_name = self.class_names[class_id] if class_id < len(self.class_names) else f'class_{class_id}'
            precision, recall, f1 = self.compute_precision_recall(class_id=class_id)
            report[f'{class_name}_metrics'] = {
                'precision': precision,
                'recall': recall,
                'f1_score': f1
            }
        
        # Small object metrics
        report['small_object_metrics'] = self.compute_small_object_metrics()
        
        # Speed metrics
        report['speed_metrics'] = self.compute_speed_metrics()
        
        # Summary statistics
        if self.predictions and self.targets:
            total_predictions = sum(len(p) for p in self.predictions)
            total_targets = sum(len(t) for t in self.targets)
            report['summary'] = {
                'total_images': len(self.predictions),
                'total_predictions': total_predictions,
                'total_targets': total_targets,
                'avg_predictions_per_image': total_predictions / len(self.predictions),
                'avg_targets_per_image': total_targets / len(self.targets)
            }
        
        # Save report
        if save_path:
            save_dir = Path(save_path).parent
            save_dir.mkdir(parents=True, exist_ok=True)
            
            # Save JSON report
            json_path = save_dir / f"{Path(save_path).stem}_report.json"
            with open(json_path, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            # Generate plots if requested
            if include_plots:
                # PR curves for each class
                for class_id in range(self.num_classes):
                    class_name = self.class_names[class_id] if class_id < len(self.class_names) else f'class_{class_id}'
                    pr_path = save_dir / f"{Path(save_path).stem}_pr_curve_{class_name}.png"
                    self.plot_precision_recall_curve(class_id, save_path=str(pr_path))
                    plt.close()
                
                # Confusion matrix
                cm_path = save_dir / f"{Path(save_path).stem}_confusion_matrix.png"
                self.plot_confusion_matrix(save_path=str(cm_path))
                plt.close()
        
        return report
    
    def reset(self):
        """Reset all stored predictions and targets"""
        self.predictions = []
        self.targets = []
        self.image_ids = []
        self.inference_times = []
        self.nms_times = []
    
    def _calculate_iou(self, box1: np.ndarray, box2: np.ndarray) -> float:
        """Calculate IoU between two boxes"""
        # Intersection area
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        
        if x2 <= x1 or y2 <= y1:
            return 0.0
        
        intersection = (x2 - x1) * (y2 - y1)
        
        # Union area
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - intersection
        
        return intersection / (union + 1e-7)
    
    def _compute_ap_11point(self, precision: np.ndarray, recall: np.ndarray) -> float:
        """Compute AP using 11-point interpolation"""
        if len(precision) == 0 or len(recall) == 0:
            return 0.0
        
        # 11-point interpolation
        recall_thresholds = np.linspace(0, 1, 11)
        interpolated_precisions = []
        
        for r_thresh in recall_thresholds:
            # Find precisions for recalls >= r_thresh
            valid_indices = recall >= r_thresh
            if np.any(valid_indices):
                max_precision = np.max(precision[valid_indices])
                interpolated_precisions.append(max_precision)
            else:
                interpolated_precisions.append(0.0)
        
        return np.mean(interpolated_precisions)
    
    def _match_predictions_to_targets(self, 
                                    predictions: np.ndarray,
                                    targets: np.ndarray,
                                    iou_threshold: float) -> List[Tuple[int, int]]:
        """Match predictions to targets based on IoU threshold"""
        matches = []
        
        if len(predictions) == 0 or len(targets) == 0:
            return matches
        
        # Sort predictions by confidence
        pred_indices = np.argsort(-predictions[:, 4])
        target_matched = np.zeros(len(targets), dtype=bool)
        
        for pred_idx in pred_indices:
            pred = predictions[pred_idx]
            pred_box = pred[:4]
            pred_class = int(pred[5])
            
            best_iou = 0
            best_target_idx = -1
            
            for target_idx, target in enumerate(targets):
                if target_matched[target_idx]:
                    continue
                
                target_box = target[:4]
                target_class = int(target[4])
                
                # Check class match
                if pred_class != target_class:
                    continue
                
                iou = self._calculate_iou(pred_box, target_box)
                
                if iou > best_iou and iou >= iou_threshold:
                    best_iou = iou
                    best_target_idx = target_idx
            
            if best_target_idx >= 0:
                matches.append((pred_idx, best_target_idx))
                target_matched[best_target_idx] = True
        
        return matches


if __name__ == "__main__":
    # Test metrics calculation
    metrics = DetectionMetrics(num_classes=1, class_names=['winter_jujube'])
    
    # Mock data
    predictions = np.array([
        [100, 100, 200, 200, 0.9, 0],  # x1, y1, x2, y2, conf, class
        [150, 150, 250, 250, 0.8, 0],
        [300, 300, 400, 400, 0.7, 0],
    ])
    
    targets = np.array([
        [105, 105, 195, 195, 0],  # x1, y1, x2, y2, class
        [155, 155, 245, 245, 0],
    ])
    
    # Update metrics
    metrics.update(predictions, targets, image_id=0, inference_time=0.01, nms_time=0.002)
    
    # Compute various metrics
    map_results = metrics.compute_map()
    print(f"mAP: {map_results['mAP']:.4f}")
    
    precision, recall, f1 = metrics.compute_precision_recall()
    print(f"Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1:.4f}")
    
    speed_metrics = metrics.compute_speed_metrics()
    print(f"FPS: {speed_metrics.get('fps', 0):.2f}")
    
    # Generate comprehensive report
    report = metrics.generate_report()
    print("\nFull Report:")
    for key, value in report.items():
        print(f"{key}: {value}")